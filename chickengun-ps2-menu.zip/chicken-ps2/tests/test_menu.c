#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "../src/gfx.h"
#include "../src/input.h"
#include "../src/menu.h"
#include "../src/ui.h"

static int rects, texrects;
void gfx_init(void) {}
void gfx_begin(void) { rects = texrects = 0; }
void gfx_end(void) {}
void gfx_rect(int x, int y, int w, int h, unsigned c) { (void)x;(void)y;(void)c; rects++; assert(w >= 0 && h >= 0); }
void gfx_tex_rect(int t, int x, int y, int w, int h, int u0, int v0, int u1, int v1, unsigned c)
{
    const UiTexture *tx;
    (void)x;(void)y;(void)c; texrects++;
    assert(t >= 0 && t < UI_TEX_COUNT && w >= 0 && h >= 0);
    tx = &ui_textures[t];
    assert(u0 >= 0 && v0 >= 0 && u1 <= tx->w && v1 <= tx->h && u1 >= u0 && v1 >= v0);
}

static void press(Menu *m, unsigned b) { menu_update(m, b); gfx_begin(); menu_draw(m); assert(texrects > 0); }

static void check_data(void)
{
    int s, i;
    for (s = 0; s < UI_SCREEN_COUNT; s++)
        for (i = 0; i < ui_screens[s].n; i++) {
            const UiElem *e = &ui_screens[s].e[i];
            if (e->kind == 3) { assert(e->text && e->font < UI_FONT_COUNT); }
            if (e->kind == 1 || e->kind == 2) assert(e->tex < UI_TEX_COUNT && e->u1 > e->u0 && e->v1 > e->v0);
        }
}

int main(void)
{
    Menu m; int i;
    check_data();
    menu_init(&m);
    gfx_begin(); menu_draw(&m); assert(texrects > 0);
    /* Shop and Servers are not available */
    press(&m, BTN_LEFT); assert(m.sel == TAG_MAIN_SHOP);
    press(&m, BTN_CROSS); assert(m.scr == SCR_TITLE && m.notice > 0);
    press(&m, BTN_RIGHT); press(&m, BTN_RIGHT); assert(m.sel == TAG_MAIN_SERVERS);
    press(&m, BTN_CROSS); assert(m.scr == SCR_TITLE && m.notice > 0);
    /* Settings via START: toggle vibro, back */
    press(&m, BTN_START); assert(m.scr == SCR_SETTINGS && m.cfg.vibro == 1);
    press(&m, BTN_CROSS); assert(m.cfg.vibro == 0);
    press(&m, BTN_DOWN); press(&m, BTN_CROSS); assert(m.scr == SCR_TITLE);
    /* Play -> create screen */
    m.sel = TAG_MAIN_PLAYTEAMBATTLE; press(&m, BTN_CROSS); assert(m.scr == SCR_CREATE);
    /* pick Team fight */
    press(&m, BTN_RIGHT); press(&m, BTN_CROSS); assert(m.cfg.mode == 1);
    /* maps row: move to an unready map and try to create */
    press(&m, BTN_DOWN); press(&m, BTN_RIGHT); assert(m.cfg.map == 1);
    press(&m, BTN_CROSS); assert(m.notice > 0 && m.scr == SCR_CREATE);
    for (i = 0; i < 20; i++) press(&m, BTN_RIGHT);
    assert(m.cfg.map == N_MAPS - 1);
    for (i = 0; i < 20; i++) press(&m, BTN_LEFT);
    assert(m.cfg.map == 0);
    /* players count */
    press(&m, BTN_DOWN); assert(m.sel == TAG_CREATE_MNUS);
    for (i = 0; i < 30; i++) press(&m, BTN_CROSS);
    assert(m.cfg.players == MIN_PLAYERS);
    press(&m, BTN_RIGHT); assert(m.sel == TAG_CREATE_PLUS);
    for (i = 0; i < 40; i++) press(&m, BTN_CROSS);
    assert(m.cfg.players == MAX_PLAYERS);
    /* create -> loading -> game */
    press(&m, BTN_DOWN); assert(m.sel == TAG_CREATE_CREATEBUTTON);
    press(&m, BTN_CROSS); assert(m.scr == SCR_LOADING && m.cfg.map == 0);
    press(&m, BTN_CIRCLE); assert(m.scr == SCR_CREATE);
    press(&m, BTN_CROSS); assert(m.scr == SCR_LOADING);
    for (i = 0; i < 100; i++) press(&m, 0);
    assert(m.scr == SCR_GAME);
    press(&m, BTN_CIRCLE); assert(m.scr == SCR_TITLE);
    /* back button from create screen */
    m.sel = TAG_MAIN_PLAYTEAMBATTLE; press(&m, BTN_CROSS); press(&m, BTN_CIRCLE); assert(m.scr == SCR_TITLE);
    printf("menu tests OK\n");
    return 0;
}
