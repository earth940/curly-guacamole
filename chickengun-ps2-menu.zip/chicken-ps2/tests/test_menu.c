#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "../src/gfx.h"
#include "../src/input.h"
#include "../src/menu.h"

static int rects, texts;
void gfx_init(void) {}
void gfx_begin(void) { rects = texts = 0; }
void gfx_end(void) {}
void gfx_rect(int x, int y, int w, int h, unsigned c) { (void)x;(void)y;(void)w;(void)h;(void)c; rects++; assert(w >= 0 && h >= 0); }
void gfx_text(int x, int y, int s, unsigned c, const char *t) { (void)x;(void)y;(void)s;(void)c;(void)t; texts++; }
int gfx_text_width(int s, const char *t) { return (int)strlen(t) * s * 5 / 8; }

static void press(Menu *m, unsigned b) { menu_update(m, b); gfx_begin(); menu_draw(m); assert(rects > 0 && texts > 0); }

int main(void)
{
    Menu m; int i;
    menu_init(&m);
    /* Multiplayer is disabled */
    press(&m, BTN_DOWN); press(&m, BTN_DOWN); press(&m, BTN_CROSS);
    assert(m.scr == SCR_TITLE && m.notice > 0);
    /* Settings: adjust and clamp */
    press(&m, BTN_UP); press(&m, BTN_CROSS); assert(m.scr == SCR_SETTINGS);
    for (i = 0; i < 20; i++) press(&m, BTN_RIGHT);
    assert(m.cfg.music == 10);
    for (i = 0; i < 20; i++) press(&m, BTN_LEFT);
    assert(m.cfg.music == 0);
    press(&m, BTN_CIRCLE); assert(m.scr == SCR_TITLE);
    /* Play -> mode Team fight -> map */
    press(&m, BTN_UP); press(&m, BTN_UP); /* wrap to Multiplayer then Settings */
    m.sel = 0; press(&m, BTN_CROSS); assert(m.scr == SCR_MODE);
    press(&m, BTN_DOWN); press(&m, BTN_CROSS); assert(m.scr == SCR_MAP && m.cfg.mode == 1);
    /* unready map refuses */
    press(&m, BTN_DOWN); press(&m, BTN_CROSS); assert(m.scr == SCR_MAP && m.notice > 0);
    /* back goes to mode, forward again, pick ready map */
    press(&m, BTN_CIRCLE); assert(m.scr == SCR_MODE);
    press(&m, BTN_CROSS); assert(m.scr == SCR_MAP && m.sel == 0);
    press(&m, BTN_CROSS); assert(m.scr == SCR_LOADING && m.cfg.map == 0);
    for (i = 0; i < 100; i++) press(&m, 0);
    assert(m.scr == SCR_GAME);
    press(&m, BTN_CIRCLE); assert(m.scr == SCR_TITLE);
    printf("menu tests OK\n");
    return 0;
}
