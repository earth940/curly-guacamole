// Host tests for the gameplay core (no PS2 SDK needed): g++ -std=c++14 tests/test_game.cpp src/*.cpp (see tests/Makefile)
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "../src/game.h"

using namespace cg;

static FlatWorld world;
#define NEAR(a, b) (fabsf((a) - (b)) < 0.01f)

static void step(Game &g, float secs)
{
    for (float t = 0; t < secs; t += 1.0f / 60.0f) g.Update(1.0f / 60.0f);
}

static Player *setup(Game &g, GameMode m, TeamID team = TeamID::None)
{
    world = FlatWorld();
    g.Init(&world, m, 1234);
    g.AddSpawnPoint(Vec3(0, 0, 0));
    Player *p = g.AddPlayer(team);
    p->pos = Vec3(0, 0, 0);
    return p;
}

static void test_data()
{
    assert(GunCount() == 21 && BotDefCount() == 4);
    const GunDef *ak = FindGun("AK47");
    assert(ak && ak->damage == 16.0f && ak->maxAmmo == 50 && ak->loopShooting);
    assert(FindGun("nope") == nullptr);
    assert(GetPlayerDef().maxHp == 100 && NEAR(GetPlayerDef().speed, 5.5f));
}

static void test_movement()
{
    Game g; Player *p = setup(g, GameMode::PvP);
    p->pos = Vec3(0, 3, 0);                       // falls to the ground
    step(g, 1.0f);
    assert(p->grounded && NEAR(p->pos.y, 0));
    p->SetLook(0, 0); p->SetMove(0, 1);           // forward = +Z at yaw 0
    step(g, 1.0f);
    assert(p->pos.z > 5.3f && p->pos.z < 5.7f && fabsf(p->pos.x) < 0.01f);
    p->SetMove(0, 0); p->Jump();
    float top = 0;
    for (int i = 0; i < 90; i++) { g.Update(1.0f / 60); if (p->pos.y > top) top = p->pos.y; }
    assert(top > 1.0f && top < 1.6f);             // v^2 / 2g = 49/40 = 1.225 m
    assert(p->grounded);
    // walls block movement
    world.AddBox(Vec3(-5, 0, 7), Vec3(5, 3, 8));
    p->SetMove(0, 1);
    step(g, 2.0f);
    assert(p->pos.z < 7.0f);
}

static void test_damage_and_kill_credit()
{
    Game g; Player *a = setup(g, GameMode::PvP);
    Player *b = g.AddPlayer(TeamID::None); Player *c = g.AddPlayer(TeamID::None);
    b->Damage(30, c->id);                         // c assists
    b->Damage(80, a->id);                         // a kills (100 hp total)
    assert(!b->IsAlive() && b->info.deaths == 1);
    assert(a->info.score == 10 && a->info.frags == 1);
    assert(c->info.score == 3 && c->info.assists == 1);
    b->Damage(10, a->id);                         // no damage on a corpse, no extra credit
    assert(a->info.score == 10);
    b->Respawn(Vec3(1, 0, 1));
    assert(b->hp == b->maxHp && !b->IsThisIdKillerAssist(c->id));
    b->Heal(50); assert(b->hp == b->maxHp);
}

static void test_team_fight()
{
    Game g; Player *a = setup(g, GameMode::TeamFight, TeamID::TeamA);
    Player *mate = g.AddPlayer(TeamID::TeamA); Player *foe = g.AddPlayer(TeamID::TeamB);
    mate->Damage(50, a->id);
    assert(mate->hp == mate->maxHp);              // friendly fire ignored
    foe->Damage(100, a->id);
    assert(!foe->IsAlive() && g.GetTeamScore(TeamID::TeamA) == 10 && g.GetTeamScore(TeamID::TeamB) == 0);
    Game g2; Player *x = setup(g2, GameMode::PvP, TeamID::TeamA);
    Player *y = g2.AddPlayer(TeamID::TeamA);
    y->Damage(10, x->id);
    assert(y->hp == y->maxHp - 10);               // outside TeamFight teams do not matter
    assert(g2.GetTeamScore(TeamID::TeamA) == 0);
}

static void test_hitscan_weapon()
{
    Game g; Player *a = setup(g, GameMode::PvP);
    Player *t = g.AddPlayer(TeamID::None);
    t->pos = Vec3(0, 0, 20);
    a->AddWeapon("AK47"); a->AddWeapon("Knife");
    a->SetLook(0, 0);
    Weapon &w = a->Gun();
    assert(w.ammo == 50 && NEAR(w.FireInterval(), 16.0f / 62.0f));
    a->StartShoot();
    step(g, 0.6f);                                // ~2-3 shots incl. flight time
    assert(t->hp < t->maxHp);
    assert(w.ammo < 50);
    a->StopShoot();
    step(g, 0.3f);                                // let bullets already in flight land
    float hp = t->hp;                             // a wall in between must stop all further damage
    world.AddBox(Vec3(-3, 0, 10), Vec3(3, 5, 11));
    a->StartShoot(); step(g, 0.8f); a->StopShoot();
    assert(t->hp == hp);
}

static void test_reload()
{
    Game g; Player *a = setup(g, GameMode::PvP);
    a->AddWeapon("DesertEagle");                  // 18 rounds
    Weapon &w = a->Gun();
    a->StartShoot();
    step(g, 6.0f);
    assert(w.shotsFired >= 18);                   // emptied the mag and kept going after the reload
    assert(w.ammo >= 0 && w.ammo <= 18);
    a->StopShoot();
    w.ResetAmmo(); w.Reload();
    assert(!w.reloading);                         // full magazine: nothing to reload
    w.ammo = 3; w.Reload(); assert(w.reloading);
    step(g, kReloadTime + 0.1f);
    assert(!w.reloading && w.ammo == 18);
}

static void test_shotgun_and_dual()
{
    Game g; Player *a = setup(g, GameMode::PvP);
    Player *t = g.AddPlayer(TeamID::None); t->pos = Vec3(0, 0, 6);
    a->AddWeapon("3S");
    a->StartShoot(); step(g, 0.3f); a->StopShoot();
    assert(a->Gun().shotsFired == 1);             // pump action: a single pull
    assert(t->hp < t->maxHp - 18.0f);             // several of 8 pellets landed at 6 m
    assert(NEAR(a->Gun().FireInterval(), 18.0f * 8 / 74.0f));
    a->AddWeapon("DDEagle");
    assert(a->Gun().def->pivots == 8);            // selection is explicit: still the shotgun
    a->SelectWeapon(1);
    assert(a->Gun().def->pivots == 2);
}

static void test_melee()
{
    Game g; Player *a = setup(g, GameMode::PvP);
    Player *t = g.AddPlayer(TeamID::None); t->pos = Vec3(0, 0, 1.2f);
    a->AddWeapon("Knife");
    a->StartShoot(); step(g, 0.2f); a->StopShoot();
    assert(NEAR(t->hp, 100 - 55));                // BaseMeleeWeapon.damagePerHit = 55 in the prefab
    t->pos = Vec3(0, 0, 3.0f);
    float hp = t->hp;
    a->StartShoot(); step(g, 1.5f); a->StopShoot();
    assert(t->hp == hp);                          // out of the 1.4 m reach
}

static void test_rocket_splash()
{
    Game g; Player *a = setup(g, GameMode::PvP);
    Player *near_ = g.AddPlayer(TeamID::None), *far_ = g.AddPlayer(TeamID::None);
    near_->pos = Vec3(0.5f, 0, 15.2f); far_->pos = Vec3(8, 0, 15);
    world.AddBox(Vec3(-3, 0, 15.5f), Vec3(3, 4, 16.5f));       // rocket hits this wall
    a->AddWeapon("RocketLauncher");
    a->StartShoot(); step(g, 1.0f); a->StopShoot();
    assert(near_->hp < near_->maxHp);             // inside the 1 m radius
    assert(far_->hp == far_->maxHp);
    assert(a->hp == a->maxHp);                    // Missile skips its owner
}

static void test_grenade_hits_owner()
{
    Game g; Player *a = setup(g, GameMode::PvP);
    a->SetLook(0, 80);                            // lob almost straight up: lands on the thrower
    a->AddWeapon("GrenadeGun");
    a->StartShoot(); step(g, 3.5f); a->StopShoot();
    // GrenadeGunBullet derives from Missile, so the owner is skipped as well
    assert(a->hp == a->maxHp);
}

static void test_match_end_and_modes()
{
    Game g; Player *a = setup(g, GameMode::PvP); (void)a;
    step(g, kLevelDuration + 1);
    assert(g.matchFinished && g.matchesPlayed == 1);
    g.PlayAgain();
    assert(!g.matchFinished && g.time == 0);
    Game s; setup(s, GameMode::Sandbox);
    step(s, kLevelDuration + 1);
    assert(!s.matchFinished);                     // sandbox never ends
}

static void test_zombies()
{
    Game g; Player *a = setup(g, GameMode::ZombieSurvival);
    g.AddSpawnPoint(Vec3(12, 0, 0)); g.AddSpawnPoint(Vec3(-12, 0, 0));
    step(g, 1.2f);
    assert(g.actorCount >= 2);                    // first zombie at t = 1 s
    step(g, 90.0f);                               // keep spawning, cap at 21 non-players, wave advances
    int bots = 0; for (int i = 0; i < g.actorCount; i++) if (!g.actors[i]->IsPlayer()) bots++;
    assert(bots <= 22 && g.currentWave == 2);
    assert(!a->IsAlive());                        // nobody shoots back: zombies must eventually kill the player
    assert(a->info.deaths == 1);
}

static void test_bot_combat()
{
    Game g; Player *a = setup(g, GameMode::PvP);
    Bot *z = g.SpawnBot(3, Vec3(0, 0, 3));        // ZombieHulk: 700 hp, 40 per hit
    step(g, 6.0f);
    assert(a->hp < a->maxHp);
    a->AddWeapon("Mac10"); a->SetLook(180, 0); a->pos = Vec3(0, 0, 3.5f);
    a->Respawn(Vec3(0, 0, 8)); a->SetLook(180, 0);
    z->Damage(5000, a->id);
    assert(z->dead && g.botKills == 1 && a->info.frags == 1);
    step(g, 3.0f);
    assert(g.Find(z->id) == nullptr);             // removed after destroyingDuration
    Bot *z2 = g.SpawnBot(0, Vec3(1, 0, 1));       // slot is reusable
    assert(z2 != nullptr);
}

int main()
{
    test_data(); test_movement(); test_damage_and_kill_credit(); test_team_fight(); test_hitscan_weapon();
    test_reload(); test_shotgun_and_dual(); test_melee(); test_rocket_splash(); test_grenade_hits_owner();
    test_match_end_and_modes(); test_zombies(); test_bot_combat();
    printf("game tests OK\n");
    return 0;
}
