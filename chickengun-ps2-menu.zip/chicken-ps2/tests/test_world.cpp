// MeshWorld against the real Proto07 collision mesh.
#include <stdio.h>
#include <assert.h>
#include "../src/meshworld.h"
#include "../src/game.h"
using namespace cg;
static MeshWorld w;
int main()
{
    assert(w.Init(kProto07));
    printf("tris %d\n", w.triangleCount());
    Vec3 sp = kProto07Spawns[0];
    // ground under the spawn point
    float gy;
    assert(w.GroundAt(sp.x, sp.y + 3, sp.z, 10, gy));
    printf("spawn %.2f %.2f %.2f ground %.3f\n", sp.x, sp.y, sp.z, gy);
    // fall from 3 m and land
    Vec3 p(sp.x, gy + 3, sp.z); bool g = false; float vy = 0;
    for (int i = 0; i < 120 && !g; i++) { vy -= 20 / 60.0f; p = w.MoveCharacter(p, Vec3(0, vy / 60.0f, 0), 0.4f, 1.8f, g); }
    assert(g && fabsf(p.y - gy) < 0.01f);
    // walk in a straight line for 40 m in every direction: must never end up below the world or inside a wall
    int blocked = 0;
    for (int dir = 0; dir < 8; dir++) {
        Vec3 q(sp.x, gy, sp.z); float a = dir * 0.785398f;
        for (int i = 0; i < 400; i++) {
            Vec3 before = q;
            q = w.MoveCharacter(q, Vec3(sinf(a) * 0.09f, -0.01f, cosf(a) * 0.09f), 0.4f, 1.8f, g);
            assert(q.y > gy - 6 && q.y < gy + 10);
            (void)before;
        }
        float moved = sqrtf((q.x - sp.x) * (q.x - sp.x) + (q.z - sp.z) * (q.z - sp.z));
        if (moved < 30.0f) blocked++;
    }
    printf("directions blocked by walls before 30 m: %d / 8\n", blocked);
    assert(blocked >= 1);                       // it is a walled map
    // bullets stop at walls
    RayHit h;
    assert(w.Raycast(Vec3(sp.x, gy + 1.5f, sp.z), Vec3(sp.x, gy - 5, sp.z), h) && fabsf(h.point.y - gy) < 0.01f);
    // Game integration: a player on the mesh stays on the floor
    Game game; game.Init(&w, GameMode::PvP, 1);
    game.AddSpawnPoint(sp);
    Player *pl = game.AddPlayer(TeamID::None);
    for (int i = 0; i < 180; i++) game.Update(1.0f / 60.0f);
    assert(pl->grounded && fabsf(pl->pos.y - gy) < 0.05f);
    printf("world tests OK\n");
    return 0;
}
