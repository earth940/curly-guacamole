#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "../src/gfx.h"
#include "../src/input.h"
#include "../src/menu.h"
#include "../src/ui.h"

static int rects, texrects;
void gfx_init() {}
void gfx_begin() { rects = texrects = 0; }
void gfx_end() {}
void gfx_rect(int, int, int w, int h, unsigned) { rects++; assert(w >= 0 && h >= 0); }
void gfx_tex_rect(int t, int, int, int w, int h, int, int, int, int, unsigned) { texrects++; assert(t >= 0 && t < UI_TEX_COUNT && w >= 0 && h >= 0); }

static void press(Menu &m, unsigned b) { m.Update(b); gfx_begin(); m.Draw(false); if (m.scr != Screen::Game) assert(texrects > 0); }

int main()
{
    Menu m;
    // Shop / Servers are not available yet
    press(m, BTN_LEFT); press(m, BTN_CROSS);
    assert(m.scr == Screen::Title && m.notice > 0);
    // Settings via START: toggle vibration, leave with O
    press(m, BTN_START); assert(m.scr == Screen::Settings);
    press(m, BTN_CROSS); assert(m.cfg.vibro == 0);
    press(m, BTN_CIRCLE); assert(m.scr == Screen::Title);
    // Play -> create screen; Team fight; players clamp
    press(m, BTN_CROSS); assert(m.scr == Screen::Create);
    press(m, BTN_RIGHT); press(m, BTN_CROSS); assert(m.cfg.mode == 1);
    // map row: moving right selects an unconverted map -> refusing to start
    press(m, BTN_DOWN); press(m, BTN_RIGHT); assert(m.cfg.map == 1);
    press(m, BTN_CROSS); assert(m.scr == Screen::Create && m.notice > 0);
    press(m, BTN_LEFT); assert(m.cfg.map == 0);
    // players +/-
    press(m, BTN_DOWN); press(m, BTN_CROSS); assert(m.cfg.players == 5);
    // create -> loading -> game
    press(m, BTN_DOWN); press(m, BTN_CROSS); assert(m.scr == Screen::Loading);
    for (int i = 0; i < 100; i++) press(m, 0);
    assert(m.scr == Screen::Game);
    m.BackToTitle(); assert(m.scr == Screen::Title);
    printf("menu tests OK\n");
    return 0;
}
