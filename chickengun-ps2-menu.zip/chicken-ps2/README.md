# Chicken Gun PS2 (C++)

Меню переведено с C на C++ (`menu`, `gfx`, `input`), добавлено игровое ядро — C++-порт Unity-скриптов Chicken Gun.

| Unity (C#) | C++ |
|---|---|
| CharacterMotor, PlayerController, PlayerWeaponManager | `Player` (player.cpp) |
| BaseWeaponScript, BaseMeleeWeapon, GunInfo | `Weapon` (weapon.cpp) |
| GunBullet, Missile, GrenadeBullet, Arrow | `Bullet` (bullet.cpp) |
| BotController, ZombieManager | `Bot` (bot.cpp), `Game::UpdateZombies` |
| GameController, TeamScores | `Game` (game.cpp) |
| IDamageReciver / IDestroyable | `Actor::Damage / Heal` |

Числа (урон, патроны, скорость, HP зомби, радиусы взрывов) вытаскивает `tools/extract_data.py`
из префабов Unity в `src/data_gen.h`.

Не портировано: Photon/сеть, реклама, магазин, UI, машины/вертолёты/лошади, DOTween, ragdoll, множители урона по частям тела.

Сборка: `make` (ps2dev). Тесты на ПК без SDK: `make -C tests`.
Управление в игре: левый стик — ходьба, правый — камера, R1/R2 — огонь, X — прыжок, □ — перезарядка, L1/L2 — смена оружия, START — в меню.

Спрайт курицы: `tools/render_chicken.py` рендерит меши `rudy_SC_*` из Unity в `assets/chicken.png`, `tools/make_sprite.py` превращает его в `src/chicken_data.cpp`. Курица рисуется в меню и в игре на месте игрока.
