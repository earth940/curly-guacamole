"""Chicken (Rudy) holding the G36, posed exactly like the Unity player prefab (P_Player.prefab):
RudyContainer/TopBody/Arms/GunSystem/G35_GunSystem/{RightRudyHand,LeftRudyHand}/{Mesh, weapon_g36}.

build_parts(assets) -> list of (pos Nx3, nrm Nx3, uv Nx2, idx Mx3, kind) with every vertex already in
chicken model space (Unity axes: +x = chicken's right, +y up, +z forward), kind in {"skin", "gun"}.
"""
import os
import re
import numpy as np
from unity_mesh import load_mesh

# prefab transform ids (see Assets/Resources/P_Player.prefab)
ROOT = "4801185359639870"          # RudyContainer: its own transform is NOT part of the mesh space
HAND_R, MESH_R, GUN = "4080871621599329", "4146060405260167", "4330601936040118"
HAND_L, MESH_L = "4769501592123092", "4019654546543479"
EYE_L, EYE_R = ("39297", "rudy_SC_eye_left"), ("39650", "rudy_SC_eye_right")
TAIL_NODE, TAIL_MESH = "4959201484767577", "4985449848836751"

# The menu/third-person pose holds the gun lower and a bit further out than the first-person rig of the
# prefab: offset (x right, y up, z forward, metres) applied to both hands and the weapon.
ARM_OFFSET = np.array([0.0, -0.482, 0.0])   # = HeadSkin height: the head mesh is stored 0.482 m below the prefab frame

NUM = r"(-?[\d.]+(?:e[-+]?\d+)?|nan|inf|-inf)"


def _vec(b, key):
    m = re.search(key + r": \{x: " + NUM + ", y: " + NUM + ", z: " + NUM + r"(?:, w: " + NUM + r")?\}", b)
    return [float(x) for x in m.groups() if x is not None] if m else None


def read_transforms(prefab):
    t = open(prefab, errors="ignore").read()
    tr = {}
    for b in re.split(r"--- !u!", t)[1:]:
        m = re.match(r"(\d+) &(\d+)", b)
        if m.group(1) != "4":
            continue
        fa = re.search(r"m_Father: \{fileID: (\d+)\}", b)
        tr[m.group(2)] = dict(
            pos=_vec(b, "m_LocalPosition") or [0, 0, 0],
            rot=_vec(b, "m_LocalRotation") or [0, 0, 0, 1],
            sc=_vec(b, "m_LocalScale") or [1, 1, 1],
            father=fa.group(1) if fa else "0")
    return tr


def quat_matrix(q):
    x, y, z, w = q
    n = (x * x + y * y + z * z + w * w) ** 0.5
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def world(tr, tid):
    """4x4 matrix of node `tid` relative to RudyContainer (Unity TRS: parent * T * R * S)."""
    chain = []
    while tid != ROOT and tid in tr:
        chain.append(tr[tid])
        tid = tr[tid]["father"]
    M = np.eye(4)
    for n in reversed(chain):
        L = np.eye(4)
        L[:3, :3] = quat_matrix(n["rot"]) * np.array(n["sc"])[None, :]
        L[:3, 3] = n["pos"]
        M = M @ L
    return M


def place(mesh, M, off=None):
    R = M[:3, :3]
    if off is not None:
        M = M.copy(); M[:3, 3] += off
    pos = mesh["pos"].astype(np.float64) @ R.T + M[:3, 3]
    nrm = mesh["nrm"].astype(np.float64) @ np.linalg.inv(R).T
    nrm /= np.maximum(np.linalg.norm(nrm, axis=1, keepdims=True), 1e-9)
    tris = []
    for first, cnt, topo, bv in mesh["subs"]:
        tris.append((mesh["idx"][first:first + cnt] + bv).reshape(-1, 3))
    uv = mesh["uv"] if mesh["uv"] is not None else np.zeros((len(pos), 2))
    return pos, nrm, np.array(uv, dtype=np.float64), np.concatenate(tris)


def build_parts(assets, with_gun=True, with_tail=True):
    tr = read_transforms(os.path.join(assets, "Resources", "P_Player.prefab"))
    mdir = os.path.join(assets, "Mesh")
    L = lambda n: load_mesh(os.path.join(mdir, n + ".asset"))
    parts = []
    # head/body, beaks, comb: stored directly in model space
    parts.append(place(L("rudy_SC_body.003"), np.eye(4)) + ("skin",))
    parts.append(place(L("rudy_SC_body.006"), np.eye(4)) + ("skin",))
    # default beak = "Beak (1)" (scale 0.7, smaller than the other beak variants) and its child
    for node, mesh in (("85515", "rudy_SC_body.004"), ("06300", "rudy_SC_body.005")):
        n = [k for k in tr if k.endswith(node)][0]
        parts.append(place(L(mesh), world(tr, n), ARM_OFFSET) + ("skin",))
    if with_tail:
        parts.append(place(L("rudy_SC_Tail"), world(tr, TAIL_MESH), ARM_OFFSET) + ("skin",))
    # default eyes (Eyes/Eyes1 are the active ones in the prefab)
    for node in (EYE_L, EYE_R):
        n = [k for k in tr if k.endswith(node[0])][0]
        parts.append(place(L(node[1]), world(tr, n), ARM_OFFSET) + ("eye",))
    # both wings (hands) and the weapon, in the G36 firing pose
    parts.append(place(L("rudy_SC_body.002"), world(tr, MESH_R), ARM_OFFSET) + ("skin",))
    parts.append(place(L("rudy_SC_body.001"), world(tr, MESH_L), ARM_OFFSET) + ("skin",))
    if with_gun:
        parts.append(place(L("weapon_g36"), world(tr, GUN), ARM_OFFSET) + ("gun",))
    return parts


# first-person rigs: weapon mesh -> (weapon node, right-hand Mesh node, left-hand Mesh node), id suffixes in P_Player.prefab
WEAPON_HANDS = {
    "weapon_ak47": ("294757", "787806", "694964"),
    "weapon_deserteagle": ("741596", "200500", "495719"),
    "3_s": ("760220", "098576", "323838"),
    "weapon_sniper_rifle": ("160206", "796028", "276214"),
    "weapon_rocket_launcher": ("893261", "643762", "275705"),
    "weapon_grenade_launcher": ("136910", "918376", "440197"),
    "weapon_knife": ("886785", "939018", "741058"),
}


def weapon_hands(assets, weapon_mesh):
    """Both wings of the prefab's first-person rig for `weapon_mesh`, expressed in that weapon mesh's own space.
    Returns [(pos, nrm, uv, tris)]; right wing uses rudy_SC_body.002, left wing rudy_SC_body.001."""
    tr = read_transforms(os.path.join(assets, "Resources", "P_Player.prefab"))
    ids = lambda suf: [k for k in tr if k.endswith(suf)][0]
    wi, ri, li = (ids(x) for x in WEAPON_HANDS[weapon_mesh])
    Winv = np.linalg.inv(world(tr, wi))
    out = []
    for nid, mesh in ((ri, "rudy_SC_body.002"), (li, "rudy_SC_body.001")):
        m = load_mesh(os.path.join(assets, "Mesh", mesh + ".asset"))
        out.append(place(m, Winv @ world(tr, nid)))
    return out


# camera node ("fps cam pivots/<gun>/Camera") of each first-person rig
WEAPON_CAM = {"weapon_ak47": "883942606180071", "weapon_deserteagle": "408320199544637", "3_s": "185178391873836",
              "weapon_sniper_rifle": "227742702042468", "weapon_rocket_launcher": "540013555294609",
              "weapon_grenade_launcher": "552914680774159", "weapon_knife": "093606865046664"}


def first_person(assets, weapon_mesh):
    """Weapon + both wings exactly as the player camera sees them in the prefab: vertices in camera space
    (x right, y up, z forward, metres), so the renderer can draw them with a zero view offset.
    Returns [(pos, nrm, uv, tris, kind)] with kind 'gun' or 'skin'."""
    tr = read_transforms(os.path.join(assets, "Resources", "P_Player.prefab"))
    ids = lambda suf: [k for k in tr if k.endswith(suf)][0]
    wi, ri, li = (ids(x) for x in WEAPON_HANDS[weapon_mesh])
    Cinv = np.linalg.inv(world(tr, ids(WEAPON_CAM[weapon_mesh])))
    # rigid camera: drop its scale so the model keeps true size
    out = []
    for nid, mesh, kind in ((wi, weapon_mesh, "gun"), (ri, "rudy_SC_body.002", "skin"), (li, "rudy_SC_body.001", "skin")):
        m = load_mesh(os.path.join(assets, "Mesh", mesh + ".asset"))
        out.append(place(m, Cinv @ world(tr, nid)) + (kind,))
    return out
