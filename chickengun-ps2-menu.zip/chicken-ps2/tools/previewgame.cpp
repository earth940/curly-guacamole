// g++ -std=c++14 -O2 -Isrc tools/previewgame.cpp tools/hostgfx.cpp src/{session,menu,render3d,meshworld,assets_gen,ui,ui_data,tex_data,hud_text,world,data,weapon,bullet,player,bot,game}.cpp -o previewgame
#include <stdio.h>
#include "../src/gfx.h"
#include "../src/session.h"
#include "hostgfx.h"
static GameSession s; static MenuScene sc;
int main() {
    Menu m;
    auto shot = [&](const char *n) { gfx_begin(); m.Draw(false); gfx_end(); host_save_ppm(n); };
    sc.Update(3.0f);
    shot("/tmp/menu_title.ppm");
    m.Update(BTN_CROSS); shot("/tmp/menu_create.ppm");
    m.Update(BTN_CIRCLE); m.Update(BTN_START); shot("/tmp/menu_settings.ppm");
    GameConfig c = m.cfg; c.mode = 0; s.Start(c);
    PadState pad = {}; pad.ly = -0.0f;
    for (int i = 0; i < 120; i++) { pad.rx = 0.2f; s.Update(pad, 0, 1/60.f); }
    pad.rx = 0; pad.held = BTN_R1;
    for (int i = 0; i < 30; i++) s.Update(pad, 0, 1/60.f);
    gfx_begin(); s.Draw(); gfx_end(); host_save_ppm("/tmp/game3d.ppm");
    s.Update(pad, BTN_SQUARE, 1/60.f); s.Update(pad, BTN_DOWN, 1/60.f);
    gfx_begin(); s.Draw(); gfx_end(); host_save_ppm("/tmp/pause.ppm");
    s.Update(pad, BTN_CROSS, 1/60.f); if (!s.ExitRequested()) return 1;
    return 0;
}
