import sys, re, glob, os, math, json
sys.argv = ['x']
exec(open('tools/layout.py').read().split("if __name__")[0])
from PIL import Image, ImageDraw, ImageFont

A = 'cgsrc/chicken-gun-main/Assets/'
OUT = 'ps2out/'
os.makedirs(OUT + 'src', exist_ok=True)
S = 0.8            # canvas units -> PS2 pixels (640/800)
CH = 560.0         # canvas height in units (448/0.8)
SKIP.update({'AdsWidget','NewGameBanner','NewVersionCheckerWindow','ReviewGameWidget','SocialButtons','Viewport','Content','Log','Scroll View','Offline','CloseButton'})

# ---------- fonts ----------
metas = {}
for p in glob.glob(A + '*/*.meta'):
    m = re.search(r'^guid: (\w+)', open(p, errors='replace').read(), re.M)
    if m: metas[m.group(1)] = p[:-5]
FONT_BY_GUID = {}
def font_path(guid):
    if guid and guid in metas and metas[guid].endswith(('.ttf','.otf')): return metas[guid]
    return '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'

# ---------- gather screens ----------
SCREENS = [('MAIN','MainMenuScreen'), ('CREATE','GameCreationScreen'), ('SETTINGS','SettingsScreen'), ('LOADING','Loading')]
built = {}
for key, nm in SCREENS:
    built[key] = build(nm, 800, CH)

def sanitize(s): return re.sub(r'[^A-Za-z0-9]+', '_', s).strip('_').upper()

# ---------- sprite atlas (128x128) ----------
def sprite_crop(sprite_asset, tex_png):
    txt = open(sprite_asset, errors='replace').read()
    m = re.search(r'm_Rect:\s*serializedVersion: 2\s*x: ([\d.\-]+)\s*y: ([\d.\-]+)\s*width: ([\d.\-]+)\s*height: ([\d.\-]+)', txt)
    x, y, w, h = [float(v) for v in m.groups()]
    im = Image.open(tex_png).convert('RGBA')
    H = im.size[1]
    return im.crop((int(round(x)), int(round(H - y - h)), int(round(x + w)), int(round(H - y))))
atlas = Image.new('RGBA', (192, 128), (0,0,0,0))
SPRF = {}
FLIPSLOT = {'a747b9b6fc62f70438bafb7e0ab5cfae': (128, 0, 160, 64), 'b33cf6cba812cab428dde5f020cd139e': (128, 64, 192, 128)}
SPR = {}    # guid -> (u0,v0,u1,v1)
def rounded(size, radius):
    big = 8; im = Image.new('L', (size*big, size*big), 0)
    ImageDraw.Draw(im).rounded_rectangle((0,0,size*big-1,size*big-1), radius=radius*big, fill=255)
    im = im.resize((size, size), Image.LANCZOS)
    out = Image.new('RGBA', (size, size), (255,255,255,0)); out.putalpha(im); return out
atlas.paste(rounded(16, 4), (0, 0));     UI4 = (0,0,16,16)
atlas.paste(rounded(32, 9), (16, 0));    UI10 = (16,0,48,32)
def put(guid, slot):
    asset = metas[guid]; tex_guid = re.search(r'texture: \{fileID: \d+, guid: (\w+)', open(asset, errors='replace').read()).group(1)
    im = sprite_crop(asset, metas[tex_guid]).resize((slot[2]-slot[0], slot[3]-slot[1]), Image.LANCZOS)
    atlas.paste(im, (slot[0], slot[1])); SPR[guid] = slot
    fs = FLIPSLOT.get(guid)
    if not fs: return
    atlas.paste(im.transpose(Image.FLIP_LEFT_RIGHT), (fs[0], fs[1])); SPRF[guid] = fs
put('a747b9b6fc62f70438bafb7e0ab5cfae', (48, 0, 80, 64))     # arrow
put('faed8ddb1946f634badea31de85e34b1', (0, 64, 64, 128))    # circle
put('b33cf6cba812cab428dde5f020cd139e', (64, 64, 128, 128))  # rudy
BUILTIN = {10911: ('slice', UI4, 4), 10905: ('slice', UI10, 9), 10907: ('slice', UI10, 9), 10913: ('slice', UI10, 9)}

# ---------- background ----------
bg = Image.open('bg_160.png').convert('RGB').resize((64, 64), Image.LANCZOS)

# ---------- elements ----------
fonts_needed = {}   # (path,px) -> set(chars)
def fkey(path, px): return (path, px)
def add_chars(path, px, chars):
    fonts_needed.setdefault((path, px), set()).update(chars)

elems = {}
tags = {}
RECTS = {}
for key, nodes in built.items():
    L = []; taglist = []
    for n in nodes:
        r = n['rect']; x = r[0]*S; y = (CH - r[3])*S; w = (r[2]-r[0])*S; h = (r[3]-r[1])*S
        base = dict(x=round(x), y=round(y), w=round(w), h=round(h), tag=-1)
        if 'ctl' in n:
            taglist.append(sanitize(n['name'])); base['tag'] = len(taglist)-1
        if n['name'] in ('Checkmark','Maps') and 'image' in n: RECTS[(key, n['name'].upper())] = (round(x), round(y), round(w), round(h))
        if 'image' in n and n['name'] != 'Checkmark' and not (key == 'LOADING' and n['name'] == 'Image (1)'):
            im = n['image']; c = im['color']
            if c[3] > 0 and w > 0 and h > 0:
                e = dict(base); e['color'] = c
                if im['guid'] in SPR: e.update(kind='spr', tex=0, uv=(SPRF.get(im['guid'], SPR[im['guid']]) if n.get('flipx') else SPR[im['guid']]))
                elif im['guid'] and im['guid'].startswith('0000') and im['fid'] in BUILTIN:
                    _, uv, b = BUILTIN[im['fid']]; e.update(kind='slice', tex=0, uv=uv, border=max(2, round(b*S)))
                elif im['guid'] is None or im['fid'] == 0:
                    e.update(kind='solid')
                else:
                    print('UNRESOLVED sprite', key, n['name'], im['guid'], im['fid']); e = None
                if e: L.append(e)
        if 'text' in n and n['text']['s'].strip():
            t = n['text']; px = max(8, round(t['size']*S)); path = font_path(t['font'])
            lines = t['s'].split('\n')
            e = dict(base); e.update(kind='text', text=t['s'], color=t['color'], align=t['align'], fpath=path, px=px)
            if w == 0 and h == 0: e['align'] = 1
            ascii_all = set(chr(c) for c in range(32, 127))
            add_chars(path, px, ascii_all if px <= 17 else set(t['s']) | set('0123456789'))
            L.append(e)
    elems[key] = L; tags[key] = taglist
# dynamic texts for other screens
add_chars('/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf', 26, set('Game starts here Settings'))
LIB = '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'
for _px in (12, 14, 15): add_chars(LIB, _px, set(chr(c) for c in range(32, 127)))
for path, px in list({k for k in fonts_needed}):
    pass
json.dump({k: [dict(e, uv=None) for e in v] for k, v in elems.items()}, open('elems.json','w'), default=str, indent=0)
print({k: len(v) for k, v in elems.items()}, len(fonts_needed), 'font combos')
for k, v in sorted(fonts_needed.items(), key=lambda kv: -kv[0][1]): print(os.path.basename(k[0]), k[1], len(v))
pickle.dump((elems, tags, SPR), open('assets_state.pkl','wb'))
atlas.save('atlas_preview.png'); bg.save('bg64.png')

# ================= bake fonts =================
font_list = sorted(fonts_needed.keys(), key=lambda k: (k[0], k[1]))
FIDX = {k: i for i, k in enumerate(font_list)}
baked = []
for (path, px) in font_list:
    f = ImageFont.truetype(path, px)
    asc, desc = f.getmetrics(); lh = asc + desc
    chars = sorted(fonts_needed[(path, px)])
    glyphs = {}; X = 1; Y = 1; rowh = 0; AW = 256
    pad = 2; cells = []
    for ch in chars:
        c = ord(ch)
        if c < 32 or c > 126: continue
        im = Image.new('L', (px*2 + 8, lh + 8), 0)
        ImageDraw.Draw(im).text((pad, asc + 2), ch, font=f, fill=255, anchor='ls')
        bb = im.getbbox(); adv = round(f.getlength(ch))
        if bb:
            g = im.crop(bb); cells.append((c, g, bb[0] - pad, bb[1] - 2, adv))
        else:
            cells.append((c, None, 0, 0, adv))
    for c, g, xo, yo, adv in cells:
        if g is None: glyphs[c] = (0,0,0,0,xo,yo,adv); continue
        gw, gh = g.size
        if X + gw + 1 > AW: X = 1; Y += rowh + 1; rowh = 0
        glyphs[c] = (X, Y, gw, gh, xo, yo, adv); X += gw + 1; rowh = max(rowh, gh)
    AH = 8
    while AH < Y + rowh + 1: AH *= 2
    at = Image.new('L', (AW, AH), 0)
    for c, g, xo, yo, adv in cells:
        if g is not None: at.paste(g, glyphs[c][:2])
    baked.append(dict(path=path, px=px, asc=asc, lh=lh, glyphs=glyphs, atlas=at))
    print('font', os.path.basename(path), px, 'lh', lh, 'atlas', AW, AH)

# ================= emit C =================
def u32(r, g, b, a): return ((a*128//255) << 24) | (b << 16) | (g << 8) | r
def arr_u32(img):
    img = img.convert('RGBA'); w, h = img.size; px = list(img.getdata())
    vals = ['0x%08X' % u32(*p) for p in px]
    lines = [','.join(vals[i:i+8]) for i in range(0, len(vals), 8)]
    return ',\n'.join(lines)
def arr_u8(img):
    d = list(img.getdata()); return ',\n'.join(','.join(str(v) for v in d[i:i+32]) for i in range(0, len(d), 32))

tex_c = ['/* generated by build_assets - do not edit */', '#include "ui.h"']
tex_c.append('static const unsigned int atlas_px[%d] __attribute__((aligned(64))) = {\n%s\n};' % (192*128, arr_u32(atlas)))
tex_c.append('static const unsigned int bg_px[%d] __attribute__((aligned(64))) = {\n%s\n};' % (64*64, arr_u32(bg.convert('RGBA'))))
for i, b in enumerate(baked):
    w, h = b['atlas'].size
    tex_c.append('static const unsigned char font%d_a8[%d] = {\n%s\n};' % (i, w*h, arr_u8(b['atlas'])))
rows = ['    { atlas_px, 192, 128, 0 }', '    { bg_px, 64, 64, 0 }']
for i, b in enumerate(baked):
    w, h = b['atlas'].size; rows.append('    { font%d_a8, %d, %d, 1 }' % (i, w, h))
tex_c.append('const UiTexture ui_textures[UI_TEX_COUNT] = {\n%s\n};' % ',\n'.join(rows))
tex_c.append('const int ui_texture_count = UI_TEX_COUNT;')
open(OUT + 'src/tex_data.c', 'w').write('\n'.join(tex_c) + '\n')

# fonts table
fc = ['/* generated by build_assets - do not edit */', '#include "ui.h"']
for i, b in enumerate(baked):
    g = b['glyphs']; ents = []
    for c in range(32, 127):
        if c in g: u, v, w, h, xo, yo, adv = g[c]
        else: u = v = w = h = xo = yo = 0; adv = b['px']//2
        ents.append('{%d,%d,%d,%d,%d,%d,%d}' % (u, v, w, h, xo, yo, adv))
    fc.append('static const UiGlyph glyphs%d[95] = {%s};' % (i, ','.join(ents)))
fc.append('const UiFont ui_fonts[UI_FONT_COUNT] = {\n%s\n};' % ',\n'.join('    { %d, %d, %d, glyphs%d }' % (2+i, b['lh'], b['asc'], i) for i, b in enumerate(baked)))
# elements
def cx(c): return '0x%02X%02X%02X%02XU' % tuple(c)
def cstr(s): return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n') + '"'
for key, L in elems.items():
    rows = []
    for e in L:
        k = {'solid': 0, 'spr': 1, 'slice': 2, 'text': 3}[e['kind']]
        uv = e.get('uv') or (0,0,0,0)
        fi = FIDX[(e['fpath'], e['px'])] if e['kind'] == 'text' else 0
        rows.append('    {%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%s,%s}' % (e['x'], e['y'], e['w'], e['h'], e['tag'], k, e.get('tex', 0), e.get('align', 4), fi, e.get('border', 0), uv[0], uv[1], uv[2], uv[3], cx(e['color']), cstr(e['text']) if e['kind']=='text' else '0'))
    fc.append('const UiElem ui_%s[%d] = {\n%s\n};' % (key.lower(), len(L), ',\n'.join(rows)))
fc.append('const UiScreen ui_screens[UI_SCREEN_COUNT] = {\n%s\n};' % ',\n'.join('    { ui_%s, %d }' % (k.lower(), len(elems[k])) for k, _ in SCREENS))
open(OUT + 'src/ui_data.c', 'w').write('\n'.join(fc) + '\n')

# header
hh = ['/* generated by build_assets - do not edit */', '#ifndef UI_DATA_H', '#define UI_DATA_H']
hh.append('#define UI_FONT_COUNT %d' % len(baked)); hh.append('#define UI_TEX_COUNT %d' % (2 + len(baked)))
hh.append('#define UI_SCREEN_COUNT %d' % len(SCREENS))
for i, (k, _) in enumerate(SCREENS): hh.append('#define UI_SCR_%s %d' % (k, i))
for k, _ in SCREENS:
    for i, t in enumerate(tags[k]): hh.append('#define TAG_%s_%s %d' % (k, t, i))
def ff(path, px): return FIDX.get((LIB if path == 'LIB' else A + 'Font/' + path, px), -1)
for nm, p, px in [('LABEL15','LIB',15),('LABEL12','LIB',12),('LABEL14','LIB',14),('BTN17','9594.otf',17),('TITLE36','orange juice 2.0.ttf',36),('LABEL26','LIB',26)]:
    hh.append('#define UI_FONT_%s %d' % (nm, ff(p, px)))
for (k, nm), (rx, ry, rw, rh) in RECTS.items(): hh.append('#define RECT_%s_%s_X %d\n#define RECT_%s_%s_Y %d\n#define RECT_%s_%s_W %d\n#define RECT_%s_%s_H %d' % (k, nm, rx, k, nm, ry, k, nm, rw, k, nm, rh))
hh.append('#define UI_TEX_ATLAS 0'); hh.append('#define UI_TEX_BG 1'); hh.append('#endif')
open(OUT + 'src/ui_data.h', 'w').write('\n'.join(hh) + '\n')
print('emitted; tags:', {k: tags[k] for k in tags})
