import pickle, re, json, sys
objs = pickle.load(open('mm.pkl','rb'))
GUID = {'fe87c0e1cc204ed48ad3b37840f39efc':'Image','5f7201a12d95ffc409449d95f23cf332':'Text','4e29b1a8efbd4b44bb3f3716e73f07ff':'Button',
        '9085046f02f69544eb97fd06b6048fe2':'Toggle','d199490a83bb2b94fa5f7dd4a8a0ed5b':'InputField',
        '8a8695521f0d02e499659fee002a26c2':'Grid','30649d3a9faa99c48a7b1166b86bf2a0':'HLG','59f8146938fff824cb5fd77236b75775':'VLG',
        '306cc8c2b49d7114eaa3623786fc2126':'LayoutElement','3245ec927659c4140ac4f8d17403cc18':'CSF'}
loc = open('cgsrc/chicken-gun-main/Assets/Scripts/Assembly-CSharp/LocalizatioManager.cs').read()
en = loc.split('localizedStringsRussian')[0]
LOC = dict(re.findall(r'\{ "([^"]+)", "([^"]*)" \}', en))
names = {f:d['m_Name'] for f,(c,k,d) in objs.items() if c==1}
tr = {}
for fid,(cid,k,d) in objs.items():
    if cid in (4,224): tr[d['m_GameObject']['fileID']] = (fid,d)
def comps(g):
    out = {}
    for c in objs[g][2]['m_Component']:
        o = objs.get(c['component']['fileID'])
        if o and o[0]==114:
            n = GUID.get(o[2].get('m_Script',{}).get('guid'))
            if n: out.setdefault(n, o[2])
            if 'localizationKey' in o[2]: out['_loc'] = o[2]
    return out
def kids(g): return [objs[c['fileID']][2]['m_GameObject']['fileID'] for c in tr[g][1].get('m_Children',[])]
def col(c): return tuple(int(round(c[k]*255)) for k in 'rgba')

def rect_of(g, prect):
    """prect=(x0,y0,x1,y1) y-up. returns absolute rect honoring anchors."""
    t = tr[g][1]
    pw, ph = prect[2]-prect[0], prect[3]-prect[1]
    amin, amax, pv, sd, ap = t['m_AnchorMin'], t['m_AnchorMax'], t['m_Pivot'], t['m_SizeDelta'], t['m_AnchoredPosition']
    w = (amax['x']-amin['x'])*pw + sd['x']; h = (amax['y']-amin['y'])*ph + sd['y']
    px = prect[0] + amin['x']*pw + (amax['x']-amin['x'])*pw*pv['x'] + ap['x']
    py = prect[1] + amin['y']*ph + (amax['y']-amin['y'])*ph*pv['y'] + ap['y']
    return (px-pv['x']*w, py-pv['y']*h, px+(1-pv['x'])*w, py+(1-pv['y'])*h)

def place(g, prect, forced=None):
    return forced if forced else rect_of(g, prect)

def layout_children(g, r, kid_list):
    """compute forced rects for children of g (rect r) if it has a layout group; returns dict or None"""
    c = comps(g); res = {}
    act = [k for k in kid_list if objs[k][2]['m_IsActive']]
    if not act: return {} if ('Grid' in c or 'HLG' in c) else None
    if 'Grid' in c:
        d = c['Grid']; cs = d['m_CellSize']; sp = d['m_Spacing']; pad = d['m_Padding']
        n = len(act); cons, cnt = d['m_Constraint'], d['m_ConstraintCount']
        if cons == 2: rows = cnt; cols = -(-n//rows)
        elif cons == 1: cols = cnt; rows = -(-n//cols)
        else: cols = max(1,int((r[2]-r[0]-pad['m_Left']-pad['m_Right']+sp['x'])//(cs['x']+sp['x']))); rows = -(-n//cols)
        ncols = min(cols, n); nrows = -(-n//cols)
        tw = ncols*cs['x'] + (ncols-1)*sp['x']; th = nrows*cs['y'] + (nrows-1)*sp['y']
        al = d['m_ChildAlignment']; ax = (al%3)*0.5; ay = (al//3)*0.5  # 0 upper,1 middle,2 lower
        iw = (r[2]-r[0]) - pad['m_Left'] - pad['m_Right']; ih = (r[3]-r[1]) - pad['m_Top'] - pad['m_Bottom']
        sx = r[0] + pad['m_Left'] + (iw - tw)*ax; sy_top = r[3] - pad['m_Top'] - (ih - th)*ay
        for i,k in enumerate(act):
            cx, cy = i % cols, i // cols
            x0 = sx + cx*(cs['x']+sp['x']); y1 = sy_top - cy*(cs['y']+sp['y'])
            res[k] = (x0, y1-cs['y'], x0+cs['x'], y1)
        return res
    if 'HLG' in c:
        d = c['HLG']; pad = d['m_Padding']; sp = d['m_Spacing']; n = len(act)
        iw = (r[2]-r[0]) - pad['m_Left'] - pad['m_Right'] - sp*(n-1); ih = (r[3]-r[1]) - pad['m_Top'] - pad['m_Bottom']
        cw = iw/n if n else 0
        for i,k in enumerate(act):
            x0 = r[0] + pad['m_Left'] + i*(cw+sp)
            res[k] = (x0, r[1]+pad['m_Bottom'], x0+cw, r[1]+pad['m_Bottom']+ih)
        return res
    return None

SKIP = set()
out = []
def walk(g, prect, forced, depth, screen_dx, screen_dy, order):
    go = objs[g][2]
    if (depth>0 and not go['m_IsActive']) or go['m_Name'] in SKIP: return
    r = prect if depth==0 else (forced if forced else rect_of(g, prect))
    c = comps(g)
    node = {'name': go['m_Name'], 'rect': r, 'flipx': tr[g][1]['m_LocalScale']['x'] < 0}
    img = c.get('Image'); txt = c.get('Text')
    if img and img.get('m_Enabled',1):
        sp = img['m_Sprite']
        node['image'] = {'guid': sp.get('guid'), 'fid': sp.get('fileID'), 'type': img['m_Type'], 'color': col(img['m_Color']), 'fillCenter': img.get('m_FillCenter',1)}
    if txt and txt.get('m_Enabled',1):
        fd = txt['m_FontData']; s = txt['m_Text']
        s = '' if s is None else str(s)
        if '_loc' in c and c['_loc']['localizationKey'] in LOC: s = LOC[c['_loc']['localizationKey']]
        node['text'] = {'s': s, 'size': fd['m_FontSize'], 'align': fd['m_Alignment'], 'color': col(txt['m_Color']),
                        'font': fd['m_Font'].get('guid'), 'style': fd.get('m_FontStyle',0), 'best': fd.get('m_BestFit',0)}
    for n in ('Button','Toggle','InputField'):
        if n in c: node['ctl'] = n
    node['order'] = order[0]; order[0]+=1
    out.append(node)
    kl = kids(g)
    lay = layout_children(g, r, kl)
    for k in kl:
        walk(k, r, lay.get(k) if lay else None, depth+1, 0, 0, order)

def build(screen_name, W, H, dx=0, dy=0):
    g = [f for f,n in names.items() if n==screen_name][0]
    global out; out = []
    walk(g, (0,0,W,H), None, 0, dx, dy, [0])
    return out
if __name__=='__main__':
    W,H = 800, 560
    for s in sys.argv[1:]:
        res = build(s, W, H)
        for n in res:
            r=n['rect']; print(f"{n['name']:22s} ({r[0]:7.1f},{r[1]:7.1f})-({r[2]:7.1f},{r[3]:7.1f}) {n.get('ctl','')} {'IMG '+str(n['image']['color']) if 'image' in n else ''} {'TXT '+repr(n['text']['s']) if 'text' in n else ''}")
