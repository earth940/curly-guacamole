"""Helpers for reading Unity 2018 text-serialized assets (YAML .asset/.unity/.prefab/.mat)."""
import re, os, glob, struct
import numpy as np

FMT = {0: ("f", 4), 1: ("e", 2), 2: ("B", 1), 3: ("b", 1), 4: ("H", 2), 5: ("h", 2), 6: ("B", 1), 7: ("b", 1),
       8: ("H", 2), 9: ("h", 2), 10: ("I", 4), 11: ("i", 4)}
NORM = {2: 255.0, 3: 127.0, 4: 65535.0, 5: 32767.0}


def guid_map(assets, folder, suffix):
    d = {}
    for f in glob.glob(os.path.join(assets, folder, "*" + suffix + ".meta")):
        m = re.search(r"guid: (\w+)", open(f, errors="ignore").read())
        if m:
            d[m.group(1)] = os.path.basename(f)[: -(len(suffix) + 5)]
    return d


def yaml_blocks(path):
    t = open(path, errors="ignore").read()
    d = {}
    for b in t.split("--- !u!")[1:]:
        m = re.match(r"(\d+) &(\d+)", b)
        if m:
            d[m.group(2)] = (m.group(1), b)
    return d


def load_mesh(path):
    """Returns dict(pos, nrm, uv, col, subs=[(firstIndex,count)], idx) as numpy arrays (index topology 0 only)."""
    t = open(path, errors="ignore").read()
    n = int(re.search(r"m_VertexCount: (\d+)", t).group(1))
    j = t.index("m_Channels:")
    ch = re.findall(r"- stream: (\d+)\n\s+offset: (\d+)\n\s+format: (\d+)\n\s+dimension: (\d+)", t[j:j + 3000])[:14]
    ch = [tuple(map(int, c)) for c in ch]
    vd = bytes.fromhex(re.search(r"_typelessdata: (\w*)", t).group(1))
    # streams: laid out one after another, each aligned to 16 bytes
    nstreams = max(c[0] for c in ch if c[3]) + 1
    strides = [0] * nstreams
    for s, off, fm, dim in ch:
        if dim:
            strides[s] = max(strides[s], off + dim * FMT[fm][1])
    base, b = [], 0
    for s in range(nstreams):
        base.append(b)
        b += (strides[s] * n + 15) // 16 * 16

    def attr(i, want_dim=None):
        s, off, fm, dim = ch[i]
        if not dim:
            return None
        code, size = FMT[fm]
        out = np.zeros((n, dim), np.float32)
        for v in range(n):
            o = base[s] + v * strides[s] + off
            vals = struct.unpack("<" + code * dim, vd[o:o + size * dim])
            out[v] = vals
        if fm in NORM:
            out /= NORM[fm]
        return out

    res = dict(pos=attr(0), nrm=attr(1), col=attr(3), uv=attr(4))
    ib = bytes.fromhex(re.search(r"m_IndexBuffer: (\w+)", t).group(1))
    fmt16 = int(re.search(r"m_IndexFormat: (\d)", t).group(1)) == 0
    idx = np.frombuffer(ib, dtype="<u2" if fmt16 else "<u4").astype(np.int64)
    subs = []
    for m in re.finditer(r"firstByte: (\d+)\n\s+indexCount: (\d+)\n\s+topology: (\d+)\n\s+baseVertex: (\d+)\n\s+firstVertex: (\d+)", t):
        fb, cnt, topo, bv, fv = map(int, m.groups())
        subs.append((fb // (2 if fmt16 else 4), cnt, topo, bv))
    res["idx"], res["subs"] = idx, subs
    return res
