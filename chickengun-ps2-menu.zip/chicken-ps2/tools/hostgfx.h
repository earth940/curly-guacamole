// Software implementation of the gfx_* backend for the PC preview tool (affine UV like the GS, z-buffer).
#pragma once
void host_save_ppm(const char *path);
