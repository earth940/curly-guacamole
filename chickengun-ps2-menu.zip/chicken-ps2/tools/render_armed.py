#!/usr/bin/env python3
"""Preview: render the chicken holding the G36 (pose from P_Player.prefab).
Usage: python3 tools/render_armed.py <Assets dir> <out.png> [size] [yaw_deg] [pitch_deg]"""
import os, sys, math
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from chicken_rig import build_parts

assets, out = sys.argv[1:3]
size = int(sys.argv[3]) if len(sys.argv) > 3 else 512
yaw = math.radians(float(sys.argv[4])) if len(sys.argv) > 4 else math.radians(-25)
pitch = math.radians(float(sys.argv[5])) if len(sys.argv) > 5 else 0.0

TEX = {"skin": "rudy_SC 1", "eye": "rudy_SC 1", "gun": "militia_weapons_texture"}
tex = {k: np.array(Image.open(os.path.join(assets, "Texture2D", v + ".png")).convert("RGBA")) for k, v in TEX.items()}
parts = build_parts(assets)
allp = np.concatenate([p[0] for p in parts])
lo, hi = allp.min(0), allp.max(0)
c = (lo + hi) / 2
ext = max(hi - lo)
cy, sy_ = math.cos(yaw), math.sin(yaw)
cp, sp = math.cos(pitch), math.sin(pitch)
light = np.array([0.35, 0.6, 0.7]); light /= np.linalg.norm(light)


def xf(v, center=True):
    if center:
        v = v - c
    x = v[:, 0] * cy + v[:, 2] * sy_
    z = -v[:, 0] * sy_ + v[:, 2] * cy
    y = v[:, 1] * cp - z * sp
    z = v[:, 1] * sp + z * cp
    return np.stack([x, y, z], 1)


S = size * 3
col = np.zeros((S, S, 4), np.uint8)
zb = np.full((S, S), 1e9, np.float32)
for pos, nrm, uv, tri, kind in parts:
    T = tex[kind]; th, tw = T.shape[:2]
    P = xf(pos); N = xf(nrm, False)
    sx = S / 2 - P[:, 0] / ext * S * 0.9
    sy = S / 2 - P[:, 1] / ext * S * 0.9
    depth = -P[:, 2]
    for a, b, d in tri:
        xs = np.array([sx[a], sx[b], sx[d]]); ys = np.array([sy[a], sy[b], sy[d]])
        area = (xs[1] - xs[0]) * (ys[2] - ys[0]) - (xs[2] - xs[0]) * (ys[1] - ys[0])
        if abs(area) < 1e-6:
            continue
        x0, x1 = int(max(0, xs.min())), int(min(S - 1, xs.max()))
        y0, y1 = int(max(0, ys.min())), int(min(S - 1, ys.max()))
        if x0 > x1 or y0 > y1:
            continue
        gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        w0 = ((xs[1] - gx) * (ys[2] - gy) - (xs[2] - gx) * (ys[1] - gy)) / area
        w1 = ((xs[2] - gx) * (ys[0] - gy) - (xs[0] - gx) * (ys[2] - gy)) / area
        w2 = 1 - w0 - w1
        m = (w0 >= 0) & (w1 >= 0) & (w2 >= 0)
        if not m.any():
            continue
        z = w0 * depth[a] + w1 * depth[b] + w2 * depth[d]
        u = w0 * uv[a, 0] + w1 * uv[b, 0] + w2 * uv[d, 0]
        v = 1 - (w0 * uv[a, 1] + w1 * uv[b, 1] + w2 * uv[d, 1])
        n = w0[..., None] * N[a] + w1[..., None] * N[b] + w2[..., None] * N[d]
        n /= np.maximum(np.linalg.norm(n, axis=2, keepdims=True), 1e-6)
        shade = 0.55 + 0.45 * np.clip(n[..., 2] * light[2] - n[..., 0] * light[0] + n[..., 1] * light[1], 0, 1)
        t = T[np.clip((v * th).astype(int), 0, th - 1), np.clip((u * tw).astype(int) % tw, 0, tw - 1)]
        sub = zb[y0:y1 + 1, x0:x1 + 1]
        ok = m & (z < sub)
        sub[ok] = z[ok]
        rgb = (t[..., :3] * shade[..., None]).clip(0, 255).astype(np.uint8)
        region = col[y0:y1 + 1, x0:x1 + 1]
        region[ok, :3] = rgb[ok]; region[ok, 3] = 255

img = Image.fromarray(col, "RGBA").resize((size, size), Image.LANCZOS)
bg = Image.new("RGBA", img.size, (110, 190, 20, 255))
bg.alpha_composite(img)
bg.convert("RGB").save(out)
print("bounds", lo.round(2), hi.round(2), "->", out)
