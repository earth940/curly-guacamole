#!/usr/bin/env python3
"""Convert the Unity assets needed by the 3D port into src/assets_gen.cpp.
Usage: python3 tools/convert_assets.py <Assets dir> [out.cpp]
 * Proto07 static-batched scene mesh (world space) + submesh->texture mapping + respawn points
 * chicken player model (rudy_SC_* meshes) and the zombie/bot models (bind pose)
 * textures as 16-bit PS2 CT16 (A1B5G5R5), power-of-two, <= 256 px"""
import os, re, sys, math
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unity_mesh import load_mesh, guid_map, yaml_blocks
from chicken_rig import build_parts, first_person, WEAPON_HANDS

CHICKEN_ONLY = "--chicken-only" in sys.argv      # only rebuild kChicken inside an existing assets_gen.cpp
sys.argv = [a for a in sys.argv if a != "--chicken-only"]
assets = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else "src/assets_gen.cpp"
mat_g = guid_map(assets, "Material", ".mat")
tex_g = guid_map(assets, "Texture2D", ".png")
mesh_g = guid_map(assets, "Mesh", ".asset")

textures = []   # (name, w, h, uint16 array)
tex_index = {}
mat_by_name = {v: k for k, v in mat_g.items()}
if CHICKEN_ONLY:      # keep the texture slots of the existing file untouched
    for i, m in enumerate(re.finditer(r'^ \{"([^"]*)",\d+,\d+,tex\d+\},$', open(out).read(), re.M)):
        tex_index[m.group(1).replace("#U0421", "\u0421")] = i

def tex_for_material(guid):
    """material guid -> texture slot (or -1 for untextured)."""
    name = mat_g.get(guid)
    if not name:
        return -1
    s = open(os.path.join(assets, "Material", name + ".mat"), errors="ignore").read()
    m = re.search(r"_MainTex:\n\s+m_Texture: \{fileID: \d+, guid: (\w+)", s)
    tn = tex_g.get(m.group(1)) if m else None
    if not tn or not os.path.exists(os.path.join(assets, "Texture2D", tn + ".png")):
        return -1
    return add_texture(tn)

def add_texture(tn, maxsz=None):
    if tn in tex_index:
        return tex_index[tn]
    im = Image.open(os.path.join(assets, "Texture2D", tn + ".png")).convert("RGBA")
    big = {"SimpleApocalypse_Texture": 256, "SimpleInteriorsHouses": 256, "rudy_SC 1": 256}.get(tn, 128)
    sz = min(maxsz or big, big)
    w = h = sz
    im = im.resize((w, h), Image.LANCZOS)
    a = np.array(im).astype(np.int32)
    r, g, b, al = (a[..., 0] * 31 + 127) // 255, (a[..., 1] * 31 + 127) // 255, (a[..., 2] * 31 + 127) // 255, a[..., 3]
    px = (r | (g << 5) | (b << 10) | ((al >= 128).astype(np.int32) << 15)).astype(np.uint16)
    tex_index[tn] = len(textures)
    textures.append((tn, w, h, px.reshape(-1)))
    return tex_index[tn]

class Model:
    """Vertices + indices grouped in submeshes (one per texture)."""
    def __init__(self):
        self.pos, self.uv, self.col, self.subs = [], [], [], []
        self.idx = []
    def add(self, m, mesh_subs, texslots, world=None):
        pass

def quant(arr, scale, lim=32767):
    return np.clip(np.round(arr / scale), -lim, lim).astype(np.int64)

def emit_model(f, name, pos, uv, col, subs, idx, pscale):
    """subs: list of (firstIdx, count, tex, cx, cy, cz, radius). pos float32 Nx3, uv Nx2, col uint8 Nx3."""
    uvs = 1.0 / 256.0
    P = quant(pos, pscale); U = quant(uv, uvs)
    f.write("static const Vertex %s_v[%d] = {\n" % (name, len(P)))
    for i in range(0, len(P), 4):
        f.write(" " + ",".join("{%d,%d,%d,%d,%d,%d,%d,%d,0}" % (P[j][0], P[j][1], P[j][2], U[j][0], U[j][1],
                                                              col[j][0], col[j][1], col[j][2])
                               for j in range(i, min(i + 4, len(P)))) + ",\n")
    f.write("};\n")
    f.write("static const unsigned short %s_i[%d] = {\n" % (name, len(idx)))
    for i in range(0, len(idx), 16):
        f.write(" " + ",".join(str(v) for v in idx[i:i + 16]) + ",\n")
    f.write("};\n")
    f.write("static const SubMesh %s_s[%d] = {\n" % (name, len(subs)))
    for s in subs:
        f.write(" {%d,%d,%d,%.3ff,%.3ff,%.3ff,%.3ff},\n" % s)
    f.write("};\n")
    f.write("const Model %s = { %s_v, %d, %s_i, %d, %s_s, %d, %.8ff, %.8ff };\n\n" % (
        name, name, len(P), name, len(idx), name, len(subs), pscale, uvs))

# ---------------------------------------------------------------- Proto07
def build_scene():
    sc = yaml_blocks(os.path.join(assets, "Scenes", "Proto07.unity"))
    mesh = load_mesh(os.path.join(assets, "Mesh", "Combined Mesh (root_ scene)_1.asset"))
    sub_tex = {}
    for k, (ty, b) in sc.items():
        if ty != "23":
            continue
        go = re.search(r"m_GameObject: \{fileID: (\d+)", b).group(1)
        if go in sc and re.search(r"m_IsActive: 0", sc[go][1]):
            continue
        mats = re.findall(r"- \{fileID: \d+, guid: (\w+)", b.split("m_Materials:")[1].split("m_StaticBatchInfo")[0])
        sb = re.search(r"firstSubMesh: (\d+)\n\s+subMeshCount: (\d+)", b)
        first, cnt = int(sb.group(1)), int(sb.group(2))
        for j in range(cnt):
            sub_tex[first + j] = tex_for_material(mats[min(j, len(mats) - 1)])
    # respawn points
    spawns = []
    names = {k: re.search(r"m_Name: (.*)", b).group(1) for k, (ty, b) in sc.items() if ty == "1"}
    tfs = {}
    for k, (ty, b) in sc.items():
        if ty == "4":
            go = re.search(r"m_GameObject: \{fileID: (\d+)", b).group(1)
            pos = tuple(float(x) for x in re.search(r"m_LocalPosition: \{x: (\S+), y: (\S+), z: (\S+)\}", b).groups())
            kids = re.findall(r"- \{fileID: (\d+)\}", b.split("m_Children:")[1].split("m_Father")[0])
            tfs[k] = (go, pos, kids, re.search(r"m_Father: \{fileID: (\d+)", b).group(1))
    def world(tk):
        p = np.zeros(3)
        while tk in tfs:
            p += np.array(tfs[tk][1]); tk = tfs[tk][3]
        return p
    for tk, (go, pos, kids, fa) in tfs.items():
        if names.get(go) == "General resp points":
            for c in kids:
                if c in tfs:
                    spawns.append(world(c))
    return mesh, sub_tex, spawns

def main():
    mesh, sub_tex, spawns = build_scene()
    P, UV, COL = mesh["pos"], mesh["uv"], mesh["col"]
    scol = (np.clip(COL[:, :3], 0, 1) * 255).astype(np.int64)
    idx = mesh["idx"]
    subs_out = []
    new_idx = []
    for si, (first, cnt, topo, bv) in enumerate(mesh["subs"]):
        ii = idx[first:first + cnt] + bv
        tri = ii.reshape(-1, 3)
        pts = P[np.unique(ii)]
        c = (pts.min(0) + pts.max(0)) / 2
        r = float(np.max(np.linalg.norm(pts - c, axis=1)))
        subs_out.append((len(new_idx), cnt, sub_tex.get(si, -1), c[0], c[1], c[2], r))
        new_idx.extend(int(v) for v in ii)

    # -------- chicken + bots
    models = {}
    def pack(meshes_tex):
        pos, uv, col, subs, idxs, base = [], [], [], [], [], 0
        for m, tx in meshes_tex:
            pos.append(m["pos"]); uv.append(m["uv"] if m["uv"] is not None else np.zeros((len(m["pos"]), 2)))
            col.append(np.full((len(m["pos"]), 3), 255))
            for first, cnt, topo, bv in m["subs"]:
                ii = m["idx"][first:first + cnt] + bv + base
                subs.append([len(idxs), cnt, tx]); idxs.extend(int(v) for v in ii)
            base += len(m["pos"])
        pos = np.concatenate(pos).astype(np.float64); uv = np.concatenate(uv).astype(np.float64)
        return pos, uv, np.concatenate(col), subs, idxs

    def finish(name, pos, uv, col, subs, idxs, flipv=True, up="y", height=None, shift=None):
        if up == "z":                      # FBX bind pose lies on its back: (x,y,z) -> (x,z,-y)
            pos = np.stack([pos[:, 0], pos[:, 2], -pos[:, 1]], 1)
        if height:
            pos = pos * (height / (pos[:, 1].max() - pos[:, 1].min()))
        lo, hi = pos.min(0), pos.max(0)
        if shift is None:
            shift = np.array([(lo[0] + hi[0]) / 2, lo[1], (lo[2] + hi[2]) / 2])
        pos = pos - shift
        if flipv:
            uv = uv.copy(); uv[:, 1] = 1 - uv[:, 1]
        so = []
        for first, cnt, tx in subs:
            ii = np.array(idxs[first:first + cnt]); pts = pos[np.unique(ii)]
            c = (pts.min(0) + pts.max(0)) / 2
            so.append((first, cnt, tx, c[0], c[1], c[2], float(np.max(np.linalg.norm(pts - c, axis=1)))))
        models[name] = (pos, uv, col, so, idxs)

    # chicken: skin parts share the skin texture; wings + G36 are posed like the Unity player prefab (tools/chicken_rig.py)
    ct = add_texture("rudy_SC 1")
    gt = max(0, tex_for_material(mat_by_name["TS_militia_weapons"]))
    # the model origin stays where it was for the old wing-less chicken, so placement in the game does not change
    legacy = [load_mesh(os.path.join(assets, "Mesh", "rudy_SC_%s.asset" % p)) for p in
              ["body.001", "body.002", "body.003", "body.004", "body.005", "body.006", "Tail"]]
    lp = np.concatenate([m["pos"] for m in legacy]).astype(np.float64)
    origin = np.array([(lp[:, 0].min() + lp[:, 0].max()) / 2, lp[:, 1].min(), (lp[:, 2].min() + lp[:, 2].max()) / 2])
    pos, uv, col, subs, idxs, base = [], [], [], [], [], 0
    for ppos, pnrm, puv, ptri, kind in build_parts(assets, with_tail=False):
        pos.append(ppos); uv.append(puv); col.append(np.full((len(ppos), 3), 255))
        subs.append([len(idxs), ptri.size, gt if kind == "gun" else ct])
        idxs.extend(int(v) + base for v in ptri.reshape(-1)); base += len(ppos)
    finish("kChicken", np.concatenate(pos), np.concatenate(uv), np.concatenate(col), subs, idxs, shift=origin)

    # bots: all renderers of the prefab, bind pose
    botnames = [] if CHICKEN_ONLY else ["Cactus", "PoliceZombie", "Zkeleton", "ZombieHulk"]
    cfg = {"Cactus": ("z", 1.5), "PoliceZombie": ("z", 1.8), "Zkeleton": ("z", 1.8), "ZombieHulk": ("y", 2.6)}
    for bn in botnames:
        pf = yaml_blocks(os.path.join(assets, "Resources", "3_%s.prefab" % bn))
        mts = []
        for k, (ty, b) in pf.items():
            if ty == "137":   # SkinnedMeshRenderer
                mg = re.search(r"m_Mesh: \{fileID: \d+, guid: (\w+)", b)
                mats = re.findall(r"- \{fileID: \d+, guid: (\w+)", b.split("m_Materials:")[1].split("m_StaticBatchInfo")[0])
                if mg and mg.group(1) in mesh_g and mats:
                    mp = os.path.join(assets, "Mesh", mesh_g[mg.group(1)] + ".asset")
                    if os.path.exists(mp):
                        try:
                            mts.append((load_mesh(mp), max(0, tex_for_material(mats[0]))))
                        except Exception as e:
                            print("skip mesh", mp, e)
        if mts and bn == "PoliceZombie":   # head mesh is stored at the origin (needs its bone); keep the body
            mts = [max(mts, key=lambda t: len(t[0]["pos"]))]
            m0 = mts[0][0]["pos"]
            if m0[:, 2].max() - m0[:, 2].min() < m0[:, 1].max() - m0[:, 1].min():
                cfg[bn] = ("y", 1.8)
        if mts:
            finish("kBot_" + bn, *pack(mts), up=cfg[bn][0], height=cfg[bn][1])
            print("bot", bn, len(mts), "meshes")
        else:
            print("bot", bn, "no meshes found")

    # -------- first-person weapon models (order = starting loadout in session.cpp)
    # (mesh, material name, rotation, target length in metres); rotations send the barrel to +z, up stays +y
    ROT = {"mx": lambda p: np.stack([p[:, 2], p[:, 1], -p[:, 0]], 1),     # barrel along -x
           "px": lambda p: np.stack([-p[:, 2], p[:, 1], p[:, 0]], 1),     # barrel along +x
           "py": lambda p: np.stack([p[:, 0], -p[:, 2], p[:, 1]], 1)}     # blade along +y (knife)
    weapons = [("weapon_ak47", "TS_militia_weapons", "mx", 0.85), ("weapon_deserteagle", "TS_militia_weapons", "mx", 0.36),
               ("3_s", "3_s", "mx", 0.80), ("weapon_sniper_rifle", "ToonSoldiers_weapons", "mx", 1.10),
               ("weapon_rocket_launcher", "ToonSoldiers_weapons", "px", 1.00), ("weapon_grenade_launcher", "ToonSoldiers_weapons", "mx", 0.70),
               ("weapon_knife", "ToonSoldiers_weapons", "py", 0.45)]
    for i, (mn, matn, rot, length) in enumerate(weapons):
        tx = max(0, tex_for_material(mat_by_name[matn])) if matn in mat_by_name else 0
        # weapon + wings as seen by the prefab's first-person camera (baked: draw with zero view offset)
        pos, uv, idxs, subs = [], [], [], []
        for ppos, pnrm, puv, ptri, kind in first_person(assets, mn):
            subs.append([len(idxs), ptri.size, tx if kind == "gun" else ct])
            idxs.extend(int(v) + sum(len(q) for q in pos) for v in ptri.reshape(-1))
            pos.append(ppos); uv.append(np.array(puv, dtype=np.float64) * [1, -1] + [0, 1])
        pos = np.concatenate(pos); uv = np.concatenate(uv)
        col = np.full((len(pos), 3), 255)
        so = []
        for first, cnt, t in subs:
            ii = np.array(idxs[first:first + cnt]); pts = pos[np.unique(ii)]
            c = (pts.min(0) + pts.max(0)) / 2
            so.append((first, cnt, t, c[0], c[1], c[2], float(np.max(np.linalg.norm(pts - c, axis=1)))))
        models["kWeapon%d" % i] = (pos, uv, col, so, idxs)

    if CHICKEN_ONLY:      # replace kChicken + kWeapon0..6 inside the existing file, leave everything else as is
        import io
        src = open(out).read()
        for name in ["kChicken"] + ["kWeapon%d" % i for i in range(7)]:
            buf = io.StringIO()
            pos, uv, col, so, idxs = models[name]
            emit_model(buf, name, pos, uv, col, so, idxs, 1.0 / 1024)
            a = src.index("static const Vertex %s_v[" % name)
            b = src.index("const Model %s = " % name)
            b = src.index("\n\n", b) + 2
            src = src[:a] + buf.getvalue() + src[b:]
            print(name, len(pos), "verts", len(idxs) // 3, "tris", pos.min(0).round(2), pos.max(0).round(2))
        open(out, "w").write(src)
        return

    # position scale: choose so the largest coordinate fits in int16
    with open(out, "w") as f:
        f.write("// generated by tools/convert_assets.py - do not edit\n#include \"assets.h\"\nnamespace cg {\n\n")
        # textures
        for i, (n, w, h, px) in enumerate(textures):
            f.write("static const unsigned short tex%d[%d] __attribute__((aligned(64))) = {\n" % (i, w * h))
            for j in range(0, w * h, 16):
                f.write(" " + ",".join("%d" % v for v in px[j:j + 16]) + ",\n")
            f.write("};\n")
        f.write("const TexData kTextures[%d] = {\n" % len(textures))
        for i, (n, w, h, px) in enumerate(textures):
            f.write(' {"%s",%d,%d,tex%d},\n' % (n, w, h, i))
        f.write("};\nconst int kTextureCount = %d;\n\n" % len(textures))
        # scene
        emit_model(f, "kProto07", P, UV, scol, [(s[0], s[1], s[2], s[3], s[4], s[5], s[6]) for s in subs_out], new_idx, 1.0 / 128)
        # models
        for name, (pos, uv, col, so, idxs) in models.items():
            emit_model(f, name, pos, uv, col, so, idxs, 1.0 / 1024)
        f.write("const Vec3 kProto07Spawns[%d] = {\n" % max(1, len(spawns)))
        for s in (spawns or [np.array([0, 1, 0])]):
            f.write(" Vec3(%.3ff,%.3ff,%.3ff),\n" % tuple(s))
        f.write("};\nconst int kProto07SpawnCount = %d;\n\n" % len(spawns))
        f.write("const Model *const kBotModels[%d] = { %s };\n" % (len(botnames), ", ".join(
            ("&kBot_" + b) if ("kBot_" + b) in models else "&kChicken" for b in botnames)))
        f.write("const Model *const kWeaponModels[7] = { %s };\n" % ", ".join("&kWeapon%d" % i for i in range(7)))
        f.write("\n} // namespace cg\n")
    print("textures:", [(t[0], t[1]) for t in textures])
    print("spawns:", [tuple(round(float(v), 1) for v in s) for s in spawns])
    print("scene verts", len(P), "idx", len(new_idx), "subs", len(subs_out))
    for n, (pos, uv, col, so, idxs) in models.items():
        print(n, len(pos), "verts", len(idxs) // 3, "tris", pos.min(0).round(2), pos.max(0).round(2))

main()
