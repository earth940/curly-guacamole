#include <stdio.h>
#include <string.h>
#include <math.h>
#include "../src/gfx.h"
#include "../src/assets.h"
#include "../src/ui.h"
#include "hostgfx.h"

static unsigned char fb[SCREEN_H][SCREEN_W][3];
static float zbuf[SCREEN_H][SCREEN_W];
static bool depth_on = false;

static void px(int x, int y, unsigned r, unsigned g, unsigned b, unsigned a) {
    if (x < 0 || y < 0 || x >= SCREEN_W || y >= SCREEN_H || a == 0) return;
    for (int i = 0; i < 3; i++) { unsigned s = i == 0 ? r : i == 1 ? g : b; fb[y][x][i] = (s * a + fb[y][x][i] * (255 - a)) / 255; }
}
void gfx_init() {}
void gfx_begin() { memset(fb, 0, sizeof fb); for (auto &row : zbuf) for (float &z : row) z = 1e30f; depth_on = false; }
void gfx_end() {}
void gfx_rect(int x, int y, int w, int h, unsigned c) {
    for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) px(x + i, y + j, c >> 24, (c >> 16) & 255, (c >> 8) & 255, c & 255);
}
void gfx_tex_rect(int t, int x, int y, int w, int h, int u0, int v0, int u1, int v1, unsigned tint) {
    const UiTexture &T = ui_textures[t];
    for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) {
        int u = u0 + i * (u1 - u0) / w, v = v0 + j * (v1 - v0) / h;
        if (u < 0 || v < 0 || u >= T.w || v >= T.h) continue;
        unsigned r, g, b, a;
        if (T.fmt == 1) { r = g = b = 255; a = ((const unsigned char *)T.data)[v * T.w + u]; }
        else { unsigned p = ((const unsigned *)T.data)[v * T.w + u]; r = p & 255; g = (p >> 8) & 255; b = (p >> 16) & 255; a = ((p >> 24) & 255) * 2; if (a > 255) a = 255; }
        r = r * (tint >> 24) / 255; g = g * ((tint >> 16) & 255) / 255; b = b * ((tint >> 8) & 255) / 255; a = a * (tint & 255) / 255;
        px(x + i, y + j, r, g, b, a);
    }
}

void gfx_3d_begin() { depth_on = true; }
void gfx_3d_end() { depth_on = false; }

void gfx_tri3d(int tex, const GVert &a, const GVert &b, const GVert &c) {
    float area = (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
    if (fabsf(area) < 1e-6f) return;
    int x0 = (int)fmaxf(0, floorf(fminf(a.x, fminf(b.x, c.x)))), x1 = (int)fminf(SCREEN_W - 1, ceilf(fmaxf(a.x, fmaxf(b.x, c.x))));
    int y0 = (int)fmaxf(0, floorf(fminf(a.y, fminf(b.y, c.y)))), y1 = (int)fminf(SCREEN_H - 1, ceilf(fmaxf(a.y, fmaxf(b.y, c.y))));
    const cg::TexData *T = tex >= 0 ? &cg::kTextures[tex] : nullptr;
    for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
        float fx = x + 0.5f, fy = y + 0.5f;
        float w0 = ((b.x - fx) * (c.y - fy) - (c.x - fx) * (b.y - fy)) / area;
        float w1 = ((c.x - fx) * (a.y - fy) - (a.x - fx) * (c.y - fy)) / area;
        float w2 = 1 - w0 - w1;
        if (w0 < 0 || w1 < 0 || w2 < 0) continue;
        float z = w0 * a.z + w1 * b.z + w2 * c.z;
        if (depth_on) { if (z >= zbuf[y][x]) continue; }
        float r = w0 * a.r + w1 * b.r + w2 * c.r, g = w0 * a.g + w1 * b.g + w2 * c.g, bl = w0 * a.b + w1 * b.b + w2 * c.b;
        float tr = 1, tg = 1, tb = 1;
        if (T) {
            float u = w0 * a.u + w1 * b.u + w2 * c.u, v = w0 * a.v + w1 * b.v + w2 * c.v;
            int iu = (int)floorf(u * T->w) & (T->w - 1), iv = (int)floorf(v * T->h) & (T->h - 1);
            unsigned short t = T->px[iv * T->w + iu];
            if (!(t & 0x8000)) continue;                     // alpha bit clear = transparent
            tr = (t & 31) / 31.0f; tg = ((t >> 5) & 31) / 31.0f; tb = ((t >> 10) & 31) / 31.0f;
        }
        auto cl = [](float v) { v *= 255; return v < 0 ? 0u : v > 255 ? 255u : (unsigned)v; };
        if (depth_on) zbuf[y][x] = z;
        px(x, y, cl(tr * r), cl(tg * g), cl(tb * bl), 255);
    }
}

void host_save_ppm(const char *path) {
    FILE *f = fopen(path, "wb"); fprintf(f, "P6\n%d %d\n255\n", SCREEN_W, SCREEN_H); fwrite(fb, 1, sizeof fb, f); fclose(f);
}
