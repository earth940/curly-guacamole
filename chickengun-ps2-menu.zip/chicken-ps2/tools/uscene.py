import re, sys, yaml, pickle
src = sys.argv[1]
txt = open(src, encoding='utf-8', errors='replace').read()
parts = re.split(r'^--- !u!(\d+) &(-?\d+)(?: stripped)?\s*$', txt, flags=re.M)
objs = {}
for i in range(1, len(parts), 3):
    cid, fid, body = int(parts[i]), int(parts[i+1]), parts[i+2]
    try:
        d = yaml.load(body, Loader=yaml.CSafeLoader)
    except Exception as e:
        continue
    if not d: continue
    k = list(d.keys())[0]
    objs[fid] = (cid, k, d[k])
pickle.dump(objs, open(sys.argv[2], 'wb'))
print(len(objs), 'objects')
