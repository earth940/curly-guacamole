// g++ -std=c++14 -O2 -Isrc tools/preview3d.cpp tools/hostgfx.cpp src/{render3d,assets_gen,font_data,chicken_data}.cpp -o preview3d
#include <stdio.h>
#include <stdlib.h>
#include "../src/gfx.h"
#include "../src/render3d.h"
#include "hostgfx.h"
using namespace cg;
int main(int argc, char **argv) {
    Renderer r; Camera cam;
    float px = argc > 1 ? atof(argv[1]) : 15.6f, py = argc > 2 ? atof(argv[2]) : 3.0f, pz = argc > 3 ? atof(argv[3]) : 4.0f;
    cam.pos = Vec3(px, py, pz); cam.yaw = argc > 4 ? atof(argv[4]) : 0; cam.pitch = argc > 5 ? atof(argv[5]) : -8;
    gfx_begin();
    for (int i = 0; i < 14; i++) gfx_rect(0, i * 32, 640, 33, ((0x58 + i * 6) << 24) | ((0x98 + i * 5) << 16) | (0xE0 << 8) | 0xFF);
    gfx_3d_begin(); r.Begin(cam);
    r.DrawModel(kProto07, Vec3(0, 0, 0), 0);
    r.DrawModel(kChicken, Vec3(px + 1.5f, 0.9f, pz + 4.5f), 200);
    for (int i = 0; i < 4; i++) r.DrawModel(*kBotModels[i], Vec3(px - 4 + i * 2.6f, 0.9f, pz + 8), 180 + i * 10);
    gfx_3d_end();
    printf("tris %d culled %d subs %d\n", r.trisDrawn, r.trisCulled, r.subsDrawn);
    host_save_ppm("/tmp/p3d.ppm");
    return 0;
}
