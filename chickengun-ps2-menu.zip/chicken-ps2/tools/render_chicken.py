#!/usr/bin/env python3
"""Software-render the Unity chicken meshes (rudy_SC_*) to a PNG sprite.
Usage: python3 tools/render_chicken.py <Assets dir> <texture name> <out.png> [size] [yaw_deg]"""
import re, struct, sys, math, os
import numpy as np
from PIL import Image

assets, texname, out = sys.argv[1:4]
size = int(sys.argv[4]) if len(sys.argv) > 4 else 128
yaw = math.radians(float(sys.argv[5])) if len(sys.argv) > 5 else math.radians(-25)
PARTS = ["body.001", "body.002", "body.003", "body.004", "body.005", "body.006", "Tail"]   # eye meshes are offset in the bind pose; eyes are painted below

def load(path):
    t = open(path, errors="ignore").read()
    n = int(re.search(r"m_VertexCount: (\d+)", t).group(1))
    vd = bytes.fromhex(re.search(r"_typelessdata: (\w+)", t).group(1))
    ib = bytes.fromhex(re.search(r"m_IndexBuffer: (\w+)", t).group(1))
    stride = len(vd) // n
    assert stride == 48, stride
    v = np.frombuffer(vd, dtype="<f4").reshape(n, 12)
    idx = np.frombuffer(ib, dtype="<u2").astype(int)
    sub = re.search(r"indexCount: (\d+)", t)
    idx = idx[: int(sub.group(1))] if sub else idx
    return v[:, 0:3], v[:, 3:6], v[:, 10:12], idx.reshape(-1, 3)

tex = np.array(Image.open(os.path.join(assets, "Texture2D", texname + ".png")).convert("RGBA"))
th, tw = tex.shape[:2]
S = size * 4
col = np.zeros((S, S, 4), np.uint8)
zb = np.full((S, S), 1e9, np.float32)

meshes = []
for p in PARTS:
    f = os.path.join(assets, "Mesh", "rudy_SC_" + p + ".asset")
    if os.path.exists(f):
        meshes.append(load(f) + (p.startswith('eye'),))
allp = np.concatenate([m[0] for m in meshes])
lo, hi = allp.min(0), allp.max(0)
c = (lo + hi) / 2
ext = max(hi - lo)
cy, sy_ = math.cos(yaw), math.sin(yaw)
light = np.array([0.35, 0.6, 0.7]); light /= np.linalg.norm(light)

def xf(v):
    v = v - c
    x = v[:, 0] * cy + v[:, 2] * sy_
    z = -v[:, 0] * sy_ + v[:, 2] * cy
    return np.stack([x, v[:, 1], z], 1)

for pos, nrm, uv, tri, is_eye in meshes:
    P = xf(pos)
    N = xf(nrm + c) if False else np.stack([nrm[:, 0] * cy + nrm[:, 2] * sy_, nrm[:, 1], -nrm[:, 0] * sy_ + nrm[:, 2] * cy], 1)
    # camera at +Z looking to -Z; Unity is left-handed so x on screen = -x
    sx = (S / 2 - P[:, 0] / ext * S * 0.92)
    sy = (S / 2 - P[:, 1] / ext * S * 0.92)
    depth = -P[:, 2]
    for a, b, d in tri:
        xs = np.array([sx[a], sx[b], sx[d]]); ys = np.array([sy[a], sy[b], sy[d]])
        area = (xs[1] - xs[0]) * (ys[2] - ys[0]) - (xs[2] - xs[0]) * (ys[1] - ys[0])
        if abs(area) < 1e-6:
            continue
        x0, x1 = int(max(0, xs.min())), int(min(S - 1, xs.max()))
        y0, y1 = int(max(0, ys.min())), int(min(S - 1, ys.max()))
        if x0 > x1 or y0 > y1:
            continue
        gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        w0 = ((xs[1] - gx) * (ys[2] - gy) - (xs[2] - gx) * (ys[1] - gy)) / area
        w1 = ((xs[2] - gx) * (ys[0] - gy) - (xs[0] - gx) * (ys[2] - gy)) / area
        w2 = 1 - w0 - w1
        m = (w0 >= 0) & (w1 >= 0) & (w2 >= 0)
        if not m.any():
            continue
        z = w0 * depth[a] + w1 * depth[b] + w2 * depth[d]
        u = w0 * uv[a, 0] + w1 * uv[b, 0] + w2 * uv[d, 0]
        v = 1 - (w0 * uv[a, 1] + w1 * uv[b, 1] + w2 * uv[d, 1])
        n = w0[..., None] * N[a] + w1[..., None] * N[b] + w2[..., None] * N[d]
        n /= np.maximum(np.linalg.norm(n, axis=2, keepdims=True), 1e-6)
        shade = 0.55 + 0.45 * np.clip(-(n[..., 2] * light[2]) * -1 + n[..., 0] * -light[0] * -1 + n[..., 1] * light[1], 0, 1)
        t = tex[np.clip((v * th).astype(int), 0, th - 1), np.clip((u * tw).astype(int) % tw, 0, tw - 1)]
        if is_eye:
            t = np.broadcast_to(np.array([20, 20, 28, 255], np.uint8), t.shape); shade = np.ones_like(shade)
        sub = zb[y0:y1 + 1, x0:x1 + 1]
        ok = m & (z < sub)
        sub[ok] = z[ok]
        rgb = (t[..., :3] * shade[..., None]).clip(0, 255).astype(np.uint8)
        region = col[y0:y1 + 1, x0:x1 + 1]
        region[ok, :3] = rgb[ok]; region[ok, 3] = 255

img = Image.fromarray(col, "RGBA").resize((size, size), Image.LANCZOS)
# The eye meshes sit inside the body in the bind pose, so paint two eyes for the default 3/4 view.
from PIL import ImageDraw
d = ImageDraw.Draw(img)
k = size / 256.0
for ex, ey in ((120, 98), (166, 92)):
    ex *= k; ey *= k
    d.ellipse([(ex - 7 * k, ey - 10 * k), (ex + 7 * k, ey + 10 * k)], fill=(20, 20, 28, 255))
    d.ellipse([(ex - 3 * k, ey - 7 * k), (ex + 1 * k, ey - 3 * k)], fill=(255, 255, 255, 255))
img.save(out)
print("wrote", out, img.size)
