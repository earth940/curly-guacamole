UI data (src/ui_data.c, src/tex_data.c) is generated from the original Unity MainMenu scene
by tools/uscene.py + layout.py + build_assets.py (needs the AssetRipper export and Pillow).
The generated files are committed, so the PS2 build does not need these tools.
