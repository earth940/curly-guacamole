// Collision interface. The PS2 build plugs in the converted map collision; FlatWorld is a
// ground plane + AABBs, enough for tests and for the first playable "Proto07" box level.
#pragma once
#include "types.h"

namespace cg {

struct RayHit {
    float dist;
    Vec3 point, normal;
    int actor;   // -1 = static world, otherwise Actor::id
    RayHit() : dist(0), actor(-1) {}
};

class IWorld {
public:
    virtual ~IWorld() {}
    // Segment a->b against static geometry.
    virtual bool Raycast(const Vec3 &a, const Vec3 &b, RayHit &hit) const = 0;
    // CharacterController.Move: pos is at the feet. Returns the new position.
    virtual Vec3 MoveCharacter(const Vec3 &pos, const Vec3 &delta, float radius, float height,
                               bool &grounded) const = 0;
};

class FlatWorld : public IWorld {
public:
    struct Box { Vec3 min, max; };
    float groundY;
    int boxCount;
    Box boxes[64];

    FlatWorld() : groundY(0.0f), boxCount(0) {}
    bool AddBox(const Vec3 &mn, const Vec3 &mx) {
        if (boxCount >= 64) return false;
        boxes[boxCount].min = mn; boxes[boxCount].max = mx; boxCount++;
        return true;
    }

    bool Raycast(const Vec3 &a, const Vec3 &b, RayHit &hit) const override;
    Vec3 MoveCharacter(const Vec3 &pos, const Vec3 &delta, float radius, float height,
                       bool &grounded) const override;

private:
    bool Overlaps(const Vec3 &p, float radius, float height) const;
    float SupportY(const Vec3 &p, float radius) const;
};

} // namespace cg
