#include <stdio.h>
#include "session.h"
#include "gfx.h"
#include "ui.h"

using namespace cg;

namespace {
const GameMode kModeMap[N_MODES] = { GameMode::PvP, GameMode::TeamFight };
const float kEyeHeight = 1.45f;
}

void draw_sky()
{
    for (int i = 0; i < 14; i++) {
        unsigned r = 0x5A + i * 5, g = 0x98 + i * 4, b = 0xE0;
        gfx_rect(0, i * (SCREEN_H / 14), SCREEN_W, SCREEN_H / 14 + 1, (r << 24) | (g << 16) | (b << 8) | 0xFF);
    }
}

void GameSession::Start(const GameConfig &cfg)
{
    if (!worldReady_) worldReady_ = world_.Init(kProto07);

    GameMode mode = kModeMap[cfg.mode < 0 || cfg.mode >= N_MODES ? 0 : cfg.mode];
    game_ = Game();
    game_.Init(&world_, mode, 0xC41C4Eu);
    for (int i = 0; i < kProto07SpawnCount; i++) game_.AddSpawnPoint(kProto07Spawns[i]);

    player_ = game_.AddPlayer(mode == GameMode::TeamFight ? TeamID::TeamA : TeamID::None);
    // Starting loadout: shop unlock state is not part of the scripts, so give a mix of every weapon class.
    static const char *const kLoadout[] = { "AK47", "DesertEagle", "3S", "SSG3000", "RocketLauncher", "GrenadeGun", "Knife" };
    for (const char *g : kLoadout) player_->AddWeapon(g);
    paused_ = false; exit_ = false; pauseSel_ = 0;
    yaw_ = 90; pitch_ = 0; sens_ = 5;

    // Practice targets outside zombie mode (no other human players offline).
    {
        Vec3 c = player_->pos;
        int n = cfg.players - 1;
        if (n > 6) n = 6;
        for (int i = 0; i < n; i++) game_.SpawnBot(i % BotDefCount(), Vec3(c.x + 6.0f + 2.0f * i, 0.0f, c.z + 3.0f - 3.0f * (i % 3)));
    }
    UpdateCamera();
}

void GameSession::Update(const PadState &pad, unsigned pressed, float dt)
{
    if (!player_) return;
    Player &p = *player_;

    if (paused_) {      // pause menu: Continue / Main menu (the game keeps its state, nothing updates)
        if (pressed & (BTN_UP | BTN_DOWN)) pauseSel_ ^= 1;
        if (pressed & (BTN_SQUARE | BTN_CIRCLE | BTN_START)) paused_ = false;
        if (pressed & BTN_CROSS) { if (pauseSel_ == 0) paused_ = false; else exit_ = true; }
        return;
    }
    if (pressed & (BTN_SQUARE | BTN_START)) {
        paused_ = true; pauseSel_ = 0;
        p.SetMove(0, 0);
        if (p.isNowShooting) p.StopShoot();
        return;
    }

    if (!p.IsAlive()) {
        if (pressed & BTN_CROSS) game_.RespawnPlayer(p);
    } else {
        float rate = 40.0f + sens_ * 20.0f;                  // degrees per second at full deflection
        yaw_ += pad.rx * rate * dt;
        pitch_ += pad.ry * rate * dt;                        // stick up = look up
        p.SetLook(yaw_, pitch_);
        pitch_ = p.pitch;
        p.SetMove(pad.lx, pad.ly);

        if (pressed & BTN_CROSS) p.Jump();
        if (pressed & BTN_TRIANGLE) p.Gun().Reload();
        if (pressed & BTN_L1) p.SelectNextWeapon(-1);
        if (pressed & BTN_L2) p.SelectNextWeapon(+1);
        bool fire = (pad.held & (BTN_R1 | BTN_R2)) != 0;
        if ((pressed & (BTN_R1 | BTN_R2)) && p.isNowShooting) p.StopShoot();   // re-arm single-shot guns
        if (fire && !p.isNowShooting) p.StartShoot();
        if (!fire && p.isNowShooting) p.StopShoot();
    }
    game_.Update(dt);
    UpdateCamera();
}

// First-person camera at the chicken's eyes; also finds the point under the crosshair for aiming.
void GameSession::UpdateCamera()
{
    Player &p = *player_;
    cam_.yaw = yaw_; cam_.pitch = pitch_;
    float cp = cosf(pitch_ * 0.017453292f);
    Vec3 h = YawForward(yaw_);
    Vec3 f(h.x * cp, sinf(pitch_ * 0.017453292f), h.z * cp);
    cam_.pos = Vec3(p.pos.x, p.pos.y + kEyeHeight, p.pos.z);
    cam_.nearZ = 0.15f;

    Vec3 far = cam_.pos + f * 80.0f;
    RayHit hit;
    p.aimPoint = far;
    if (game_.RaycastAll(cam_.pos, far, hit, p.id)) p.aimPoint = hit.point;
    p.hasAim = true;
}

void GameSession::Draw()
{
    if (!player_) return;
    const Player &p = *player_;
    draw_sky();
    gfx_3d_begin();
    rend_.Begin(cam_);
    rend_.DrawModel(kProto07, Vec3(0, 0, 0), 0);
    for (int i = 0; i < game_.actorCount; i++) {
        const Actor &a = *game_.actors[i];
        if (a.IsPlayer()) {
            if (&a != player_ && a.IsAlive()) rend_.DrawModel(kChicken, a.pos, a.yaw);   // other players; own body is not drawn in first person
        } else {
            const Bot &b = static_cast<const Bot &>(a);
            float s = b.dead ? (b.destroyTimer > 0 ? b.destroyTimer / b.def->destroyDelay : 0.0f) : 1.0f;   // shrink away
            float hit = b.isAttacking ? 1.25f : 1.0f;
            if (s > 0.02f) rend_.DrawModel(*kBotModels[b.defIndex], b.pos, b.yaw, s, hit, b.dead ? 0.6f : 1.0f, b.dead ? 0.6f : 1.0f);
        }
    }
    for (int i = 0; i < kMaxBullets; i++) {
        const Bullet &b = game_.bullets[i];
        if (!b.active) continue;
        if (b.hitscan) continue;
        bool rocket = b.type == BulletType::Missile_1 || b.type == BulletType::GrenadeGunBullet;
        rend_.DrawBillboard(b.pos, rocket ? 0.35f : 0.22f, 1.0f, rocket ? 0.45f : 0.85f, 0.15f);
    }
    if (player_->IsAlive() && player_->weaponCount && player_->current < 7)   // first-person weapon
        rend_.DrawModelView(*kWeaponModels[player_->current], Vec3(0, 0, 0), 1.0f, 0.0f, 0.0f);
    gfx_3d_end();
    DrawHud();
    DrawPause();
    (void)p;
}

// HUD laid out like the original in-battle screen (Proto07 GameWindow canvas, 800x560 units -> 640x448 px):
// green health bar top-left, team icons with score and timer top-centre, gear (START) and weapon ring with ammo +
// reload top-right, crosshair in the middle, Shoot / Jump rings bottom-right (shown as pad button hints).
static void panel(int x, int y, int w, int h, unsigned c = 0x000000A0u) { ui_slice(UI_TEX_ATLAS, x, y, w, h, 3, 0, 0, 16, 16, c); }
// sprite from the HUD atlas: (u,v,uw,vh) in texels
static void hudx(int u, int v, int uw, int vh, int x, int y, int w, int h, unsigned c) { gfx_tex_rect(UI_TEX_HUD, x, y, w, h, u, v, u + uw, v + vh, c); }
// 64x64 slots: 0 crosshair, 1 ring, 2 bullet, 3 jump, 4 reload, 5 settings, 6 arrow, 7 disc, 8 red chicken, 9 blue chicken
static void hud(int slot, int x, int y, int w, int h, unsigned c) { hudx((slot % 4) * 64, (slot / 4) * 64, 64, 64, x, y, w, h, c); }
// 64x32 weapon icons, same order as the loadout
static void weaponIcon(int i, int cx, int cy, int w, unsigned c)
{
    static const int u[7] = { 0, 64, 128, 192, 0, 64, 128 }, v[7] = { 192, 192, 192, 192, 224, 224, 224 };
    hudx(u[i], v[i], 64, 32, cx - w / 2, cy - w / 4, w, w / 2, c);
}
static void button(int cx, int cy, int r, int icon)
{
    hud(1, cx - r, cy - r, 2 * r, 2 * r, 0xFFFFFFFFu);    // circle-2thin outline
    if (icon >= 0) hud(icon, cx - r * 65 / 100, cy - r * 65 / 100, r * 130 / 100, r * 130 / 100, 0xFFFFFFD8u);
}

void GameSession::DrawHud() const
{
    const Player &p = *player_;
    char buf[96];
    // Crosshair: 70x70 units, alpha 0.485
    hud(0, SCREEN_W / 2 - 28, SCREEN_H / 2 - 28, 56, 56, 0xFFFFFF7Cu);

    // health: plain green bar (RedBack, colour 0.10/0.88/0, alpha 0.86)
    float hpf = p.maxHp > 0 ? p.hp / p.maxHp : 0;
    if (hpf < 0) hpf = 0;
    if (hpf > 1) hpf = 1;
    gfx_rect(14, 22, (int)(240 * hpf), 22, 0x1AE000DBu);

    // team icons + score + timer
    hud(9, SCREEN_W / 2 - 100, 6, 56, 56, 0xFFFFFFFFu);
    hud(8, SCREEN_W / 2 + 44, 6, 56, 56, 0xFFFFFFFFu);
    int sa = game_.mode == GameMode::TeamFight ? game_.teamScores.a : p.info.frags, sb = game_.mode == GameMode::TeamFight ? game_.teamScores.b : 0;
    snprintf(buf, sizeof buf, "%d - %d", sa, sb);
    ui_text_box(UI_FONT_LABEL26, SCREEN_W / 2 - 44, 14, 88, 36, 4, 0xFFFFFFC8u, buf);
    int t = (int)game_.TimeLeft();
    snprintf(buf, sizeof buf, "%02d:%02d", t / 60, t % 60);
    ui_text_box(UI_FONT_LABEL15, SCREEN_W / 2 - 44, 50, 88, 22, 4, 0xFFFFFFB0u, buf);

    // gear = START
    hud(5, 570, 6, 44, 44, 0xFFFFFFA0u);

    // weapon ring + ammo + reload
    if (p.weaponCount) {
        const Weapon &w = p.weapons[p.current];
        button(572, 100, 46, -1);
        weaponIcon(p.current < 7 ? p.current : 0, 572, 100, 78, 0xFFFFFFFFu);
        if (w.reloading) snprintf(buf, sizeof buf, "...");
        else if (w.ammo >= 99999) snprintf(buf, sizeof buf, "-");
        else snprintf(buf, sizeof buf, "%d", w.ammo);
        ui_text_box(UI_FONT_LABEL26, 470, 142, 80, 36, 6, 0xFFFFFFFFu, buf);
        hud(2, 548, 148, 24, 24, 0xFFFFFFC0u);
        button(596, 160, 24, 4);
    }

    // Shoot / Jump rings (pad button hints)
    button(500, 300, 52, 2);   ui_text_box(UI_FONT_LABEL12, 448, 354, 104, 16, 4, 0xFFFFFFC0u, "R1 / R2");
    button(560, 390, 36, 3);   ui_text_box(UI_FONT_LABEL12, 524, 428, 72, 16, 4, 0xFFFFFFC0u, "X");
    ui_text_box(UI_FONT_LABEL12, 8, SCREEN_H - 20, 300, 16, 3, 0xFFFFFFA0u, "Triangle: reload   L1/L2: weapon   Square: menu");

    if (!p.IsAlive()) {
        panel(SCREEN_W / 2 - 150, 150, 300, 70);
        ui_text_box(UI_FONT_LABEL26, SCREEN_W / 2 - 150, 154, 300, 36, 4, 0xFFFFFFFFu, "You were killed");
        ui_text_box(UI_FONT_LABEL14, SCREEN_W / 2 - 150, 190, 300, 24, 4, 0xFFFFFFC0u, "X: respawn");
    }
    if (game_.matchFinished) ui_text_box(UI_FONT_LABEL26, 0, 130, SCREEN_W, 36, 4, 0xFFFFFFFFu, "Match finished");
}

void MenuScene::Draw(MeshWorld &world)
{
    const Vec3 c(kProto07Spawns[0].x, 1.1f, kProto07Spawns[0].z);
    float ang = t_ * 0.18f;
    Vec3 dirOut(sinf(ang), 0, cosf(ang));
    Vec3 want = c + dirOut * 5.5f + Vec3(0, 0.8f, 0);
    RayHit h;
    if (world.Raycast(c, want, h) && h.dist > 0.8f) want = c + (want - c).Normalized() * (h.dist - 0.4f);
    Camera cam;
    cam.pos = want;
    Vec3 d = c - want;
    cam.yaw = atan2f(d.x, d.z) * 57.29578f;
    cam.pitch = atan2f(d.y, sqrtf(d.x * d.x + d.z * d.z)) * 57.29578f;
    cam.fovDeg = 52.0f;

    draw_sky();
    gfx_3d_begin();
    rend_.Begin(cam);
    rend_.DrawModel(kProto07, Vec3(0, 0, 0), 0);
    Vec3 pos = c + YawRight(cam.yaw) * 1.7f;
    pos.y = 0.0f;
    rend_.DrawModel(kChicken, pos, t_ * 45.0f + 200.0f);
    gfx_3d_end();
}

// Rounded rectangle from 1px rows (corner inset follows a circle); no texture needed.
static void roundRect(int x, int y, int w, int h, int r, unsigned c)
{
    if (r * 2 > h) r = h / 2;
    if (r * 2 > w) r = w / 2;
    for (int i = 0; i < r; i++) {
        float dy = r - i - 0.5f;
        int inset = r - (int)(sqrtf((float)r * r - dy * dy) + 0.5f);
        gfx_rect(x + inset, y + i, w - 2 * inset, 1, c);
        gfx_rect(x + inset, y + h - 1 - i, w - 2 * inset, 1, c);
    }
    gfx_rect(x, y + r, w, h - 2 * r, c);
}

// Pause menu like the original: dimmed battle view, translucent rounded panel, two big rounded white buttons.
void GameSession::DrawPause() const
{
    if (!paused_) return;
    gfx_rect(0, 0, SCREEN_W, SCREEN_H, 0x00000090u);
    const int bw = 170, bh = 56, gap = 8, pw = bw + 30, ph = 2 * bh + gap + 30;
    const int px = (SCREEN_W - pw) / 2, py = (SCREEN_H - ph) / 2;
    roundRect(px, py, pw, ph, 18, 0xFFFFFF48u);
    static const char *const kItems[2] = { "Continue", "Main menu" };
    for (int i = 0; i < 2; i++) {
        int x = px + 15, y = py + 15 + i * (bh + gap);
        if (i == pauseSel_) roundRect(x - 3, y - 3, bw + 6, bh + 6, 17, 0xFFC800FFu);
        roundRect(x, y, bw, bh, 14, i == pauseSel_ ? 0xFFFFFFFFu : 0xF2F2F2F0u);
        ui_text_box(UI_FONT_LABEL15, x, y, bw, bh, 4, 0x303030FFu, kItems[i]);
    }
}
