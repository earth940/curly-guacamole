#include "gfx.h"
#include "ui.h"

static int font_for(int size)
{
    if (size <= 13) return UI_FONT_LABEL12;
    if (size <= 15) return UI_FONT_LABEL14;
    if (size <= 18) return UI_FONT_LABEL15;
    if (size <= 21) return UI_FONT_BTN17;
    if (size <= 30) return UI_FONT_LABEL26;
    return UI_FONT_TITLE36;
}
void gfx_text(int x, int y, int size, unsigned rgba, const char *s) { ui_text(font_for(size), x, y, rgba, s); }
int gfx_text_width(int size, const char *s) { return ui_text_width(font_for(size), s); }
