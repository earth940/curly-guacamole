// Collision against a triangle mesh (the Proto07 scene). Uniform XZ grid, no heap.
#pragma once
#include "world.h"
#include "assets.h"

namespace cg {

class MeshWorld : public IWorld {
public:
    static constexpr int kMaxTris = 12000;
    static constexpr int kMaxCells = 2048;
    static constexpr int kMaxRefs = 60000;

    MeshWorld() : triCount_(0), gx_(0), gz_(0), stamp_(0) {}
    // Builds the grid from every triangle of the model (vertices are already in world space).
    bool Init(const Model &m, float cellSize = 4.0f);

    bool Raycast(const Vec3 &a, const Vec3 &b, RayHit &hit) const override;
    Vec3 MoveCharacter(const Vec3 &pos, const Vec3 &delta, float radius, float height,
                       bool &grounded) const override;
    // Highest surface at or below y (within maxDrop) under (x,z); false when there is none.
    bool GroundAt(float x, float y, float z, float maxDrop, float &outY) const;

    int triangleCount() const { return triCount_; }

private:
    struct Tri { Vec3 a, b, c, n; };
    Tri tris_[kMaxTris];
    int triCount_;
    float cell_, minX_, minZ_;
    int gx_, gz_;
    int cellStart_[kMaxCells + 1];
    unsigned short refs_[kMaxRefs];
    mutable unsigned stamp_;
    mutable unsigned triStamp_[kMaxTris];

    int CellX(float x) const { int c = (int)floorf((x - minX_) / cell_); return c < 0 ? 0 : (c >= gx_ ? gx_ - 1 : c); }
    int CellZ(float z) const { int c = (int)floorf((z - minZ_) / cell_); return c < 0 ? 0 : (c >= gz_ ? gz_ - 1 : c); }
    bool RayTri(const Tri &t, const Vec3 &o, const Vec3 &d, float maxT, float &tOut) const;
    void PushOut(Vec3 &p, float centerY, float radius) const;
};

} // namespace cg
