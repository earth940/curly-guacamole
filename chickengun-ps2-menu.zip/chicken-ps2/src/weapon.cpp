// BaseWeaponScript / BaseMeleeWeapon. In Unity the fire rate and reload length come from
// Animator events (PushBullet / OnReloadFinished); here they are timers.
#include "game.h"

namespace cg {

void Weapon::Init(const GunDef *d, int owner)
{
    def = d; ownerId = owner; shooting = false; shotsFired = 0;
    cooldown_ = 0; queueIndex_ = 0;
    ResetAmmo();
}

// Seconds between shots. The Unity prefabs keep firerate at 0 for guns (animation-driven), so the
// interval is derived from the shop stats: damage dealt per trigger pull / damagePerSecond.
float Weapon::FireInterval() const
{
    float payload = def->damage;
    if (IsMelee()) payload = def->meleeDamage > 0 ? def->meleeDamage : def->damage;
    else if (def->shootType == (int)ShootType::AllAtOne) payload *= (float)def->pivots;
    float t = def->damagePerSec > 1.0f ? payload / def->damagePerSec : 0.5f;
    t = Clampf(t, 0.08f, 2.0f);
    return t > def->shootDuration ? t : def->shootDuration;
}

void Weapon::StartShooting()
{
    // CharacterMotor.StartShoot refuses while reloading or inside the shoot delay.
    if (reloading) return;
    shooting = true;
}

void Weapon::Reload()
{
    if (ammo != def->maxAmmo && !reloading) {
        reloading = true;
        reloadTimer_ = kReloadTime;
        shooting = false;          // OnReload() -> StopShooting()
    }
}

void Weapon::Update(Player &owner, float dt)
{
    if (cooldown_ > 0) cooldown_ -= dt;
    if (reloading) {
        reloadTimer_ -= dt;
        if (reloadTimer_ <= 0) {   // OnReloadFinished
            reloading = false;
            ammo = def->maxAmmo;
            if (owner.isNowShooting && def->continueAfterReload) shooting = true;
        }
        return;
    }
    if (shooting && cooldown_ <= 0) {
        PushBullet(owner);
        cooldown_ = FireInterval();
        if (!def->loopShooting) shooting = false;   // single-shot weapons fire once per press
    }
}

void Weapon::PushBullet(Player &owner)
{
    if (ammo == 0) { Reload(); return; }
    shotsFired++;
    if (IsMelee()) { MeleeHit(owner); return; }
    switch ((ShootType)def->shootType) {
    case ShootType::SingleOne: CreateBullet(owner, 0); break;
    case ShootType::AllAtOne:
        for (int i = 0; i < def->pivots; i++) CreateBullet(owner, i);
        break;
    case ShootType::ByQueue:
        CreateBullet(owner, queueIndex_ % def->pivots);
        queueIndex_++;
        break;
    }
    ammo--;
    if (ammo == 0) Reload();       // OnShootCycleEnded
}

void Weapon::CreateBullet(Player &owner, int pivotIndex)
{
    Game &g = *owner.game;
    // Muzzle pivots are not modelled; offset pairs of pivots sideways like the dual-wield guns.
    Vec3 origin = owner.EyePos();
    if (def->pivots == 2) origin += YawRight(owner.yaw) * (pivotIndex == 0 ? -0.2f : 0.2f);
    // GunInfo.errorDelta: random deviation in degrees on both axes
    Vec3 base = owner.AimDir();
    float yaw0 = atan2f(base.x, base.z) * 57.29578f, pit0 = asinf(Clampf(base.y, -1.0f, 1.0f)) * 57.29578f;
    float ex = def->errX * (g.rng.Value() - 0.5f);
    float ey = def->errY * (g.rng.Value() - 0.5f);
    float pit = pit0 + ex;
    float cp = cosf(pit * 0.017453292f);
    Vec3 f = YawForward(yaw0 + ey);
    Vec3 dir(f.x * cp, sinf(pit * 0.017453292f), f.z * cp);
    g.SpawnBullet((BulletType)def->bulletType, origin, dir, owner.id, def->damage);
}

// BaseMeleeWeapon.ApplyDamege: 1.4 m linecast from the muzzle.
void Weapon::MeleeHit(Player &owner)
{
    Game &g = *owner.game;
    Vec3 a = owner.EyePos();
    Vec3 b = a + owner.AimDir() * 1.4f;
    RayHit h;
    if (g.RaycastAll(a, b, h, owner.id) && h.actor >= 0) {
        Actor *t = g.Find(h.actor);
        if (t) t->Damage(def->meleeDamage > 0 ? def->meleeDamage : def->damage, owner.id);
    }
}

} // namespace cg
