// Basic types shared by the gameplay code. No Unity, no Photon, no STL containers:
// everything here builds with -fno-exceptions -fno-rtti on the PS2 EE toolchain.
#pragma once
#include <math.h>

namespace cg {

struct Vec3 {
    float x, y, z;
    Vec3() : x(0), y(0), z(0) {}
    Vec3(float x_, float y_, float z_) : x(x_), y(y_), z(z_) {}
    Vec3 operator+(const Vec3 &o) const { return Vec3(x + o.x, y + o.y, z + o.z); }
    Vec3 operator-(const Vec3 &o) const { return Vec3(x - o.x, y - o.y, z - o.z); }
    Vec3 operator*(float s) const { return Vec3(x * s, y * s, z * s); }
    Vec3 &operator+=(const Vec3 &o) { x += o.x; y += o.y; z += o.z; return *this; }
    float Dot(const Vec3 &o) const { return x * o.x + y * o.y + z * o.z; }
    float SqrMagnitude() const { return Dot(*this); }
    float Magnitude() const { return sqrtf(SqrMagnitude()); }
    Vec3 Normalized() const {
        float m = Magnitude();
        return m > 1e-6f ? (*this) * (1.0f / m) : Vec3();
    }
};

// Unity convention: yaw = rotation around +Y in degrees, forward at yaw 0 is +Z.
inline Vec3 YawForward(float yawDeg) {
    float r = yawDeg * 0.017453292f;
    return Vec3(sinf(r), 0.0f, cosf(r));
}
inline Vec3 YawRight(float yawDeg) {
    float r = yawDeg * 0.017453292f;
    return Vec3(cosf(r), 0.0f, -sinf(r));
}
inline float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Small deterministic RNG (replaces UnityEngine.Random).
struct Rng {
    unsigned s;
    explicit Rng(unsigned seed = 0x1234567u) : s(seed ? seed : 1u) {}
    unsigned Next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float Value() { return (Next() >> 8) * (1.0f / 16777216.0f); }   // [0,1)
    int Range(int lo, int hiExclusive) { return lo + (int)(Value() * (hiExclusive - lo)); }
};

// ---- enums copied from the Unity project ----
enum class GameMode : int { PvP = 0, TeamFight = 1, Sandbox = 2, ZombieSurvival = 3, CaptureFlag = 4,
                            BattleRoyalePvP = 5, BattleRoyaleTeams = 6 };
enum class TeamID : int { None = 0, TeamA = 1, TeamB = 2 };
enum class BulletType : int { GunBullet = 0, Missile_1 = 1, Grenade = 2, Arrow = 3, SmokeGrenade = 4,
                              MolotovGrenade = 5, BlasterBullet = 6, GrenadeGunBullet = 7 };
enum class ShootType : int { SingleOne = 0, AllAtOne = 1, ByQueue = 2 };
enum class WeaponClass : int { Gun = 0, Melee = 1 };

// ---- static data tables (filled by data_gen.h, produced from the Unity prefabs) ----
struct PlayerDef { float speed, jumpSpeed, gravity, maxFallSpeed; int maxHp; };
struct BulletDef { float speed, lifeTime, rayLength, damageRadius; };
struct GunDef {
    const char *id;
    int weaponClass;      // WeaponClass
    int bulletType;       // BulletType
    int shootType;        // ShootType
    float damage;         // per bullet / per pellet
    float damagePerSec;   // display stat from the shop; used to derive the fire interval
    float accuracy;
    float errX, errY;     // random aim error in degrees (GunInfo.errorDelta)
    float shootDuration;  // BaseWeaponScript.shootDuration (min delay between shots)
    float meleeDamage;    // BaseMeleeWeapon.damagePerHit (0 for guns)
    int maxAmmo;
    int pivots;           // number of muzzle pivots (pellets for AllAtOne)
    int loopShooting;     // automatic fire
    int continueAfterReload;
};
struct BotDef { const char *name; float hp, damagePerAttack, attackDist; int attackTypes; float destroyDelay; };

constexpr int kMaxActors = 32;
constexpr int kMaxBullets = 64;
constexpr float kDefaultDamageRadius = 5.0f;   // Missile / BaseGrenade.damageRadius
constexpr float kReloadTime = 1.6f;            // reload is animation-driven in Unity; clip length assumed
constexpr float kBotTargetPeriod = 2.0f;       // BotController.UpdateTargetPeriod
constexpr float kLevelDuration = 220.0f;       // GameConfigData.levelDuration

} // namespace cg
