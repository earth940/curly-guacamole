// GameController + ZombieManager (offline).
#include <string.h>
#include "game.h"

namespace cg {

Game::Game() : world(nullptr), mode(GameMode::PvP), time(0), levelDuration(kLevelDuration), matchFinished(false),
               matchesPlayed(0), botKills(0), actorCount(0), currentWave(0), zombieClock(0), our_(nullptr),
               spawnCount_(0), zombieSpawnTimer_(1.0f), playerStoreUsed_(0), nextId_(1)
{
    teamScores.a = teamScores.b = 0;
    for (int i = 0; i < kMaxActors; i++) actors[i] = nullptr;
}

void Game::Init(IWorld *w, GameMode m, unsigned seed)
{
    world = w; mode = m; rng = Rng(seed);
    time = 0; matchFinished = false; matchesPlayed = 0; botKills = 0;
    teamScores.a = teamScores.b = 0;
    actorCount = 0; our_ = nullptr; spawnCount_ = 0; playerStoreUsed_ = 0; nextId_ = 1;
    currentWave = 0; zombieClock = 0; zombieSpawnTimer_ = 1.0f;     // InvokeRepeating("CreateZombie", 1, period)
    for (int i = 0; i < kMaxBullets; i++) bullets[i].active = false;
    for (int i = 0; i < kMaxActors; i++) botStore_[i].id = -1;
}

void Game::AddSpawnPoint(const Vec3 &p) { if (spawnCount_ < kMaxSpawns) spawns_[spawnCount_++] = p; }

Vec3 Game::PickSpawn()
{
    if (spawnCount_ == 0) return Vec3(0, 0, 0);
    return spawns_[rng.Range(0, spawnCount_)];
}

Player *Game::AddPlayer(TeamID team)
{
    if (playerStoreUsed_ >= 8 || actorCount >= kMaxActors) return nullptr;
    Player *p = &playerStore_[playerStoreUsed_++];
    *p = Player();
    p->Init(this, nextId_++, team, &GetPlayerDef());
    p->pos = PickSpawn();
    actors[actorCount++] = p;
    if (!our_) our_ = p;                     // first player is the local one (GameController.OurPlayer)
    return p;
}

Bot *Game::SpawnBot(int defIndex, const Vec3 &at)
{
    if (actorCount >= kMaxActors || defIndex < 0 || defIndex >= BotDefCount()) return nullptr;
    for (int i = 0; i < kMaxActors; i++) {
        if (botStore_[i].id == -1) {
            botStore_[i] = Bot();
            botStore_[i].Init(this, nextId_++, GetBotDef(defIndex), at);
            botStore_[i].defIndex = defIndex;
            actors[actorCount++] = &botStore_[i];
            return &botStore_[i];
        }
    }
    return nullptr;
}

Actor *Game::Find(int id) const
{
    for (int i = 0; i < actorCount; i++) if (actors[i]->id == id) return actors[i];
    return nullptr;
}

// ---- scoring (GameController.OnPlayerKilled generalised to every player) ----
void Game::OnPlayerKilled(Player &victim)
{
    victim.HandleMyDeath();
    for (int i = 0; i < actorCount; i++) {
        Actor *a = actors[i];
        if (!a->IsPlayer() || a == &victim) continue;
        Player *p = static_cast<Player *>(a);
        if (victim.lastKillerId == p->id) { p->AddScore(10); p->HandleMakeKill(); }
        else if (victim.IsThisIdKillerAssist(p->id)) { p->AddScore(3); p->HandleMakeKillAssist(); }
    }
}

void Game::OnBotKilled(Bot &, int killerId)
{
    botKills++;
    Actor *k = Find(killerId);
    if (k && k->IsPlayer()) static_cast<Player *>(k)->HandleMakeKill();
}

void Game::AddTeamScore(int score, TeamID team)
{
    if (mode != GameMode::TeamFight) return;
    if (team == TeamID::TeamA) teamScores.a += score;
    else if (team == TeamID::TeamB) teamScores.b += score;
}

bool Game::IsFriendlyFire(int attackerId, const Actor &victim) const
{
    if (mode != GameMode::TeamFight) return false;
    Actor *a = Find(attackerId);
    return a && a->IsPlayer() && a->team == victim.team;
}

void Game::RespawnPlayer(Player &p) { p.Respawn(PickSpawn()); }

void Game::PlayAgain()
{
    time = 0; matchFinished = false;
    teamScores.a = teamScores.b = 0;
    for (int i = 0; i < kMaxBullets; i++) bullets[i].active = false;
    for (int i = 0; i < actorCount; i++)
        if (actors[i]->IsPlayer()) {
            Player *p = static_cast<Player *>(actors[i]);
            p->info.deaths = p->info.assists = p->info.score = p->info.frags = 0;
            p->Respawn(PickSpawn());
        }
}

// ---- combat queries ----

// Segment vs. vertical cylinder (actor capsule approximation): intersect circle and height slabs.
static bool SegmentCylinder(const Vec3 &a, const Vec3 &b, const Actor &t, float &tOut)
{
    Vec3 d = b - a;
    float t0 = 0.0f, t1 = 1.0f;
    float dx = a.x - t.pos.x, dz = a.z - t.pos.z;
    float A = d.x * d.x + d.z * d.z, B = 2.0f * (dx * d.x + dz * d.z), C = dx * dx + dz * dz - t.radius * t.radius;
    if (A < 1e-9f) { if (C > 0) return false; }
    else {
        float disc = B * B - 4 * A * C;
        if (disc < 0) return false;
        float s = sqrtf(disc);
        float r0 = (-B - s) / (2 * A), r1 = (-B + s) / (2 * A);
        if (r0 > t0) t0 = r0;
        if (r1 < t1) t1 = r1;
        if (t0 > t1) return false;
    }
    float lo = t.pos.y, hi = t.pos.y + t.height;
    if (fabsf(d.y) < 1e-9f) { if (a.y < lo || a.y > hi) return false; }
    else {
        float y0 = (lo - a.y) / d.y, y1 = (hi - a.y) / d.y;
        if (y0 > y1) { float x = y0; y0 = y1; y1 = x; }
        if (y0 > t0) t0 = y0;
        if (y1 < t1) t1 = y1;
        if (t0 > t1) return false;
    }
    tOut = t0;
    return true;
}

bool Game::RaycastAll(const Vec3 &a, const Vec3 &b, RayHit &hit, int ignoreActor) const
{
    RayHit best;
    bool found = false;
    if (world && world->Raycast(a, b, best)) { found = true; best.actor = -1; }
    Vec3 d = b - a;
    float len = d.Magnitude();
    for (int i = 0; i < actorCount; i++) {
        Actor *t = actors[i];
        if (t->id == ignoreActor || !t->IsAlive()) continue;
        float tt;
        if (SegmentCylinder(a, b, *t, tt)) {
            float dist = tt * len;
            if (!found || dist < best.dist) {
                found = true;
                best.dist = dist; best.actor = t->id; best.point = a + d * tt;
                best.normal = (best.point - t->Center()).Normalized();
            }
        }
    }
    if (found) hit = best;
    return found;
}

void Game::DamageInRadius(const Vec3 &c, float radius, float dmg, int fromWhom, bool hitOwner)
{
    for (int i = 0; i < actorCount; i++) {
        Actor *t = actors[i];
        if (!t->IsAlive()) continue;
        if (t->id == fromWhom && !hitOwner) continue;
        float hx = t->pos.x - c.x, hz = t->pos.z - c.z;
        float hd = sqrtf(hx * hx + hz * hz) - t->radius;
        if (hd < 0) hd = 0;
        float cy = Clampf(c.y, t->pos.y, t->pos.y + t->height) - c.y;
        if (hd * hd + cy * cy <= radius * radius) t->Damage(dmg, fromWhom);
    }
}

// ---- zombie survival ----
void Game::CreateZombie()
{
    int alive = 0;
    for (int i = 0; i < actorCount; i++) if (!actors[i]->IsPlayer()) alive++;
    if (alive > 20) return;
    Vec3 at = PickSpawn();
    static const float chances[4] = { 3, 3, 3, 1 };      // every wave in ZombieManager uses these
    float sum = 0; for (int i = 0; i < 4; i++) sum += chances[i];
    float v = rng.Value(), acc = chances[0] / sum;
    int idx = 0;
    for (int k = 0; k < 3; k++) {
        if (v > acc) idx = k + 1;
        acc += chances[k + 1] / sum;
    }
    if (idx > BotDefCount() - 1) idx = BotDefCount() - 1;
    SpawnBot(idx, at);
}

void Game::UpdateZombies(float dt)
{
    zombieClock += dt;
    currentWave = (int)(zombieClock / 40.0f);            // 12 waves x 40 s; the last one repeats
    if (currentWave > 11) currentWave = 11;
    zombieSpawnTimer_ -= dt;
    if (zombieSpawnTimer_ <= 0.0f) { zombieSpawnTimer_ += 6.0f; CreateZombie(); }   // spawnPeriod = 6 s
}

void Game::CollectGarbage()
{
    int w = 0;
    for (int i = 0; i < actorCount; i++) {
        Actor *a = actors[i];
        if (!a->IsPlayer() && static_cast<Bot *>(a)->destroyed) { a->id = -1; continue; }   // frees the slot
        actors[w++] = a;
    }
    for (int i = w; i < actorCount; i++) actors[i] = nullptr;
    actorCount = w;
}

void Game::Update(float dt)
{
    if (matchFinished) return;
    time += dt;
    if (mode == GameMode::ZombieSurvival) UpdateZombies(dt);
    for (int i = 0; i < actorCount; i++) actors[i]->Update(dt);
    for (int i = 0; i < kMaxBullets; i++) bullets[i].Update(*this, dt);
    for (int i = 0; i < actorCount; i++)             // fell out of the map: back to a spawn point
        if (actors[i]->IsPlayer() && actors[i]->pos.y < -30.0f) static_cast<Player *>(actors[i])->Respawn(PickSpawn());
    CollectGarbage();
    // CheckMatchEndTime: Sandbox and survival modes never end by time
    if (mode != GameMode::Sandbox && mode != GameMode::ZombieSurvival && mode != GameMode::BattleRoyalePvP &&
        mode != GameMode::BattleRoyaleTeams && time >= levelDuration) {
        matchFinished = true; matchesPlayed++;
        for (int i = 0; i < actorCount; i++) if (actors[i]->IsPlayer()) static_cast<Player *>(actors[i])->StopShoot();
    }
}

} // namespace cg
