#include <stdio.h>
#include "menu.h"
#include "gfx.h"
#include "input.h"

const char *MODE_NAMES[N_MODES] = { "Deathmatch", "Team fight", "Sandbox" };
const char *MAP_NAMES[N_MAPS] = { "Proto07", "Lava", "RaceTrack1", "House",
                                  "ChaloHouse", "Dungeons", "Dust2", "SmallTown" };
unsigned maps_ready = 0x01;   /* only Proto07 for now */

#define LOADING_FRAMES 90

static int item_count(Screen s)
{
    switch (s) {
    case SCR_TITLE:    return 3;            /* Play, Settings, Multiplayer */
    case SCR_MODE:     return N_MODES + 1;  /* modes + Back */
    case SCR_MAP:      return N_MAPS + 1;   /* maps + Back */
    case SCR_SETTINGS: return 4;            /* music, sfx, sensitivity, Back */
    default:           return 0;
    }
}

static void go(Menu *m, Screen s) { m->scr = s; m->sel = 0; m->timer = 0; }

static void say(Menu *m, const char *t) { m->notice_text = t; m->notice = 120; }

void menu_init(Menu *m)
{
    m->scr = SCR_TITLE; m->sel = 0; m->timer = 0; m->notice = 0; m->notice_text = "";
    m->cfg.mode = 0; m->cfg.map = 0; m->cfg.music = 7; m->cfg.sfx = 8; m->cfg.sens = 5;
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

void menu_update(Menu *m, unsigned p)
{
    int n = item_count(m->scr);
    if (m->notice > 0) m->notice--;
    m->timer++;

    if (m->scr == SCR_LOADING) {
        if (m->timer >= LOADING_FRAMES) go(m, SCR_GAME);
        return;
    }
    if (m->scr == SCR_GAME) {
        if (p & (BTN_CIRCLE | BTN_START)) go(m, SCR_TITLE);
        return;
    }

    if (p & BTN_UP)   m->sel = (m->sel + n - 1) % n;
    if (p & BTN_DOWN) m->sel = (m->sel + 1) % n;

    if (p & BTN_CIRCLE) {
        if (m->scr == SCR_MODE || m->scr == SCR_SETTINGS) go(m, SCR_TITLE);
        else if (m->scr == SCR_MAP) go(m, SCR_MODE);
        return;
    }

    if (m->scr == SCR_SETTINGS && m->sel < 3 && (p & (BTN_LEFT | BTN_RIGHT))) {
        int d = (p & BTN_RIGHT) ? 1 : -1;
        int *v = m->sel == 0 ? &m->cfg.music : m->sel == 1 ? &m->cfg.sfx : &m->cfg.sens;
        *v = clampi(*v + d, 0, 10);
        return;
    }

    if (!(p & (BTN_CROSS | BTN_START))) return;

    switch (m->scr) {
    case SCR_TITLE:
        if (m->sel == 0) go(m, SCR_MODE);
        else if (m->sel == 1) go(m, SCR_SETTINGS);
        else say(m, "Multiplayer: not available yet");
        break;
    case SCR_MODE:
        if (m->sel == N_MODES) go(m, SCR_TITLE);
        else { m->cfg.mode = m->sel; go(m, SCR_MAP); }
        break;
    case SCR_MAP:
        if (m->sel == N_MAPS) go(m, SCR_MODE);
        else if (maps_ready & (1u << m->sel)) { m->cfg.map = m->sel; go(m, SCR_LOADING); }
        else say(m, "This map is not converted yet");
        break;
    case SCR_SETTINGS:
        if (m->sel == 3) go(m, SCR_TITLE);
        break;
    default: break;
    }
}

/* ---------- drawing ---------- */

#define COL_TEXT   0xFFFFFFFFu
#define COL_DIM    0x8890A0FFu
#define COL_ACCENT 0xFFB020FFu
#define COL_BAR    0x3A5CA8FFu

static void draw_bg(void)
{
    int i;
    for (i = 0; i < 14; i++) {  /* vertical gradient in bands */
        unsigned r = 0x14 + i * 3, g = 0x1C + i * 4, b = 0x38 + i * 6;
        gfx_rect(0, i * (SCREEN_H / 14), SCREEN_W, SCREEN_H / 14 + 1,
                 (r << 24) | (g << 16) | (b << 8) | 0xFF);
    }
}

static void draw_centered(int y, int size, unsigned col, const char *s)
{
    gfx_text((SCREEN_W - gfx_text_width(size, s)) / 2, y, size, col, s);
}

static void draw_item(int idx, const Menu *m, const char *label, int enabled)
{
    int y = 150 + idx * 30, sel = (idx == m->sel);
    if (sel) gfx_rect(140, y - 4, 360, 28, COL_BAR);
    draw_centered(y, 20, !enabled ? COL_DIM : (sel ? COL_ACCENT : COL_TEXT), label);
}

static void draw_bar(int idx, const Menu *m, const char *name, int val)
{
    char buf[48];
    int y = 150 + idx * 30, sel = (idx == m->sel), i;
    if (sel) gfx_rect(140, y - 4, 360, 28, COL_BAR);
    gfx_text(150, y, 20, sel ? COL_ACCENT : COL_TEXT, name);
    for (i = 0; i < 10; i++)
        gfx_rect(300 + i * 18, y + 2, 14, 16, i < val ? COL_ACCENT : 0x20283CFF);
    snprintf(buf, sizeof buf, "%d", val);
    gfx_text(486, y, 20, COL_TEXT, buf);
}

void menu_draw(const Menu *m)
{
    char buf[96];
    int i;
    draw_bg();

    if (m->scr == SCR_LOADING) {
        draw_centered(190, 28, COL_TEXT, "Loading...");
        snprintf(buf, sizeof buf, "%s - %s", MODE_NAMES[m->cfg.mode], MAP_NAMES[m->cfg.map]);
        draw_centered(230, 20, COL_DIM, buf);
        gfx_rect(170, 280, 300, 12, 0x20283CFF);
        gfx_rect(170, 280, 300 * m->timer / LOADING_FRAMES, 12, COL_ACCENT);
        return;
    }
    if (m->scr == SCR_GAME) {
        draw_centered(170, 28, COL_TEXT, "Game starts here");
        snprintf(buf, sizeof buf, "%s on %s", MODE_NAMES[m->cfg.mode], MAP_NAMES[m->cfg.map]);
        draw_centered(215, 20, COL_ACCENT, buf);
        draw_centered(260, 16, COL_DIM, "(gameplay not implemented yet)");
        draw_centered(400, 16, COL_DIM, "O: back to menu");
        return;
    }

    draw_centered(36, 48, COL_ACCENT, "CHICKEN GUN");
    draw_centered(92, 16, COL_DIM, "PS2 port - work in progress");

    switch (m->scr) {
    case SCR_TITLE:
        draw_item(0, m, "Play", 1);
        draw_item(1, m, "Settings", 1);
        draw_item(2, m, "Multiplayer", 0);
        break;
    case SCR_MODE:
        draw_centered(120, 20, COL_TEXT, "Select game mode");
        for (i = 0; i < N_MODES; i++) draw_item(i, m, MODE_NAMES[i], 1);
        draw_item(N_MODES, m, "Back", 1);
        break;
    case SCR_MAP:
        draw_centered(120, 20, COL_TEXT, "Select map");
        for (i = 0; i < N_MAPS; i++) draw_item(i, m, MAP_NAMES[i], (maps_ready >> i) & 1);
        draw_item(N_MAPS, m, "Back", 1);
        break;
    case SCR_SETTINGS:
        draw_centered(120, 20, COL_TEXT, "Settings");
        draw_bar(0, m, "Music", m->cfg.music);
        draw_bar(1, m, "Sound", m->cfg.sfx);
        draw_bar(2, m, "Sensitivity", m->cfg.sens);
        draw_item(3, m, "Back", 1);
        break;
    default: break;
    }
    if (m->notice > 0) draw_centered(400, 16, COL_ACCENT, m->notice_text);
    else draw_centered(400, 16, COL_DIM, "X: select   O: back   D-pad: move");
}
