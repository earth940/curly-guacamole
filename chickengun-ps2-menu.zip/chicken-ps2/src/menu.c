#include <stdio.h>
#include <string.h>
#include "menu.h"
#include "gfx.h"
#include "input.h"
#include "ui.h"

const char *MODE_NAMES[N_MODES] = { "Deathmatch", "Team fight" };
const char *MAP_NAMES[N_MAPS] = { "Proto07", "Lava", "RaceTrack1", "House",
                                  "ChaloHouse", "Dungeons", "Dust2", "SmallTown" };
unsigned maps_ready = 0x01;   /* only Proto07 for now */

#define LOADING_FRAMES 90

/* focus ids on the "new game" screen (first six are the tags from the original scene) */
#define SEL_BACK   TAG_CREATE_BACKBUTTON
#define SEL_DM     TAG_CREATE_DEATHMATCH
#define SEL_TEAM   TAG_CREATE_TEAM_FIGHT
#define SEL_CREATE TAG_CREATE_CREATEBUTTON
#define SEL_PLUS   TAG_CREATE_PLUS
#define SEL_MINUS  TAG_CREATE_MNUS
#define SEL_MAPS   6

#define COL_FOCUS  0xFFFFFFFFu
#define COL_CHOSEN 0xFFC800FFu

static void say(Menu *m, const char *t) { m->notice_text = t; m->notice = 120; }
static void go(Menu *m, Screen s, int sel) { m->scr = s; m->sel = sel; m->timer = 0; }
static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

void menu_init(Menu *m)
{
    m->scr = SCR_TITLE; m->sel = TAG_MAIN_PLAYTEAMBATTLE; m->timer = 0; m->notice = 0; m->notice_text = "";
    m->cfg.mode = 0; m->cfg.map = 0; m->cfg.players = 6; m->cfg.vibro = 1;
}

static int row_of(int sel)
{
    switch (sel) {
    case SEL_BACK: return 0;
    case SEL_DM: case SEL_TEAM: return 1;
    case SEL_MAPS: return 2;
    case SEL_MINUS: case SEL_PLUS: return 3;
    default: return 4;
    }
}

static int row_first(const Menu *m, int row)
{
    switch (row) {
    case 0: return SEL_BACK;
    case 1: return m->cfg.mode == 0 ? SEL_DM : SEL_TEAM;
    case 2: return SEL_MAPS;
    case 3: return SEL_MINUS;
    default: return SEL_CREATE;
    }
}

static void update_title(Menu *m, unsigned p)
{
    if (p & (BTN_LEFT | BTN_UP))    m->sel = (m->sel + 2) % 3;
    if (p & (BTN_RIGHT | BTN_DOWN)) m->sel = (m->sel + 1) % 3;
    if (p & BTN_START) { go(m, SCR_SETTINGS, 0); return; }
    if (!(p & BTN_CROSS)) return;
    if (m->sel == TAG_MAIN_PLAYTEAMBATTLE) go(m, SCR_CREATE, row_first(m, 1));
    else if (m->sel == TAG_MAIN_SHOP) say(m, "Shop is not available yet");
    else say(m, "Servers: not available yet");
}

static void update_create(Menu *m, unsigned p)
{
    int r = row_of(m->sel);
    if (p & BTN_CIRCLE) { go(m, SCR_TITLE, TAG_MAIN_PLAYTEAMBATTLE); return; }
    if (p & BTN_UP)   { r = (r + 4) % 5; m->sel = row_first(m, r); }
    if (p & BTN_DOWN) { r = (r + 1) % 5; m->sel = row_first(m, r); }
    if (p & (BTN_LEFT | BTN_RIGHT)) {
        int d = (p & BTN_RIGHT) ? 1 : -1;
        if (r == 1) m->sel = d > 0 ? SEL_TEAM : SEL_DM;
        else if (r == 2) m->cfg.map = clampi(m->cfg.map + d, 0, N_MAPS - 1);
        else if (r == 3) m->sel = d > 0 ? SEL_PLUS : SEL_MINUS;
    }
    if (!(p & (BTN_CROSS | BTN_START))) return;
    switch (m->sel) {
    case SEL_BACK: go(m, SCR_TITLE, TAG_MAIN_PLAYTEAMBATTLE); break;
    case SEL_DM: m->cfg.mode = 0; break;
    case SEL_TEAM: m->cfg.mode = 1; break;
    case SEL_MINUS: m->cfg.players = clampi(m->cfg.players - 1, MIN_PLAYERS, MAX_PLAYERS); break;
    case SEL_PLUS: m->cfg.players = clampi(m->cfg.players + 1, MIN_PLAYERS, MAX_PLAYERS); break;
    case SEL_MAPS:
    case SEL_CREATE:
        if (maps_ready & (1u << m->cfg.map)) { if (m->sel == SEL_CREATE) go(m, SCR_LOADING, 0); }
        else say(m, "This map is not converted yet");
        break;
    default: break;
    }
}

static void update_settings(Menu *m, unsigned p)
{
    if (p & (BTN_UP | BTN_DOWN | BTN_LEFT | BTN_RIGHT)) m->sel = 1 - m->sel;
    if (p & BTN_CIRCLE) { go(m, SCR_TITLE, TAG_MAIN_PLAYTEAMBATTLE); return; }
    if (p & (BTN_CROSS | BTN_START)) {
        if (m->sel == TAG_SETTINGS_VIBROTOGGLE) m->cfg.vibro = !m->cfg.vibro;
        else go(m, SCR_TITLE, TAG_MAIN_PLAYTEAMBATTLE);
    }
}

void menu_update(Menu *m, unsigned p)
{
    if (m->notice > 0) m->notice--;
    m->timer++;
    switch (m->scr) {
    case SCR_TITLE:    update_title(m, p); break;
    case SCR_CREATE:   update_create(m, p); break;
    case SCR_SETTINGS: update_settings(m, p); break;
    case SCR_LOADING:
        if (p & (BTN_CIRCLE | BTN_CROSS)) { go(m, SCR_CREATE, SEL_CREATE); break; }   /* Cancel */
        if (m->timer >= LOADING_FRAMES) go(m, SCR_GAME, 0);
        break;
    case SCR_GAME:
        if (p & (BTN_CIRCLE | BTN_START)) go(m, SCR_TITLE, TAG_MAIN_PLAYTEAMBATTLE);
        break;
    }
}

/* ---------- drawing ---------- */

static char players_buf[8];
static const char *subst(int screen, const UiElem *e)
{
    if (screen == UI_SCR_CREATE && e->text && !strcmp(e->text, "6")) return players_buf;
    if (screen == UI_SCR_MAIN && e->text && !strcmp(e->text, "0.0")) return "0.1";
    return 0;
}

static void draw_maps(const Menu *m, int focused)
{
    int cw = 142, ch = 93, pad = 2, first, i, shown = (RECT_CREATE_MAPS_W - 2 * pad) / cw;
    first = m->cfg.map - (shown - 1);
    first = clampi(first, 0, N_MAPS - shown);
    for (i = 0; i < shown; i++) {
        int idx = first + i, x = RECT_CREATE_MAPS_X + pad + i * cw, y = RECT_CREATE_MAPS_Y + 0;
        int ready = (maps_ready >> idx) & 1;
        UiElem box;
        ui_slice(UI_TEX_ATLAS, x + 3, y + 3, cw - 6, ch - 6, 3, 0, 0, 16, 16, ready ? 0xFFFFFFC8u : 0xFFFFFF60u);
        ui_text_box(UI_FONT_LABEL15, x, y, cw, ch, 4, ready ? 0x323232FFu : 0x32323290u, MAP_NAMES[idx]);
        if (idx == m->cfg.map) {
            box.x = x + 3; box.y = y + 3; box.w = cw - 6; box.h = ch - 6;
            ui_outline(&box, 0, focused ? 3 : 2, focused ? COL_FOCUS : COL_CHOSEN);
        }
    }
}

void menu_draw(const Menu *m)
{
    char buf[96];
    const UiElem *e;
    gfx_tex_rect(UI_TEX_BG, 0, 0, SCREEN_W, SCREEN_H, 0, 0, 64, 64, 0xFFFFFFFFu);
    snprintf(players_buf, sizeof players_buf, "%d", m->cfg.players);

    switch (m->scr) {
    case SCR_TITLE:
        ui_draw_screen(UI_SCR_MAIN, subst);
        e = ui_find_tag(UI_SCR_MAIN, m->sel);
        if (e) ui_outline(e, 1, 2, COL_FOCUS);
        break;
    case SCR_CREATE:
        ui_draw_screen(UI_SCR_CREATE, subst);
        e = ui_find_tag(UI_SCR_CREATE, m->cfg.mode == 0 ? SEL_DM : SEL_TEAM);
        if (e) ui_outline(e, 0, 2, COL_CHOSEN);
        draw_maps(m, m->sel == SEL_MAPS);
        if (m->sel != SEL_MAPS && (e = ui_find_tag(UI_SCR_CREATE, m->sel)) != 0) ui_outline(e, 1, 2, COL_FOCUS);
        break;
    case SCR_SETTINGS: {
        UiElem box;
        ui_draw_screen(UI_SCR_SETTINGS, subst);
        box.x = RECT_SETTINGS_CHECKMARK_X; box.y = RECT_SETTINGS_CHECKMARK_Y;
        box.w = RECT_SETTINGS_CHECKMARK_W; box.h = RECT_SETTINGS_CHECKMARK_H;
        if (m->cfg.vibro) gfx_rect(box.x, box.y, box.w, box.h, 0x323232FFu);
        if (m->sel == TAG_SETTINGS_VIBROTOGGLE) { box.x -= 4; box.y -= 4; box.w += 8; box.h += 8; ui_outline(&box, 0, 2, COL_FOCUS); }
        else if ((e = ui_find_tag(UI_SCR_SETTINGS, TAG_SETTINGS_BACKBUTTON)) != 0) ui_outline(e, 1, 2, COL_FOCUS);
        break; }
    case SCR_LOADING:
        ui_draw_screen(UI_SCR_LOADING, subst);
        snprintf(buf, sizeof buf, "%s - %s", MODE_NAMES[m->cfg.mode], MAP_NAMES[m->cfg.map]);
        ui_text_box(UI_FONT_LABEL15, 0, 212, SCREEN_W, 24, 4, 0x323232FFu, buf);
        gfx_rect(170, 244, 300, 8, 0x32323240u);
        gfx_rect(170, 244, 300 * m->timer / LOADING_FRAMES, 8, 0x32323290u);
        if ((e = ui_find_tag(UI_SCR_LOADING, TAG_LOADING_CANCELBUTTON)) != 0) ui_outline(e, 1, 2, 0x323232FFu);
        break;
    case SCR_GAME:
        ui_text_box(UI_FONT_LABEL26, 0, 170, SCREEN_W, 40, 4, 0xFFFFFFFFu, "Game starts here");
        snprintf(buf, sizeof buf, "%s on %s", MODE_NAMES[m->cfg.mode], MAP_NAMES[m->cfg.map]);
        ui_text_box(UI_FONT_LABEL15, 0, 215, SCREEN_W, 30, 4, 0xFFFFFFFFu, buf);
        ui_text_box(UI_FONT_LABEL14, 0, 255, SCREEN_W, 30, 4, 0xFFFFFFC0u, "(gameplay not implemented yet)");
        ui_text_box(UI_FONT_LABEL14, 0, 400, SCREEN_W, 24, 4, 0xFFFFFFC0u, "O: back to menu");
        break;
    }
    if (m->notice > 0) ui_text_box(UI_FONT_LABEL14, 0, m->scr == SCR_CREATE ? 340 : 365, SCREEN_W, 24, 4, 0xFFFFFFFFu, m->notice_text);
    else if (m->scr == SCR_TITLE) ui_text_box(UI_FONT_LABEL12, 0, 365, SCREEN_W, 24, 4, 0xFFFFFFC0u, "D-pad: move   X: select   START: settings");
    else if (m->scr != SCR_GAME && m->scr != SCR_LOADING) ui_text_box(UI_FONT_LABEL12, 0, m->scr == SCR_CREATE ? 340 : 400, SCREEN_W, 20, 4, 0xFFFFFFC0u, "D-pad: move   X: select   O: back");
}
