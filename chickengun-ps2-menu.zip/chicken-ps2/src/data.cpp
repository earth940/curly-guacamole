#include <string.h>
#include "game.h"
#include "data_gen.h"

namespace cg {

const GunDef *FindGun(const char *id)
{
    for (unsigned i = 0; i < sizeof(kGuns) / sizeof(kGuns[0]); i++)
        if (strcmp(kGuns[i].id, id) == 0) return &kGuns[i];
    return nullptr;
}
int GunCount() { return (int)(sizeof(kGuns) / sizeof(kGuns[0])); }
int BotDefCount() { return (int)(sizeof(kBots) / sizeof(kBots[0])); }
const BotDef *GetBotDef(int i) { return &kBots[i]; }
const PlayerDef &GetPlayerDef() { return kPlayerDef; }
const BulletDef &GetBulletDef(BulletType t) { return kBullets[(int)t]; }

} // namespace cg
