#pragma once
// Glue between the menu and the gameplay core: Proto07 collision + 3D third-person view, and the 3D menu backdrop.
#include "game.h"
#include "input.h"
#include "menu.h"
#include "meshworld.h"
#include "render3d.h"

class GameSession {
public:
    void Start(const GameConfig &cfg);
    void Update(const PadState &pad, unsigned pressed, float dt);
    void Draw();
    bool ExitRequested() const { return exit_; }   // "Main menu" chosen in the pause menu

    cg::Game &game() { return game_; }
    cg::Player *player() { return player_; }
    const cg::Camera &camera() const { return cam_; }
    cg::MeshWorld &world() { return world_; }

private:
    cg::MeshWorld world_;
    bool worldReady_ = false;
    cg::Game game_;
    cg::Player *player_ = nullptr;
    cg::Renderer rend_;
    cg::Camera cam_;
    int sens_ = 5;
    bool paused_ = false, exit_ = false;
    int pauseSel_ = 0;
    float yaw_ = 0, pitch_ = 0;
    void UpdateCamera();
    void DrawHud() const;
    void DrawPause() const;
};

// Rotating chicken in front of a slowly orbiting Proto07 view, drawn behind the menu.
class MenuScene {
public:
    void Update(float dt) { t_ += dt; }
    void Draw(cg::MeshWorld &world);
private:
    float t_ = 0;
    cg::Renderer rend_;
};

void draw_sky();
