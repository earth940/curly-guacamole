#include <string.h>
#include <tamtypes.h>
#include <gsKit.h>
#include <dmaKit.h>
#include <gsToolkit.h>
#include "gfx.h"

extern const unsigned int font_atlas[];   /* generated: tools/make_font.py */
#define FONT_W 256
#define FONT_H 128
#define FONT_CELL 16

static GSGLOBAL *gs;
static GSTEXTURE font_tex;

static u64 col(unsigned c)
{
    return GS_SETREG_RGBAQ((c >> 24) & 255, (c >> 16) & 255, (c >> 8) & 255,
                           ((c & 255) * 128) / 255, 0);
}

void gfx_init(void)
{
    gs = gsKit_init_global();
    gs->ZBuffering = GS_SETTING_OFF;
    gs->DoubleBuffering = GS_SETTING_ON;
    gs->PrimAlphaEnable = GS_SETTING_ON;

    dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC,
                D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1 << DMA_CHANNEL_GIF);
    dmaKit_chan_init(DMA_CHANNEL_GIF);

    gsKit_init_screen(gs);
    gsKit_mode_switch(gs, GS_ONESHOT);

    memset(&font_tex, 0, sizeof font_tex);
    font_tex.Width = FONT_W;
    font_tex.Height = FONT_H;
    font_tex.PSM = GS_PSM_CT32;
    font_tex.Mem = (void *)font_atlas;
    font_tex.Filter = GS_FILTER_NEAREST;
    font_tex.Vram = gsKit_vram_alloc(gs, gsKit_texture_size(FONT_W, FONT_H, GS_PSM_CT32),
                                     GSKIT_ALLOC_USERBUFFER);
    gsKit_texture_upload(gs, &font_tex);
}

void gfx_begin(void) { gsKit_clear(gs, GS_SETREG_RGBAQ(0, 0, 0, 0x80, 0)); }

void gfx_end(void)
{
    gsKit_queue_exec(gs);
    gsKit_sync_flip(gs);
}

void gfx_rect(int x, int y, int w, int h, unsigned rgba)
{
    gsKit_prim_sprite(gs, x, y, x + w, y + h, 1, col(rgba));
}

/* glyph advance is size*5/8 (proportional-ish fixed pitch); atlas is 16x6 cells of 16px */
static int adv(int size) { return size * 5 / 8; }

int gfx_text_width(int size, const char *s) { return (int)strlen(s) * adv(size); }

void gfx_text(int x, int y, int size, unsigned rgba, const char *s)
{
    for (; *s; s++, x += adv(size)) {
        int c = (unsigned char)*s - 32;
        if (c <= 0 || c >= 96) continue;
        {
            int u = (c % 16) * FONT_CELL, v = (c / 16) * FONT_CELL;
            gsKit_prim_sprite_texture(gs, &font_tex, x, y, u, v,
                                      x + size, y + size, u + FONT_CELL, v + FONT_CELL,
                                      2, col(rgba));
        }
    }
}
