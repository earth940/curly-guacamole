#include <string.h>
#include <malloc.h>
#include <tamtypes.h>
#include <gsKit.h>
#include <dmaKit.h>
#include <gsToolkit.h>
#include "gfx.h"
#include "ui.h"

static GSGLOBAL *gs;
static GSTEXTURE tex[UI_TEX_COUNT];

static u64 col(unsigned c)
{
    return GS_SETREG_RGBAQ((c >> 24) & 255, (c >> 16) & 255, (c >> 8) & 255,
                           ((c & 255) * 128) / 255, 0);
}

static void load_textures(void)
{
    int i;
    for (i = 0; i < ui_texture_count; i++) {
        const UiTexture *t = &ui_textures[i];
        void *mem = (void *)t->data;
        memset(&tex[i], 0, sizeof tex[i]);
        if (t->fmt == 1) {              /* A8 mask -> white RGBA32, alpha 0..128 */
            unsigned *px = (unsigned *)memalign(64, (size_t)t->w * t->h * 4);
            const unsigned char *src = (const unsigned char *)t->data;
            int n = t->w * t->h, k;
            if (!px) continue;
            for (k = 0; k < n; k++) px[k] = ((unsigned)(src[k] * 128 / 255) << 24) | 0x00FFFFFFu;
            mem = px;
        }
        tex[i].Width = t->w;
        tex[i].Height = t->h;
        tex[i].PSM = GS_PSM_CT32;
        tex[i].Mem = mem;
        tex[i].Filter = (t->fmt == 1) ? GS_FILTER_NEAREST : GS_FILTER_LINEAR;
        tex[i].Vram = gsKit_vram_alloc(gs, gsKit_texture_size(t->w, t->h, GS_PSM_CT32),
                                       GSKIT_ALLOC_USERBUFFER);
        gsKit_texture_upload(gs, &tex[i]);
    }
}

void gfx_init(void)
{
    gs = gsKit_init_global();
    gs->ZBuffering = GS_SETTING_OFF;
    gs->DoubleBuffering = GS_SETTING_ON;
    gs->PrimAlphaEnable = GS_SETTING_ON;

    dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC,
                D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1 << DMA_CHANNEL_GIF);
    dmaKit_chan_init(DMA_CHANNEL_GIF);

    gsKit_init_screen(gs);
    gsKit_mode_switch(gs, GS_ONESHOT);
    load_textures();
}

void gfx_begin(void) { gsKit_clear(gs, GS_SETREG_RGBAQ(0, 0, 0, 0x80, 0)); }

void gfx_end(void)
{
    gsKit_queue_exec(gs);
    gsKit_sync_flip(gs);
}

void gfx_rect(int x, int y, int w, int h, unsigned rgba)
{
    gsKit_prim_sprite(gs, x, y, x + w, y + h, 1, col(rgba));
}

void gfx_tex_rect(int t, int x, int y, int w, int h, int u0, int v0, int u1, int v1, unsigned rgba)
{
    gsKit_prim_sprite_texture(gs, &tex[t], x, y, u0, v0, x + w, y + h, u1, v1, 2, col(rgba));
}
