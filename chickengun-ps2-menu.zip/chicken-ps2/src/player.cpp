// CharacterMotor (movement, damage, death, score) + PlayerWeaponManager.
#include <string.h>
#include "game.h"

namespace cg {

Player::Player() : def(nullptr), moveX(0), moveY(0), pitch(0), hasAim(false), vertVelocity(0), timeInAir(0), grounded(true),
                   jumpFrames(0), lastShootTime(-100), isNowShooting(false), weaponCount(0), current(0),
                   lastDamagerId(-1), lastKillerId(-1), damagerCount(0)
{
    info.deaths = info.assists = info.score = info.frags = 0;
    radius = 0.4f; height = 1.8f;
}

void Player::Init(Game *g, int actorId, TeamID t, const PlayerDef *d)
{
    game = g; id = actorId; team = t; def = d;
    maxHp = (float)d->maxHp; hp = maxHp;
    weaponCount = 0; current = 0;
    info.deaths = info.assists = info.score = info.frags = 0;
    damagerCount = 0; lastDamagerId = lastKillerId = -1;
}

bool Player::AddWeapon(const char *gunId)
{
    const GunDef *d = FindGun(gunId);
    if (!d || weaponCount >= kMaxWeapons) return false;
    for (int i = 0; i < weaponCount; i++) if (weapons[i].def == d) return true;   // already owned
    weapons[weaponCount].Init(d, id);
    weaponCount++;
    return true;
}

void Player::SelectWeapon(int index)
{
    if (weaponCount == 0 || index < 0 || index >= weaponCount) return;
    Gun().StopShooting();          // HideCurrentGun
    current = index;
    if (isNowShooting) Gun().StartShooting();
}

void Player::SelectNextWeapon(int sign)
{
    if (weaponCount == 0) return;
    int i = current + sign;
    if (i < 0) i = weaponCount - 1; else if (i > weaponCount - 1) i = 0;   // same wrap as PlayerWeaponManager
    SelectWeapon(i);
}

Vec3 Player::AimDir() const
{
    if (hasAim) {
        Vec3 d = aimPoint - EyePos();
        if (d.SqrMagnitude() > 1e-4f) return d.Normalized();
    }
    float cp = cosf(pitch * 0.017453292f);
    Vec3 f = YawForward(yaw);
    return Vec3(f.x * cp, sinf(pitch * 0.017453292f), f.z * cp);
}

void Player::StartShoot()
{
    if (!IsAlive() || weaponCount == 0) return;
    Weapon &w = Gun();
    if (isNowShooting || w.reloading) return;
    if (game->time - lastShootTime < w.def->shootDuration) return;
    isNowShooting = true;
    lastShootTime = game->time;
    w.StartShooting();
}

void Player::StopShoot()
{
    isNowShooting = false;
    if (weaponCount) Gun().StopShooting();
}

void Player::Damage(float val, int fromWhom)
{
    if (!IsAlive()) return;                                   // DamageRPC ignores hp == 0
    if (game->IsFriendlyFire(fromWhom, *this)) return;        // TeamFight: no damage from teammates
    bool known = false;
    for (int i = 0; i < damagerCount; i++) if (damagers[i] == fromWhom) known = true;
    if (!known && damagerCount < kMaxActors) damagers[damagerCount++] = fromWhom;
    lastDamagerId = fromWhom;
    hp -= val;
    if (hp < 0) hp = 0;
    if (hp == 0) { lastKillerId = lastDamagerId; Die(); }     // UpdateHP -> OnDie
}

void Player::Heal(float val)
{
    if (!IsAlive()) return;
    hp += val;
    if (hp > maxHp) hp = maxHp;
}

void Player::Die()
{
    StopShoot();
    if (weaponCount) Gun().ResetAmmo();
    moveX = moveY = 0;
    game->OnPlayerKilled(*this);
}

void Player::Respawn(const Vec3 &at)
{
    pos = at; hp = maxHp;
    vertVelocity = 0; timeInAir = 0; grounded = false;
    damagerCount = 0; lastDamagerId = -1;
    for (int i = 0; i < weaponCount; i++) weapons[i].ResetAmmo();
}

bool Player::IsThisIdKillerAssist(int damagerId) const
{
    for (int i = 0; i < damagerCount; i++) if (damagers[i] == damagerId) return true;
    return false;
}

void Player::AddScore(int score)
{
    info.score += score;
    game->AddTeamScore(score, team);
}

void Player::Update(float dt)
{
    if (!IsAlive()) return;

    if (weaponCount) Gun().Update(*this, dt);

    // JumpCRT: waits up to 10 frames for the ground, then launches
    if (jumpFrames > 0) {
        if (grounded) { vertVelocity = def->jumpSpeed; grounded = false; jumpFrames = 0; }
        else jumpFrames--;
    }

    // CalcVerticalSpeed
    if (grounded) {
        timeInAir = 0;
        if (vertVelocity < -1.0f) vertVelocity = 0;
    } else {
        timeInAir += dt;
    }
    vertVelocity -= def->gravity * dt;
    if (vertVelocity < -def->maxFallSpeed) vertVelocity = -def->maxFallSpeed;

    // Move: local input -> world direction * speed, plus vertical velocity
    float mx = moveX, my = moveY;
    float m = sqrtf(mx * mx + my * my);
    if (m > 1.0f) { mx /= m; my /= m; }
    Vec3 dir = YawRight(yaw) * mx + YawForward(yaw) * my;
    Vec3 vel = dir * def->speed;
    vel.y = vertVelocity;
    pos = game->world->MoveCharacter(pos, vel * dt, radius, height, grounded);
}

} // namespace cg
