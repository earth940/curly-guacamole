#include "meshworld.h"

namespace cg {

static Vec3 Cross(const Vec3 &a, const Vec3 &b) { return Vec3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }

// Closest point on triangle abc to p (Ericson, Real-Time Collision Detection).
static Vec3 ClosestOnTri(const Vec3 &p, const Vec3 &a, const Vec3 &b, const Vec3 &c)
{
    Vec3 ab = b - a, ac = c - a, ap = p - a;
    float d1 = ab.Dot(ap), d2 = ac.Dot(ap);
    if (d1 <= 0 && d2 <= 0) return a;
    Vec3 bp = p - b;
    float d3 = ab.Dot(bp), d4 = ac.Dot(bp);
    if (d3 >= 0 && d4 <= d3) return b;
    float vc = d1 * d4 - d3 * d2;
    if (vc <= 0 && d1 >= 0 && d3 <= 0) return a + ab * (d1 / (d1 - d3));
    Vec3 cp = p - c;
    float d5 = ab.Dot(cp), d6 = ac.Dot(cp);
    if (d6 >= 0 && d5 <= d6) return c;
    float vb = d5 * d2 - d1 * d6;
    if (vb <= 0 && d2 >= 0 && d6 <= 0) return a + ac * (d2 / (d2 - d6));
    float va = d3 * d6 - d5 * d4;
    if (va <= 0 && (d4 - d3) >= 0 && (d5 - d6) >= 0) return b + (c - b) * ((d4 - d3) / ((d4 - d3) + (d5 - d6)));
    float denom = 1.0f / (va + vb + vc);
    return a + ab * (vb * denom) + ac * (vc * denom);
}

bool MeshWorld::Init(const Model &m, float cellSize)
{
    cell_ = cellSize;
    triCount_ = 0;
    float minx = 1e30f, minz = 1e30f, maxx = -1e30f, maxz = -1e30f;
    const float s = m.posScale;
    for (int si = 0; si < m.subCount; si++) {
        const SubMesh &sm = m.subs[si];
        for (unsigned i = sm.firstIndex; i + 2 < sm.firstIndex + sm.indexCount; i += 3) {
            if (triCount_ >= kMaxTris) return false;
            Tri &t = tris_[triCount_];
            const Vertex *v[3] = { &m.verts[m.idx[i]], &m.verts[m.idx[i + 1]], &m.verts[m.idx[i + 2]] };
            t.a = Vec3(v[0]->x * s, v[0]->y * s, v[0]->z * s);
            t.b = Vec3(v[1]->x * s, v[1]->y * s, v[1]->z * s);
            t.c = Vec3(v[2]->x * s, v[2]->y * s, v[2]->z * s);
            Vec3 n = Cross(t.b - t.a, t.c - t.a);
            float l = n.Magnitude();
            if (l < 1e-8f) continue;                       // degenerate
            t.n = n * (1.0f / l);
            // Unity front faces are clockwise: with this cross-product formula the normal points to the *front*
            // side; flip so that n is the outward normal as used below.
            t.n = t.n * -1.0f;
            const Vec3 *pts[3] = { &t.a, &t.b, &t.c };
            for (int k = 0; k < 3; k++) {
                if (pts[k]->x < minx) minx = pts[k]->x;
                if (pts[k]->x > maxx) maxx = pts[k]->x;
                if (pts[k]->z < minz) minz = pts[k]->z;
                if (pts[k]->z > maxz) maxz = pts[k]->z;
            }
            triCount_++;
        }
    }
    minX_ = minx - 0.01f; minZ_ = minz - 0.01f;
    gx_ = (int)((maxx - minX_) / cell_) + 1;
    gz_ = (int)((maxz - minZ_) / cell_) + 1;
    while (gx_ * gz_ > kMaxCells) { cell_ *= 1.5f; gx_ = (int)((maxx - minX_) / cell_) + 1; gz_ = (int)((maxz - minZ_) / cell_) + 1; }

    // two passes: count, then fill (CSR)
    static int counts[kMaxCells + 1];
    for (int i = 0; i <= gx_ * gz_; i++) counts[i] = 0;
    for (int pass = 0; pass < 2; pass++) {
        for (int t = 0; t < triCount_; t++) {
            const Tri &tr = tris_[t];
            float x0 = tr.a.x < tr.b.x ? (tr.a.x < tr.c.x ? tr.a.x : tr.c.x) : (tr.b.x < tr.c.x ? tr.b.x : tr.c.x);
            float x1 = tr.a.x > tr.b.x ? (tr.a.x > tr.c.x ? tr.a.x : tr.c.x) : (tr.b.x > tr.c.x ? tr.b.x : tr.c.x);
            float z0 = tr.a.z < tr.b.z ? (tr.a.z < tr.c.z ? tr.a.z : tr.c.z) : (tr.b.z < tr.c.z ? tr.b.z : tr.c.z);
            float z1 = tr.a.z > tr.b.z ? (tr.a.z > tr.c.z ? tr.a.z : tr.c.z) : (tr.b.z > tr.c.z ? tr.b.z : tr.c.z);
            for (int cz = CellZ(z0); cz <= CellZ(z1); cz++)
                for (int cx = CellX(x0); cx <= CellX(x1); cx++) {
                    int ci = cz * gx_ + cx;
                    if (pass == 0) counts[ci]++;
                    else refs_[cellStart_[ci] + (counts[ci]++)] = (unsigned short)t;
                }
        }
        if (pass == 0) {
            int acc = 0;
            for (int i = 0; i < gx_ * gz_; i++) { cellStart_[i] = acc; acc += counts[i]; counts[i] = 0; }
            cellStart_[gx_ * gz_] = acc;
            if (acc > kMaxRefs) return false;
        }
    }
    for (int i = 0; i < kMaxTris; i++) triStamp_[i] = 0;
    stamp_ = 0;
    return true;
}

// Moller-Trumbore, double sided.
bool MeshWorld::RayTri(const Tri &t, const Vec3 &o, const Vec3 &d, float maxT, float &tOut) const
{
    Vec3 e1 = t.b - t.a, e2 = t.c - t.a;
    Vec3 p = Cross(d, e2);
    float det = e1.Dot(p);
    if (fabsf(det) < 1e-9f) return false;
    float inv = 1.0f / det;
    Vec3 s = o - t.a;
    float u = s.Dot(p) * inv;
    if (u < 0 || u > 1) return false;
    Vec3 q = Cross(s, e1);
    float v = d.Dot(q) * inv;
    if (v < 0 || u + v > 1) return false;
    float tt = e2.Dot(q) * inv;
    if (tt < 0 || tt > maxT) return false;
    tOut = tt;
    return true;
}

bool MeshWorld::Raycast(const Vec3 &a, const Vec3 &b, RayHit &hit) const
{
    Vec3 d = b - a;
    float len = d.Magnitude();
    if (len < 1e-6f) return false;
    Vec3 dir = d * (1.0f / len);
    stamp_++;
    float best = len; int bestTri = -1;

    // 2D DDA through the XZ grid
    float x = a.x, z = a.z;
    int cx = CellX(x), cz = CellZ(z);
    int stepX = dir.x > 0 ? 1 : -1, stepZ = dir.z > 0 ? 1 : -1;
    float tDX = fabsf(dir.x) > 1e-9f ? cell_ / fabsf(dir.x) : 1e30f;
    float tDZ = fabsf(dir.z) > 1e-9f ? cell_ / fabsf(dir.z) : 1e30f;
    float nextX = minX_ + (cx + (stepX > 0 ? 1 : 0)) * cell_, nextZ = minZ_ + (cz + (stepZ > 0 ? 1 : 0)) * cell_;
    float tMaxX = fabsf(dir.x) > 1e-9f ? (nextX - x) / dir.x : 1e30f;
    float tMaxZ = fabsf(dir.z) > 1e-9f ? (nextZ - z) / dir.z : 1e30f;
    for (;;) {
        int ci = cz * gx_ + cx;
        for (int r = cellStart_[ci]; r < cellStart_[ci + 1]; r++) {
            int ti = refs_[r];
            if (triStamp_[ti] == stamp_) continue;
            triStamp_[ti] = stamp_;
            float t;
            if (RayTri(tris_[ti], a, dir, best, t) && t < best) { best = t; bestTri = ti; }
        }
        float tNext = tMaxX < tMaxZ ? tMaxX : tMaxZ;
        if (tNext > best || tNext > len) break;
        if (tMaxX < tMaxZ) { cx += stepX; tMaxX += tDX; if (cx < 0 || cx >= gx_) break; }
        else { cz += stepZ; tMaxZ += tDZ; if (cz < 0 || cz >= gz_) break; }
    }
    if (bestTri < 0) return false;
    hit.dist = best; hit.point = a + dir * best; hit.normal = tris_[bestTri].n; hit.actor = -1;
    if (hit.normal.Dot(dir) > 0) hit.normal = hit.normal * -1.0f;
    return true;
}

bool MeshWorld::GroundAt(float x, float y, float z, float maxDrop, float &outY) const
{
    RayHit h;
    if (!Raycast(Vec3(x, y, z), Vec3(x, y - maxDrop, z), h)) return false;
    outY = h.point.y;
    return true;
}

// Push a sphere (centre p+centerY) out of wall-like triangles, horizontally.
void MeshWorld::PushOut(Vec3 &p, float centerY, float r) const
{
    Vec3 c(p.x, p.y + centerY, p.z);
    stamp_++;
    for (int cz = CellZ(c.z - r); cz <= CellZ(c.z + r); cz++)
        for (int cx = CellX(c.x - r); cx <= CellX(c.x + r); cx++) {
            int ci = cz * gx_ + cx;
            for (int ri = cellStart_[ci]; ri < cellStart_[ci + 1]; ri++) {
                int ti = refs_[ri];
                if (triStamp_[ti] == stamp_) continue;
                triStamp_[ti] = stamp_;
                const Tri &t = tris_[ti];
                if (fabsf(t.n.y) > 0.7f) continue;                 // floors/ceilings are handled by the vertical pass
                Vec3 q = ClosestOnTri(c, t.a, t.b, t.c);
                Vec3 d = c - q;
                d.y = 0;
                float dist2 = d.SqrMagnitude();
                Vec3 full = c - q;
                if (full.SqrMagnitude() >= r * r) continue;
                float dist = sqrtf(dist2);
                if (dist < 1e-5f) { d = Vec3(t.n.x, 0, t.n.z); dist = d.Magnitude(); if (dist < 1e-5f) continue; }
                float pen = r - dist;
                if (pen <= 0) continue;
                Vec3 push = d * (1.0f / dist) * pen;
                p += push; c += push;
            }
        }
}

Vec3 MeshWorld::MoveCharacter(const Vec3 &pos, const Vec3 &delta, float radius, float height, bool &grounded) const
{
    Vec3 p = pos;
    p.x += delta.x; p.z += delta.z;
    for (int it = 0; it < 3; it++) {
        PushOut(p, 0.75f, radius);
        PushOut(p, height - 0.4f, radius);
    }

    // vertical
    const float step = 0.45f;
    float targetY = pos.y + delta.y;
    grounded = false;
    float gy;
    float probeFrom = (pos.y > p.y ? pos.y : p.y) + step;
    if (delta.y <= 0.0f) {
        if (GroundAt(p.x, probeFrom, p.z, step + (-delta.y) + 0.05f + step, gy) && gy >= targetY - 0.001f) {
            p.y = gy; grounded = true;
        } else p.y = targetY;
    } else {
        p.y = targetY;
        RayHit h;                                              // ceiling
        if (Raycast(Vec3(p.x, pos.y + height, p.z), Vec3(p.x, p.y + height + 0.05f, p.z), h)) p.y = h.point.y - height - 0.05f;
    }
    return p;
}

} // namespace cg
