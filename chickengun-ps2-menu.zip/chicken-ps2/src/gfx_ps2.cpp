#include <string.h>
#include <malloc.h>
#include <math.h>
#include <tamtypes.h>
#include <gsKit.h>
#include <dmaKit.h>
#include <gsToolkit.h>
#include <kernel.h>
#include "gfx.h"
#include "ui.h"
#include "assets.h"

using namespace cg;

namespace {
GSGLOBAL *gs;
GSTEXTURE ui_tex[UI_TEX_COUNT];
bool ui_ok[UI_TEX_COUNT];
GSTEXTURE scene_tex[16];
bool scene_ok[16];     // CT16 textures of the converted Unity assets
bool scene_ready = false;

u64 col(unsigned c)
{
    return GS_SETREG_RGBAQ((c >> 24) & 255, (c >> 16) & 255, (c >> 8) & 255, ((c & 255) * 128) / 255, 0);
}

void load_ui_textures()
{
    for (int i = 0; i < ui_texture_count; i++) {
        const UiTexture *t = &ui_textures[i];
        void *mem = (void *)t->data;
        memset(&ui_tex[i], 0, sizeof ui_tex[i]);
        if (t->fmt == 1) {              // A8 mask -> white RGBA32, alpha 0..128
            unsigned *px = (unsigned *)memalign(64, (size_t)t->w * t->h * 4);
            const unsigned char *src = (const unsigned char *)t->data;
            int n = t->w * t->h;
            if (!px) continue;
            for (int k = 0; k < n; k++) px[k] = ((unsigned)(src[k] * 128 / 255) << 24) | 0x00FFFFFFu;
            mem = px;
            FlushCache(0);              // converted by the CPU: write the data cache back before the DMA upload
        }
        ui_tex[i].Width = t->w;
        ui_tex[i].Height = t->h;
        ui_tex[i].PSM = GS_PSM_CT32;
        ui_tex[i].Mem = (u32 *)mem;
        ui_tex[i].Filter = (t->fmt == 1) ? GS_FILTER_NEAREST : GS_FILTER_LINEAR;
        ui_tex[i].Vram = gsKit_vram_alloc(gs, gsKit_texture_size(t->w, t->h, GS_PSM_CT32), GSKIT_ALLOC_USERBUFFER);
        if (ui_tex[i].Vram == GSKIT_ALLOC_ERROR) { ui_ok[i] = false; continue; }   // out of VRAM: skip instead of corrupting memory
        ui_ok[i] = true;
        gsKit_texture_upload(gs, &ui_tex[i]);
    }
}
} // namespace

void gfx_init()
{
    gs = gsKit_init_global();
    gs->PSM = GS_PSM_CT16;            // 16-bit framebuffer + 16-bit Z to leave VRAM for textures
    gs->PSMZ = GS_PSMZ_16S;
    gs->ZBuffering = GS_SETTING_ON;
    gs->DoubleBuffering = GS_SETTING_ON;
    gs->PrimAlphaEnable = GS_SETTING_ON;

    dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC, D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1 << DMA_CHANNEL_GIF);
    dmaKit_chan_init(DMA_CHANNEL_GIF);

    gsKit_init_screen(gs);
    gsKit_mode_switch(gs, GS_ONESHOT);

    load_ui_textures();
    for (int i = 0; i < kTextureCount && i < 16; i++) {
        GSTEXTURE &t = scene_tex[i];
        memset(&t, 0, sizeof t);
        t.Width = kTextures[i].w;
        t.Height = kTextures[i].h;
        t.PSM = GS_PSM_CT16;
        t.Mem = (u32 *)(void *)kTextures[i].px;
        t.Filter = GS_FILTER_LINEAR;
        t.Vram = gsKit_vram_alloc(gs, gsKit_texture_size(t.Width, t.Height, GS_PSM_CT16), GSKIT_ALLOC_USERBUFFER);
        if (t.Vram == GSKIT_ALLOC_ERROR) { scene_ok[i] = false; continue; }
        scene_ok[i] = true;
        gsKit_texture_upload(gs, &t);
    }
    gsKit_set_clamp(gs, GS_CMODE_REPEAT);
    scene_ready = true;
    gsKit_set_test(gs, GS_ZTEST_OFF);   // 2D overlay by default
}

// ---- 3D ----
void gfx_3d_begin() { gsKit_set_test(gs, GS_ZTEST_ON); }
void gfx_3d_end() { gsKit_set_test(gs, GS_ZTEST_OFF); }

namespace {
u64 vcol(const GVert &v)
{
    auto c = [](float f) { int i = (int)(f * 128.0f); return i < 0 ? 0 : i > 255 ? 255 : i; };
    return GS_SETREG_RGBAQ(c(v.r), c(v.g), c(v.b), 0x80, 0);
}
// larger Z = nearer on the GS; keep inside 16 bits
int zmap(float z)
{
    float t = (z - 0.3f) / (250.0f - 0.3f);
    if (t < 0) t = 0;
    if (t > 1) t = 1;
    return 200 + (int)((1.0f - sqrtf(t)) * 60000.0f);
}
} // namespace

void gfx_tri3d(int tex, const GVert &a, const GVert &b, const GVert &c)
{
    if (tex < 0 || tex >= kTextureCount || tex >= 16 || !scene_ready || !scene_ok[tex]) {
        gsKit_prim_triangle_gouraud_3d(gs, a.x, a.y, zmap(a.z), b.x, b.y, zmap(b.z), c.x, c.y, zmap(c.z),
                                       vcol(a), vcol(b), vcol(c));
        return;
    }
    GSTEXTURE *t = &scene_tex[tex];
    // The GS UV register only covers ~1k texels: shift each triangle back into the first tile (texture repeats).
    float tw = (float)t->Width, th = (float)t->Height;
    float mu = fminf(a.u, fminf(b.u, c.u)), mv = fminf(a.v, fminf(b.v, c.v));
    float du = floorf(mu / tw) * tw, dv = floorf(mv / th) * th;
    gsKit_prim_triangle_goraud_texture_3d(gs, t,
        a.x, a.y, zmap(a.z), a.u - du, a.v - dv,
        b.x, b.y, zmap(b.z), b.u - du, b.v - dv,
        c.x, c.y, zmap(c.z), c.u - du, c.v - dv,
        vcol(a), vcol(b), vcol(c));
}

void gfx_begin()
{
    gsKit_clear(gs, GS_SETREG_RGBAQ(0x50, 0xA8, 0x10, 0x80, 0));   // also resets Z to 0
    // gsKit_clear() switches the depth test back on; the 2D UI must draw without it (else it is tested against stale Z)
    gsKit_set_test(gs, GS_ZTEST_OFF);
}

void gfx_end()
{
    gsKit_queue_exec(gs);
    gsKit_sync_flip(gs);
}

void gfx_rect(int x, int y, int w, int h, unsigned rgba)
{
    gsKit_prim_sprite(gs, x, y, x + w, y + h, 1, col(rgba));
}

void gfx_tex_rect(int t, int x, int y, int w, int h, int u0, int v0, int u1, int v1, unsigned rgba)
{
    if (!ui_ok[t]) return;
    gsKit_prim_sprite_texture(gs, &ui_tex[t], x, y, u0, v0, x + w, y + h, u1, v1, 2, col(rgba));
}
