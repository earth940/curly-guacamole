#include "gfx.h"
#include "input.h"
#include "menu.h"
#include "session.h"

static GameSession session;     // large (collision grid): keep it off the stack

int main()
{
    Menu menu;
    unsigned prev = 0;

    gfx_init();
    input_init();

    for (;;) {
        PadState pad = input_poll();
        unsigned pressed = pad.held & ~prev;
        prev = pad.held;

        Screen before = menu.scr;
        if (menu.scr == Screen::Game) session.Update(pad, pressed, 1.0f / 60.0f);
        menu.Update(pressed);
        if (menu.scr == Screen::Game && session.ExitRequested()) menu.BackToTitle();
        if (before != Screen::Game && menu.scr == Screen::Game) session.Start(menu.cfg);

        gfx_begin();
        if (menu.scr == Screen::Game) session.Draw();
        else menu.Draw(false);      // original flat green background tile
        gfx_end();
    }
    return 0;
}
