// BotController (zombies). NavMeshAgent is replaced by a straight chase; plug path-finding into
// Bot::Update if the converted maps get a nav grid.
#include "game.h"

namespace cg {

static const float kBotAttackPeriod = 1.0f;   // Animator "Attack" loop length is not in the scripts
static const float kBotSpeed = 3.0f;

Bot::Bot() : def(nullptr), isAttacking(false), targetId(-1), targetTimer(0), destroyTimer(0), attackTimer(0),
             speed(kBotSpeed), dead(false), destroyed(false), attackIndex(1), defIndex(0) {}

void Bot::Init(Game *g, int actorId, const BotDef *d, const Vec3 &at)
{
    game = g; id = actorId; def = d; pos = at;
    hp = maxHp = d->hp;
    radius = 0.5f; height = 1.8f;
    isAttacking = false; targetId = -1; targetTimer = 0; destroyTimer = 0; attackTimer = 0;
    dead = destroyed = false;
    team = TeamID::None;
}

void Bot::Damage(float val, int fromWhom)
{
    if (hp <= 0.0f) return;
    hp -= val;
    if (hp <= 0.0f) {                 // UpdateHP: Die animation, agent stopped, destroyed after delay
        hp = 0; dead = true; isAttacking = false;
        destroyTimer = def->destroyDelay;
        game->OnBotKilled(*this, fromWhom);
    }
}

void Bot::UpdateTarget()
{
    targetId = -1;
    float best = 1e30f;
    for (int i = 0; i < game->actorCount; i++) {
        Actor *a = game->actors[i];
        if (!a->IsPlayer() || !a->IsAlive()) continue;
        float d = (a->pos - pos).SqrMagnitude();
        if (d < best) { best = d; targetId = a->id; }
    }
}

void Bot::StartAttack()
{
    attackIndex = game->rng.Range(0, def->attackTypes) + 1;   // Random.Range(0, attackTypesCount) + 1
    isAttacking = true;
    attackTimer = kBotAttackPeriod * 0.5f;                    // hit lands mid-animation
}

void Bot::StopAttack() { isAttacking = false; }

void Bot::DamageTarget()
{
    Actor *t = game->Find(targetId);
    if (!t || !t->IsAlive()) return;
    if ((pos - t->pos).SqrMagnitude() <= def->attackDist * def->attackDist)
        t->Damage(def->damagePerAttack, id);
}

void Bot::CheckAttack()
{
    Actor *t = game->Find(targetId);
    if (!t || !t->IsAlive() || hp <= 0.0f) { if (isAttacking) StopAttack(); return; }
    if ((pos - t->pos).SqrMagnitude() < def->attackDist * def->attackDist) {
        if (!isAttacking) StartAttack();
    } else if (isAttacking) {
        StopAttack();
    }
}

void Bot::Update(float dt)
{
    if (dead) {
        destroyTimer -= dt;
        if (destroyTimer <= 0.0f) destroyed = true;
        return;
    }
    targetTimer -= dt;
    if (targetTimer <= 0.0f) { targetTimer = kBotTargetPeriod; UpdateTarget(); }
    CheckAttack();

    Actor *t = game->Find(targetId);
    if (!t || !t->IsAlive()) return;

    Vec3 to = t->pos - pos; to.y = 0;
    if (to.SqrMagnitude() > 1e-4f) yaw = atan2f(to.x, to.z) * 57.29578f;

    if (isAttacking) {
        attackTimer -= dt;
        if (attackTimer <= 0.0f) { DamageTarget(); attackTimer += kBotAttackPeriod; }
    } else {
        Vec3 step = to.Normalized() * (speed * dt);
        step.y = -2.0f * dt;                      // stay glued to the ground
        bool grounded;
        pos = game->world->MoveCharacter(pos, step, radius, height, grounded);
    }
}

} // namespace cg
