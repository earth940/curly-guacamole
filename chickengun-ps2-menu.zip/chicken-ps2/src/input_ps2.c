#include <tamtypes.h>
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <libpad.h>
#include "input.h"

static char pad_buf[256] __attribute__((aligned(64)));

void input_init(void)
{
    SifInitRpc(0);
    SifLoadModule("rom0:SIO2MAN", 0, NULL);
    SifLoadModule("rom0:PADMAN", 0, NULL);
    padInit(0);
    padPortOpen(0, 0, pad_buf);
    while (padGetState(0, 0) != PAD_STATE_STABLE) { }
}

unsigned input_poll(void)
{
    struct padButtonStatus b;
    unsigned raw, out = 0;
    if (padGetState(0, 0) != PAD_STATE_STABLE) return 0;
    if (!padRead(0, 0, &b)) return 0;
    raw = 0xFFFF ^ b.btns;
    if (raw & PAD_UP)     out |= BTN_UP;
    if (raw & PAD_DOWN)   out |= BTN_DOWN;
    if (raw & PAD_LEFT)   out |= BTN_LEFT;
    if (raw & PAD_RIGHT)  out |= BTN_RIGHT;
    if (raw & PAD_CROSS)  out |= BTN_CROSS;
    if (raw & PAD_CIRCLE) out |= BTN_CIRCLE;
    if (raw & PAD_START)  out |= BTN_START;
    return out;
}
