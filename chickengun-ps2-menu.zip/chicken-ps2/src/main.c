#include "gfx.h"
#include "input.h"
#include "menu.h"

int main(void)
{
    Menu m;
    unsigned prev = 0;

    gfx_init();
    input_init();
    menu_init(&m);

    for (;;) {
        unsigned cur = input_poll();
        unsigned pressed = cur & ~prev;
        prev = cur;
        menu_update(&m, pressed);
        gfx_begin();
        menu_draw(&m);
        gfx_end();
    }
    return 0;
}
