#ifndef UI_H
#define UI_H
#include "ui_data.h"

typedef struct { short u, v; unsigned char w, h; signed char xoff, yoff; unsigned char adv; } UiGlyph;
typedef struct { unsigned char tex, line_h, ascent; const UiGlyph *g; } UiFont;
typedef struct {
    short x, y, w, h;
    signed char tag;
    unsigned char kind;      /* 0 solid, 1 sprite, 2 9-slice, 3 text */
    unsigned char tex, align, font, border;
    short u0, v0, u1, v1;
    unsigned color;          /* 0xRRGGBBAA */
    const char *text;
} UiElem;
typedef struct { const UiElem *e; int n; } UiScreen;
typedef struct { const void *data; short w, h; int fmt; } UiTexture;  /* fmt 0: RGBA32 (A 0..128), 1: A8 mask */

extern const UiTexture ui_textures[UI_TEX_COUNT];
extern const int ui_texture_count;
extern const UiFont ui_fonts[UI_FONT_COUNT];
extern const UiScreen ui_screens[UI_SCREEN_COUNT];

/* text substitution hook: return replacement for e->text or NULL */
typedef const char *(*UiSubst)(int screen, const UiElem *e);

int  ui_text_width(int font, const char *s);
void ui_text(int font, int x, int y, unsigned color, const char *s);
void ui_text_box(int font, int x, int y, int w, int h, int align, unsigned color, const char *s);
void ui_slice(int tex, int x, int y, int w, int h, int border, int u0, int v0, int u1, int v1, unsigned color);
void ui_draw_screen(int screen, UiSubst subst);
const UiElem *ui_find_tag(int screen, int tag);
void ui_outline(const UiElem *e, int pad, int thick, unsigned color);
unsigned ui_alpha(unsigned rgba, int a);   /* replace alpha */
#endif
