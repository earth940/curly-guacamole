// BaseBulletScript / GunBullet / Missile / GrenadeBullet / Arrow.
#include "game.h"

namespace cg {

// GunBullet.RaycastForTarget: a 250 m linecast at spawn; damage lands after distance/speed.
static const float kHitscanRange = 250.0f;
static const float kGravity = 20.0f;   // Physics.gravity stand-in for rigidbody grenades

Bullet *Game::SpawnBullet(BulletType t, const Vec3 &pos, const Vec3 &dir, int owner, float damage)
{
    Bullet *b = nullptr;
    for (int i = 0; i < kMaxBullets; i++) if (!bullets[i].active) { b = &bullets[i]; break; }
    if (!b) return nullptr;               // pool exhausted (ObjectPool would instantiate; we drop)
    const BulletDef &d = GetBulletDef(t);
    *b = Bullet();
    b->active = true; b->type = t; b->ownerId = owner; b->damage = damage;
    b->pos = pos; b->dir = dir.Normalized();
    b->speed = d.speed; b->life = d.lifeTime; b->damageRadius = d.damageRadius;

    switch (t) {
    case BulletType::GunBullet:
    case BulletType::BlasterBullet: {
        b->hitscan = true;
        RayHit h;
        Vec3 end = pos + b->dir * kHitscanRange;
        float dist = kHitscanRange;
        b->pendingTarget = -1;
        if (RaycastAll(pos, end, h, owner)) { dist = h.dist; b->pendingTarget = h.actor; }
        else b->pendingTarget = -2;      // nothing hit: expire silently
        b->pendingDelay = b->speed > 0 ? dist / b->speed : 0.0f;
        break;
    }
    case BulletType::Arrow:              // Arrow overrides RaycastForTarget with nothing: flies and collides
    case BulletType::Missile_1:
        break;
    case BulletType::Grenade:
    case BulletType::SmokeGrenade:
    case BulletType::MolotovGrenade:
    case BulletType::GrenadeGunBullet:
        b->ballistic = true;             // GrenadeBullet: Rigidbody with initial velocity = forward * speed
        if (b->speed <= 0) b->speed = 18.0f;
        b->vy = b->dir.y * b->speed;
        b->dir = Vec3(b->dir.x * b->speed, 0.0f, b->dir.z * b->speed);   // dir = horizontal velocity
        break;
    }
    return b;
}

static void Finish(Game &g, Bullet &b)
{
    if (b.damageRadius > 0.0f && b.damage >= 0.0f &&
        (b.type == BulletType::Missile_1 || b.type == BulletType::Grenade || b.type == BulletType::GrenadeGunBullet ||
         b.type == BulletType::MolotovGrenade))
        // Missile (rocket, grenade-gun) skips the shooter; BaseGrenade (thrown) hits everything in range.
        g.DamageInRadius(b.pos, b.damageRadius, b.damage, b.ownerId,
                         b.type == BulletType::Grenade || b.type == BulletType::MolotovGrenade);
    b.active = false;
}

void Bullet::Update(Game &g, float dt)
{
    if (!active) return;

    if (hitscan) {                       // GunBullet.DamageTargetAndBoomIE
        pendingDelay -= dt;
        if (pendingDelay <= 0.0f) {
            if (pendingTarget >= 0) {
                Actor *t = g.Find(pendingTarget);
                if (t && t->IsAlive()) t->Damage(damage, ownerId);
            }
            active = false;
        }
        return;
    }

    life -= dt;                          // BaseBulletScript.CheckLifeTime
    Vec3 from = pos;
    if (ballistic) {
        vy -= kGravity * dt;
        pos += Vec3(dir.x, vy, dir.z) * dt;
    } else {
        pos += dir * (speed * dt);
    }

    RayHit h;
    if (g.RaycastAll(from, pos, h, ownerId)) {
        pos = h.point;
        if (type == BulletType::Arrow || type == BulletType::Missile_1) {
            if (h.actor >= 0 && type == BulletType::Arrow) {
                Actor *t = g.Find(h.actor);
                if (t && t->IsAlive()) t->Damage(damage, ownerId);
                active = false;
                return;
            }
            Finish(g, *this);            // Missile.OnTriggerEnter -> ShowBulletBoom -> DamageInRadius
            return;
        }
        if (ballistic) { Finish(g, *this); return; }   // GrenadeBullet.OnCollisionEnter
    }
    if (life <= 0.0f) {
        if (ballistic) Finish(g, *this); // thrown grenades also detonate at end of life
        else active = false;
    }
}

} // namespace cg
