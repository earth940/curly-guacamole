#include "render3d.h"
#include "gfx.h"

namespace cg {

static const int kMaxVerts = 20000;
static float s_vx[kMaxVerts], s_vy[kMaxVerts], s_vz[kMaxVerts];
static unsigned s_stamp[kMaxVerts];
static unsigned s_counter = 0;

void Renderer::Begin(const Camera &c)
{
    cam_ = c;
    float cy = cosf(c.yaw * 0.017453292f), sy = sinf(c.yaw * 0.017453292f);
    float cp = cosf(c.pitch * 0.017453292f), sp = sinf(c.pitch * 0.017453292f);
    fwd_ = Vec3(sy * cp, sp, cy * cp);
    right_ = Vec3(cy, 0, -sy);
    up_ = Vec3(fwd_.y * right_.z - fwd_.z * right_.y, fwd_.z * right_.x - fwd_.x * right_.z,
               fwd_.x * right_.y - fwd_.y * right_.x);        // forward x right
    float t = tanf(c.fovDeg * 0.5f * 0.017453292f);
    tanY_ = t; tanX_ = t * (4.0f / 3.0f);                      // 4:3 picture on a 640x448 buffer
    fy_ = (SCREEN_H * 0.5f) / tanY_;
    fx_ = (SCREEN_W * 0.5f) / tanX_;
    lightView_ = Vec3(light_.Dot(right_), light_.Dot(up_), light_.Dot(fwd_));
    trisDrawn = trisCulled = subsDrawn = 0;
}

bool Renderer::Project(const Vec3 &w, float &sx, float &sy, float &depth) const
{
    Vec3 d = w - cam_.pos;
    float x = d.Dot(right_), y = d.Dot(up_), z = d.Dot(fwd_);
    if (z < cam_.nearZ) return false;
    sx = SCREEN_W * 0.5f + x / z * fx_;
    sy = SCREEN_H * 0.5f - y / z * fy_;
    depth = z;
    return true;
}

// ---- triangle emission: near clip, projection, subdivision of large triangles ----
void Renderer::Emit(int tex, const VV &a, const VV &b, const VV &c, int)
{
    // vertices are already projected (x,y screen, z depth); cull what is entirely off screen
    float minx = a.x < b.x ? (a.x < c.x ? a.x : c.x) : (b.x < c.x ? b.x : c.x);
    float maxx = a.x > b.x ? (a.x > c.x ? a.x : c.x) : (b.x > c.x ? b.x : c.x);
    float miny = a.y < b.y ? (a.y < c.y ? a.y : c.y) : (b.y < c.y ? b.y : c.y);
    float maxy = a.y > b.y ? (a.y > c.y ? a.y : c.y) : (b.y > c.y ? b.y : c.y);
    if (maxx < 0 || minx > SCREEN_W || maxy < 0 || miny > SCREEN_H) { trisCulled++; return; }
    GVert ga = { a.x, a.y, a.z, a.u, a.v, a.r, a.g, a.b };
    GVert gb = { b.x, b.y, b.z, b.u, b.v, b.r, b.g, b.b };
    GVert gc = { c.x, c.y, c.z, c.u, c.v, c.r, c.g, c.b };
    gfx_tri3d(tex, ga, gb, gc);
    trisDrawn++;
}

// a,b,c in view space. Clips against the near plane, projects, splits large triangles in view space.
void Renderer::DrawViewTri(int tex, VV a, VV b, VV c, bool lit, float shade)
{
    (void)lit;
    VV in[4]; int n = 0;
    const VV v[3] = { a, b, c };
    const float nz = cam_.nearZ;
    for (int i = 0; i < 3; i++) {
        const VV &p = v[i], &q = v[(i + 1) % 3];
        bool pin = p.z >= nz, qin = q.z >= nz;
        if (pin) in[n++] = p;
        if (pin != qin) {
            float t = (nz - p.z) / (q.z - p.z);
            VV m = { p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, nz, p.u + (q.u - p.u) * t, p.v + (q.v - p.v) * t,
                     p.r + (q.r - p.r) * t, p.g + (q.g - p.g) * t, p.b + (q.b - p.b) * t };
            in[n++] = m;
        }
    }
    if (n < 3) return;

    // triangle list from the fan (up to 2 triangles); subdivide recursively while projected size is large
    struct Tri { VV v[3]; int d; };
    Tri stack[24]; int sp = 0;
    for (int i = 1; i + 1 < n; i++) { stack[sp].v[0] = in[0]; stack[sp].v[1] = in[i]; stack[sp].v[2] = in[i + 1]; stack[sp].d = 0; sp++; }
    while (sp > 0) {
        Tri t = stack[--sp];
        float sxv[3], syv[3];
        for (int i = 0; i < 3; i++) { sxv[i] = SCREEN_W * 0.5f + t.v[i].x / t.v[i].z * fx_; syv[i] = SCREEN_H * 0.5f - t.v[i].y / t.v[i].z * fy_; }
        float minx = sxv[0], maxx = sxv[0], miny = syv[0], maxy = syv[0];
        for (int i = 1; i < 3; i++) {
            if (sxv[i] < minx) minx = sxv[i];
            if (sxv[i] > maxx) maxx = sxv[i];
            if (syv[i] < miny) miny = syv[i];
            if (syv[i] > maxy) maxy = syv[i];
        }
        if (maxx < 0 || minx > SCREEN_W || maxy < 0 || miny > SCREEN_H) { trisCulled++; continue; }
        bool big = false;
        if (tex >= 0 && sp < 20) {
            float umin = t.v[0].u, umax = umin, vmin = t.v[0].v, vmax = vmin;
            for (int i = 1; i < 3; i++) {
                if (t.v[i].u < umin) umin = t.v[i].u;
                if (t.v[i].u > umax) umax = t.v[i].u;
                if (t.v[i].v < vmin) vmin = t.v[i].v;
                if (t.v[i].v > vmax) vmax = t.v[i].v;
            }
            float texel = (float)kTextures[tex].w;     // GS UV registers hold ~2k texels: keep the span small
            bool uvBig = ((umax - umin) > vmax - vmin ? (umax - umin) : (vmax - vmin)) * texel > 900.0f;
            big = (t.d < 3 && ((maxx - minx) > 110.0f || (maxy - miny) > 110.0f)) || (t.d < 6 && uvBig);
        }
        if (big) {
            // split at the longest edge midpoint (in view space, so the interpolation stays perspective-correct)
            int e = 0; float best = -1;
            for (int i = 0; i < 3; i++) {
                int j = (i + 1) % 3;
                float dx = sxv[i] - sxv[j], dy = syv[i] - syv[j], l = dx * dx + dy * dy;
                if (l > best) { best = l; e = i; }
            }
            const VV &p = t.v[e], &q = t.v[(e + 1) % 3], &o = t.v[(e + 2) % 3];
            VV m = { (p.x + q.x) * .5f, (p.y + q.y) * .5f, (p.z + q.z) * .5f, (p.u + q.u) * .5f, (p.v + q.v) * .5f,
                     (p.r + q.r) * .5f, (p.g + q.g) * .5f, (p.b + q.b) * .5f };
            stack[sp].v[0] = p; stack[sp].v[1] = m; stack[sp].v[2] = o; stack[sp].d = t.d + 1; sp++;
            stack[sp].v[0] = m; stack[sp].v[1] = q; stack[sp].v[2] = o; stack[sp].d = t.d + 1; sp++;
            continue;
        }
        VV o[3];
        for (int i = 0; i < 3; i++) {
            o[i] = t.v[i];
            o[i].x = sxv[i]; o[i].y = syv[i];
            o[i].r *= shade; o[i].g *= shade; o[i].b *= shade;
        }
        Emit(tex, o[0], o[1], o[2], t.d);
    }
}

void Renderer::DrawModel(const Model &m, const Vec3 &pos, float yawDeg, float scale, float tr, float tg, float tb)
{
    float cy = cosf(yawDeg * 0.017453292f), sy = sinf(yawDeg * 0.017453292f);
    // model -> world: x' = (x*cy + z*sy)*s,  z' = (-x*sy + z*cy)*s,  y' = y*s
    // world -> view: dot with camera basis. Build the 3x3 (rows = view axes) and the translation.
    const Vec3 axX(cy * scale, 0, -sy * scale), axY(0, scale, 0), axZ(sy * scale, 0, cy * scale);   // images of local x,y,z
    Vec3 cols[3] = { axX, axY, axZ };
    float M[3][3];
    for (int c = 0; c < 3; c++) {
        M[0][c] = cols[c].Dot(right_); M[1][c] = cols[c].Dot(up_); M[2][c] = cols[c].Dot(fwd_);
    }
    Vec3 d = pos - cam_.pos;
    const float T[3] = { d.Dot(right_), d.Dot(up_), d.Dot(fwd_) };
    DrawModelMT(m, M, T, scale, tr, tg, tb);
}

// Model attached to the camera (first-person weapon): off = (right, up, forward) in metres,
// the model's +z points along the view direction, yaw/pitch tilt it slightly (degrees).
void Renderer::DrawModelView(const Model &m, const Vec3 &off, float scale, float yawDeg, float pitchDeg)
{
    float cy = cosf(yawDeg * 0.017453292f), sy = sinf(yawDeg * 0.017453292f);
    float cp = cosf(pitchDeg * 0.017453292f), sp = sinf(pitchDeg * 0.017453292f);
    // local->view: yaw about y then pitch about x
    float M[3][3] = { { cy * scale, 0, sy * scale },
                      { sp * sy * scale, cp * scale, -sp * cy * scale },
                      { -cp * sy * scale, sp * scale, cp * cy * scale } };
    const float T[3] = { off.x, off.y, off.z };
    DrawModelMT(m, M, T, scale, 1, 1, 1);
}

void Renderer::DrawModelMT(const Model &m, const float M[3][3], const float T[3], float scale, float tr, float tg, float tb)
{
    s_counter++;
    const float ps = m.posScale, us = m.uvScale;
    for (int si = 0; si < m.subCount; si++) {
        const SubMesh &s = m.subs[si];
        // bounding sphere in view space
        float cx = M[0][0] * s.cx + M[0][1] * s.cy + M[0][2] * s.cz + T[0];
        float cyv = M[1][0] * s.cx + M[1][1] * s.cy + M[1][2] * s.cz + T[1];
        float cz = M[2][0] * s.cx + M[2][1] * s.cy + M[2][2] * s.cz + T[2];
        float r = s.radius * scale * 1.05f;
        if (cz + r < cam_.nearZ || cz - r > cam_.farZ) continue;
        float k = r * 1.5f;
        if (cx - k > cz * tanX_ || -cx - k > cz * tanX_ || cyv - k > cz * tanY_ || -cyv - k > cz * tanY_) continue;
        subsDrawn++;
        float tw = 1.0f, th = 1.0f; (void)tw; (void)th;
        for (unsigned i = s.firstIndex; i < s.firstIndex + s.indexCount; i += 3) {
            VV v[3];
            for (int k2 = 0; k2 < 3; k2++) {
                unsigned vi = m.idx[i + k2];
                const Vertex &vt = m.verts[vi];
                if (vi < (unsigned)kMaxVerts && s_stamp[vi] != s_counter) {
                    float x = vt.x * ps, y = vt.y * ps, z = vt.z * ps;
                    s_vx[vi] = M[0][0] * x + M[0][1] * y + M[0][2] * z + T[0];
                    s_vy[vi] = M[1][0] * x + M[1][1] * y + M[1][2] * z + T[1];
                    s_vz[vi] = M[2][0] * x + M[2][1] * y + M[2][2] * z + T[2];
                    s_stamp[vi] = s_counter;
                }
                v[k2].x = s_vx[vi]; v[k2].y = s_vy[vi]; v[k2].z = s_vz[vi];
                v[k2].u = vt.u * us; v[k2].v = vt.v * us;
                v[k2].r = vt.r * (1.0f / 255.0f) * tr; v[k2].g = vt.g * (1.0f / 255.0f) * tg; v[k2].b = vt.b * (1.0f / 255.0f) * tb;
            }
            if (v[0].z < cam_.nearZ && v[1].z < cam_.nearZ && v[2].z < cam_.nearZ) continue;
            if (v[0].z > cam_.farZ && v[1].z > cam_.farZ && v[2].z > cam_.farZ) continue;
            // face normal (view space); the front face is the one whose normal points at the camera
            Vec3 e1(v[1].x - v[0].x, v[1].y - v[0].y, v[1].z - v[0].z), e2(v[2].x - v[0].x, v[2].y - v[0].y, v[2].z - v[0].z);
            Vec3 n(e1.y * e2.z - e1.z * e2.y, e1.z * e2.x - e1.x * e2.z, e1.x * e2.y - e1.y * e2.x);
            float facing = n.x * v[0].x + n.y * v[0].y + n.z * v[0].z;
            if (facing >= 0.0f) { trisCulled++; continue; }
            float nl = n.Magnitude();
            float shade = 0.62f;
            if (nl > 1e-9f) {
                float d2 = (n.x * lightView_.x + n.y * lightView_.y + n.z * lightView_.z) / nl;
                shade = 0.62f + 0.5f * (d2 > 0 ? d2 : 0);
            }
            DrawViewTri(s.tex, v[0], v[1], v[2], true, shade);
        }
    }
}

void Renderer::DrawBillboard(const Vec3 &c, float size, float r, float g, float b)
{
    Vec3 d = c - cam_.pos;
    float x = d.Dot(right_), y = d.Dot(up_), z = d.Dot(fwd_);
    float h = size * 0.5f;
    VV q[4] = { { x - h, y + h, z, 0, 0, r, g, b }, { x + h, y + h, z, 0, 0, r, g, b },
                { x + h, y - h, z, 0, 0, r, g, b }, { x - h, y - h, z, 0, 0, r, g, b } };
    // clockwise as seen from the camera
    DrawViewTri(-1, q[0], q[1], q[2], false, 1.0f);
    DrawViewTri(-1, q[0], q[2], q[3], false, 1.0f);
}

} // namespace cg
