// Minimal C++ runtime pieces for -fno-exceptions -fno-rtti builds without libstdc++.
// Only linked into the PS2 ELF (see Makefile); host tests use the real runtime.
#include <stddef.h>

extern "C" void __cxa_pure_virtual() { for (;;) { } }

// Virtual destructors reference the deleting variant; nothing is ever heap-allocated.
void operator delete(void *) noexcept {}
void operator delete(void *, size_t) noexcept {}
