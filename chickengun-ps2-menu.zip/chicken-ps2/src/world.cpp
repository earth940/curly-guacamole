#include "world.h"

namespace cg {

// Slab test of a segment against an AABB. Returns entry fraction in t, normal of the entered face.
static bool SegmentBox(const Vec3 &a, const Vec3 &d, const Vec3 &mn, const Vec3 &mx, float &tOut, Vec3 &nOut)
{
    float t0 = 0.0f, t1 = 1.0f;
    Vec3 n;
    const float as[3] = { a.x, a.y, a.z }, ds[3] = { d.x, d.y, d.z };
    const float mins[3] = { mn.x, mn.y, mn.z }, maxs[3] = { mx.x, mx.y, mx.z };
    for (int i = 0; i < 3; i++) {
        if (fabsf(ds[i]) < 1e-8f) {
            if (as[i] < mins[i] || as[i] > maxs[i]) return false;
            continue;
        }
        float inv = 1.0f / ds[i];
        float ta = (mins[i] - as[i]) * inv, tb = (maxs[i] - as[i]) * inv;
        float sign = -1.0f;
        if (ta > tb) { float t = ta; ta = tb; tb = t; sign = 1.0f; }
        if (ta > t0) {
            t0 = ta;
            n = Vec3();
            (i == 0 ? n.x : i == 1 ? n.y : n.z) = sign;
        }
        if (tb < t1) t1 = tb;
        if (t0 > t1) return false;
    }
    tOut = t0; nOut = n;
    return true;
}

bool FlatWorld::Raycast(const Vec3 &a, const Vec3 &b, RayHit &hit) const
{
    Vec3 d = b - a;
    float len = d.Magnitude();
    if (len < 1e-6f) return false;
    bool found = false;
    float best = 2.0f;
    Vec3 bn;
    // ground plane
    if (d.y < -1e-8f && a.y >= groundY) {
        float t = (groundY - a.y) / d.y;
        if (t >= 0.0f && t <= 1.0f) { best = t; bn = Vec3(0, 1, 0); found = true; }
    }
    for (int i = 0; i < boxCount; i++) {
        float t; Vec3 n;
        if (SegmentBox(a, d, boxes[i].min, boxes[i].max, t, n) && t < best) { best = t; bn = n; found = true; }
    }
    if (!found) return false;
    hit.dist = best * len;
    hit.point = a + d * best;
    hit.normal = bn;
    hit.actor = -1;
    return true;
}

bool FlatWorld::Overlaps(const Vec3 &p, float r, float h) const
{
    for (int i = 0; i < boxCount; i++) {
        const Box &b = boxes[i];
        if (p.x + r > b.min.x && p.x - r < b.max.x && p.z + r > b.min.z && p.z - r < b.max.z &&
            p.y + h > b.min.y + 0.001f && p.y < b.max.y - 0.001f)
            return true;
    }
    return false;
}

// Highest walkable surface under the character footprint that is not above the feet.
float FlatWorld::SupportY(const Vec3 &p, float r) const
{
    float y = groundY;
    for (int i = 0; i < boxCount; i++) {
        const Box &b = boxes[i];
        if (p.x + r > b.min.x && p.x - r < b.max.x && p.z + r > b.min.z && p.z - r < b.max.z &&
            b.max.y <= p.y + 0.31f && b.max.y > y)
            y = b.max.y;
    }
    return y;
}

Vec3 FlatWorld::MoveCharacter(const Vec3 &pos, const Vec3 &delta, float r, float h, bool &grounded) const
{
    Vec3 p = pos;
    Vec3 q = p; q.x += delta.x;
    if (!Overlaps(q, r, h)) p = q;
    q = p; q.z += delta.z;
    if (!Overlaps(q, r, h)) p = q;

    p.y += delta.y;
    float floorY = SupportY(p, r);
    grounded = false;
    if (p.y <= floorY + 0.001f && delta.y <= 0.0f) { p.y = floorY; grounded = true; }
    else if (delta.y > 0.0f) {
        for (int i = 0; i < boxCount; i++) {   // head bump
            const Box &b = boxes[i];
            if (p.x + r > b.min.x && p.x - r < b.max.x && p.z + r > b.min.z && p.z - r < b.max.z &&
                pos.y + h <= b.min.y + 0.001f && p.y + h > b.min.y) { p.y = b.min.y - h; break; }
        }
    }
    return p;
}

} // namespace cg
