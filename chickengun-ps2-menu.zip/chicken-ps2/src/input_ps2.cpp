#include <tamtypes.h>
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <libpad.h>
#include "input.h"

namespace {
char pad_buf[256] __attribute__((aligned(64)));

float axis(unsigned char v)
{
    float f = ((int)v - 128) / 127.0f;
    return (f > -0.2f && f < 0.2f) ? 0.0f : (f > 1.0f ? 1.0f : (f < -1.0f ? -1.0f : f));   // dead zone
}
}

void input_init()
{
    SifInitRpc(0);
    SifLoadModule("rom0:SIO2MAN", 0, nullptr);
    SifLoadModule("rom0:PADMAN", 0, nullptr);
    padInit(0);
    padPortOpen(0, 0, pad_buf);
    while (padGetState(0, 0) != PAD_STATE_STABLE) { }
    // analog sticks need DualShock mode; lock it so the Analog button can't switch it off
    padSetMainMode(0, 0, PAD_MMODE_DUALSHOCK, PAD_MMODE_LOCK);
}

PadState input_poll()
{
    PadState out;
    padButtonStatus b;
    if (padGetState(0, 0) != PAD_STATE_STABLE) return out;
    if (!padRead(0, 0, &b)) return out;
    unsigned raw = 0xFFFF ^ b.btns;
    struct { unsigned ps2, mine; } map[] = {
        { PAD_UP, BTN_UP }, { PAD_DOWN, BTN_DOWN }, { PAD_LEFT, BTN_LEFT }, { PAD_RIGHT, BTN_RIGHT },
        { PAD_CROSS, BTN_CROSS }, { PAD_CIRCLE, BTN_CIRCLE }, { PAD_START, BTN_START },
        { PAD_SQUARE, BTN_SQUARE }, { PAD_TRIANGLE, BTN_TRIANGLE }, { PAD_L1, BTN_L1 }, { PAD_R1, BTN_R1 },
        { PAD_L2, BTN_L2 }, { PAD_R2, BTN_R2 }, { PAD_SELECT, BTN_SELECT },
    };
    for (const auto &m : map) if (raw & m.ps2) out.held |= m.mine;
    out.lx = axis(b.ljoy_h);  out.ly = -axis(b.ljoy_v);
    out.rx = axis(b.rjoy_h);  out.ry = -axis(b.rjoy_v);
    return out;
}
