#ifndef GFX_H
#define GFX_H
/* Colors are 0xRRGGBBAA, alpha 0..255. Screen is 640x448. */
#define SCREEN_W 640
#define SCREEN_H 448
void gfx_init(void);
void gfx_begin(void);
void gfx_end(void);
void gfx_rect(int x, int y, int w, int h, unsigned rgba);
/* textured rectangle; u/v are texel coordinates inside texture `tex` (index into ui_textures) */
void gfx_tex_rect(int tex, int x, int y, int w, int h, int u0, int v0, int u1, int v1, unsigned rgba);
#endif
