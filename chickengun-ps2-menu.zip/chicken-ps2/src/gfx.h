#pragma once
// Colors are 0xRRGGBBAA, alpha 0..255. Screen is 640x448.
#define SCREEN_W 640
#define SCREEN_H 448
void gfx_init();
void gfx_begin();
void gfx_end();
void gfx_rect(int x, int y, int w, int h, unsigned rgba);
// textured rectangle; u/v are texel coordinates inside UI texture `tex` (index into ui_textures)
void gfx_tex_rect(int tex, int x, int y, int w, int h, int u0, int v0, int u1, int v1, unsigned rgba);
// HUD text built on the original game's UI fonts; size picks the nearest font.
void gfx_text(int x, int y, int size, unsigned rgba, const char *s);
int gfx_text_width(int size, const char *s);

// ---- 3D ----
// x,y = screen pixels, z = view depth (metres), u,v = texels, r,g,b = modulation (1.0 = unlit texture colour)
struct GVert { float x, y, z, u, v, r, g, b; };
void gfx_3d_begin();                                   // depth test on
void gfx_3d_end();                                     // back to 2D overlay drawing
void gfx_tri3d(int tex, const GVert &a, const GVert &b, const GVert &c);   // tex < 0: flat colour
