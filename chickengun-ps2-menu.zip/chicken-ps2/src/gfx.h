#ifndef GFX_H
#define GFX_H
/* Colors are 0xRRGGBBAA, alpha 0..255. Screen is 640x448. */
#define SCREEN_W 640
#define SCREEN_H 448
void gfx_init(void);
void gfx_begin(void);
void gfx_end(void);
void gfx_rect(int x, int y, int w, int h, unsigned rgba);
void gfx_text(int x, int y, int size, unsigned rgba, const char *s);
int  gfx_text_width(int size, const char *s);
#endif
