// Small software T&L pipeline: transform, near-plane clip, back-face cull, per-face lighting.
// Triangles are handed to the gfx_tri3d backend (gsKit on PS2, a software rasteriser in the preview tool).
#pragma once
#include "assets.h"

namespace cg {

struct Camera {
    Vec3 pos;
    float yaw, pitch;       // degrees, same convention as Player
    float fovDeg;           // vertical field of view
    float nearZ, farZ;
    Camera() : yaw(0), pitch(0), fovDeg(60.0f), nearZ(0.3f), farZ(250.0f) {}
};

class Renderer {
public:
    int trisDrawn, trisCulled, subsDrawn;

    Renderer() : trisDrawn(0), trisCulled(0), subsDrawn(0), frame_(0) { SetLight(Vec3(0.45f, 0.8f, -0.4f)); }
    void SetLight(const Vec3 &dirToLightWorld) { light_ = dirToLightWorld.Normalized(); }
    void Begin(const Camera &cam);

    // pos = model origin (feet), yaw in degrees (local +Z faces (sin,0,cos)), tint multiplies the texture.
    void DrawModel(const Model &m, const Vec3 &pos, float yawDeg, float scale = 1.0f,
                   float tr = 1.0f, float tg = 1.0f, float tb = 1.0f);
    void DrawModelView(const Model &m, const Vec3 &off, float scale = 1.0f, float yawDeg = 0, float pitchDeg = 0);
    void DrawBillboard(const Vec3 &center, float size, float r, float g, float b);

    // projection of a world point (for tests / HUD); returns false when behind the near plane
    bool Project(const Vec3 &w, float &sx, float &sy, float &depth) const;

private:
    void DrawModelMT(const Model &m, const float M[3][3], const float T[3], float scale, float tr, float tg, float tb);
    struct VV { float x, y, z, u, v, r, g, b; };
    Camera cam_;
    Vec3 right_, up_, fwd_, lightView_;
    float fx_, fy_, tanX_, tanY_;
    unsigned frame_;
    Vec3 light_;
    void DrawViewTri(int tex, VV a, VV b, VV c, bool lit, float shade);
    void Emit(int tex, const VV &a, const VV &b, const VV &c, int depth);
};

} // namespace cg
