#include <string.h>
#include "gfx.h"
#include "ui.h"

unsigned ui_alpha(unsigned c, int a) { return (c & 0xFFFFFF00u) | (unsigned)(a & 255); }

int ui_text_width(int font, const char *s)
{
    const UiFont *f = &ui_fonts[font]; int w = 0;
    for (; *s && *s != '\n'; s++) {
        int c = (unsigned char)*s - 32;
        if (c >= 0 && c < 95) w += f->g[c].adv;
    }
    return w;
}

void ui_text(int font, int x, int y, unsigned color, const char *s)
{
    const UiFont *f = &ui_fonts[font];
    for (; *s && *s != '\n'; s++) {
        int c = (unsigned char)*s - 32;
        const UiGlyph *g;
        if (c < 0 || c >= 95) continue;
        g = &f->g[c];
        if (g->w)
            gfx_tex_rect(f->tex, x + g->xoff, y + g->yoff, g->w, g->h, g->u, g->v, g->u + g->w, g->v + g->h, color);
        x += g->adv;
    }
}

/* align: 0..8 like Unity TextAnchor (col = a%3: left/center/right, row = a/3: upper/middle/lower) */
void ui_text_box(int font, int x, int y, int w, int h, int align, unsigned color, const char *s)
{
    const UiFont *f = &ui_fonts[font];
    int lines = 1, i, col = align % 3, row = align / 3, ty;
    const char *p;
    for (p = s; *p; p++) if (*p == '\n') lines++;
    ty = y + (h - lines * f->line_h) * row / 2;
    p = s;
    for (i = 0; i < lines; i++) {
        int lw = ui_text_width(font, p);
        ui_text(font, x + (w - lw) * col / 2, ty + i * f->line_h, color, p);
        while (*p && *p != '\n') p++;
        if (*p == '\n') p++;
    }
}

void ui_slice(int tex, int x, int y, int w, int h, int b, int u0, int v0, int u1, int v1, unsigned c)
{
    int sb = (u1 - u0) <= 16 ? 4 : 9;
    int xs[4], ys[4], us[4], vs[4], i, j;
    if (w < 2 * b) b = w / 2;
    if (h < 2 * b) b = h / 2;
    if (b < 1) { gfx_tex_rect(tex, x, y, w, h, u0 + sb, v0 + sb, u0 + sb + 1, v0 + sb + 1, c); return; }
    xs[0] = x; xs[1] = x + b; xs[2] = x + w - b; xs[3] = x + w;
    ys[0] = y; ys[1] = y + b; ys[2] = y + h - b; ys[3] = y + h;
    us[0] = u0; us[1] = u0 + sb; us[2] = u1 - sb; us[3] = u1;
    vs[0] = v0; vs[1] = v0 + sb; vs[2] = v1 - sb; vs[3] = v1;
    for (j = 0; j < 3; j++)
        for (i = 0; i < 3; i++)
            if (xs[i + 1] > xs[i] && ys[j + 1] > ys[j])
                gfx_tex_rect(tex, xs[i], ys[j], xs[i + 1] - xs[i], ys[j + 1] - ys[j], us[i], vs[j], us[i + 1], vs[j + 1], c);
}

void ui_draw_screen(int screen, UiSubst subst)
{
    const UiScreen *s = &ui_screens[screen];
    int i;
    for (i = 0; i < s->n; i++) {
        const UiElem *e = &s->e[i];
        switch (e->kind) {
        case 0: gfx_rect(e->x, e->y, e->w, e->h, e->color); break;
        case 1: gfx_tex_rect(e->tex, e->x, e->y, e->w, e->h, e->u0, e->v0, e->u1, e->v1, e->color); break;
        case 2: ui_slice(e->tex, e->x, e->y, e->w, e->h, e->border, e->u0, e->v0, e->u1, e->v1, e->color); break;
        case 3: {
            const char *t = subst ? subst(screen, e) : 0;
            ui_text_box(e->font, e->x, e->y, e->w, e->h, e->align, e->color, t ? t : e->text);
            break; }
        }
    }
}

const UiElem *ui_find_tag(int screen, int tag)
{
    const UiScreen *s = &ui_screens[screen]; int i;
    for (i = 0; i < s->n; i++) if (s->e[i].tag == tag && s->e[i].kind != 3) return &s->e[i];
    return 0;
}

void ui_outline(const UiElem *e, int pad, int t, unsigned c)
{
    int x = e->x - pad, y = e->y - pad, w = e->w + 2 * pad, h = e->h + 2 * pad;
    gfx_rect(x, y, w, t, c); gfx_rect(x, y + h - t, w, t, c);
    gfx_rect(x, y, t, h, c); gfx_rect(x + w - t, y, t, h, c);
}
