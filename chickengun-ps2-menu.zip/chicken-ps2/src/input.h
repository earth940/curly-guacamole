#ifndef INPUT_H
#define INPUT_H
#define BTN_UP     0x01
#define BTN_DOWN   0x02
#define BTN_LEFT   0x04
#define BTN_RIGHT  0x08
#define BTN_CROSS  0x10
#define BTN_CIRCLE 0x20
#define BTN_START  0x40
void input_init(void);
unsigned input_poll(void); /* returns currently held buttons */
#endif
