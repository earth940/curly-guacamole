#pragma once
// Button bits (held-state mask). Menu code works on "pressed this frame" masks.
enum : unsigned {
    BTN_UP = 0x0001, BTN_DOWN = 0x0002, BTN_LEFT = 0x0004, BTN_RIGHT = 0x0008,
    BTN_CROSS = 0x0010, BTN_CIRCLE = 0x0020, BTN_START = 0x0040,
    BTN_SQUARE = 0x0080, BTN_TRIANGLE = 0x0100, BTN_L1 = 0x0200, BTN_R1 = 0x0400,
    BTN_L2 = 0x0800, BTN_R2 = 0x1000, BTN_SELECT = 0x2000
};

struct PadState {
    unsigned held = 0;
    float lx = 0, ly = 0;   // left stick,  -1..1 (x right, y up)
    float rx = 0, ry = 0;   // right stick, -1..1
};

void input_init();
PadState input_poll();
