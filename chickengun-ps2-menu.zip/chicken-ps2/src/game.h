// Gameplay core, C++ port of the Unity scripts:
//   CharacterMotor + PlayerController -> Player        BaseWeaponScript/BaseMeleeWeapon -> Weapon
//   GunBullet/Missile/GrenadeBullet/Arrow -> Bullet     BotController -> Bot
//   GameController + ZombieManager    -> Game          IDamageReciver/IDestroyable -> Actor
// Photon (RPC, views, clones, interpolation) is dropped: the PS2 port is offline.
#pragma once
#include "types.h"
#include "world.h"

namespace cg {

class Game;
class Player;

// ---------------------------------------------------------------- Actor
class Actor {
public:
    int id;
    Game *game;
    Vec3 pos;           // feet
    float yaw;          // degrees
    TeamID team;
    float hp, maxHp;
    float radius, height;

    Actor() : id(-1), game(nullptr), yaw(0), team(TeamID::None), hp(0), maxHp(0), radius(0.4f), height(1.8f) {}
    virtual ~Actor() {}
    bool IsAlive() const { return hp > 0.0f; }
    virtual bool IsPlayer() const { return false; }
    virtual void Damage(float val, int fromWhom) = 0;   // IDamageReciver.Damage
    virtual void Heal(float val) = 0;                   // IDamageReciver.Heal
    virtual void Update(float dt) = 0;
    Vec3 Center() const { return Vec3(pos.x, pos.y + height * 0.5f, pos.z); }
};

// ---------------------------------------------------------------- Weapon
class Weapon {
public:
    const GunDef *def;
    int ownerId;
    int ammo;
    bool shooting;
    bool reloading;
    int shotsFired;

    Weapon() : def(nullptr), ownerId(-1), ammo(0), shooting(false), reloading(false), shotsFired(0),
               cooldown_(0), reloadTimer_(0), queueIndex_(0) {}
    void Init(const GunDef *d, int owner);
    bool IsMelee() const { return def->weaponClass == (int)WeaponClass::Melee; }
    float FireInterval() const;
    void ResetAmmo() { ammo = def->maxAmmo; reloading = false; reloadTimer_ = 0; }
    void StartShooting();
    void StopShooting() { shooting = false; }
    void Reload();
    void Update(Player &owner, float dt);

private:
    float cooldown_, reloadTimer_;
    int queueIndex_;
    void PushBullet(Player &owner);
    void CreateBullet(Player &owner, int pivotIndex);
    void MeleeHit(Player &owner);
};

// ---------------------------------------------------------------- Bullet
class Bullet {
public:
    bool active;
    BulletType type;
    int ownerId;
    float damage;
    Vec3 pos, dir;
    float speed, life, damageRadius;
    float vy;                 // ballistic projectiles (grenades)
    bool ballistic;
    float pendingDelay;       // hitscan: damage lands after distance/speed seconds
    int pendingTarget;        // actor id, or -1 for "hit the world"
    bool hitscan;
    Bullet() : active(false), type(BulletType::GunBullet), ownerId(-1), damage(0), speed(0), life(0),
               damageRadius(0), vy(0), ballistic(false), pendingDelay(0), pendingTarget(-1), hitscan(false) {}
    void Update(Game &g, float dt);
};

// ---------------------------------------------------------------- Player
class Player : public Actor {
public:
    static constexpr int kMaxWeapons = 24;
    struct Info { int deaths, assists, score, frags; };

    Info info;
    const PlayerDef *def;

    // input (CharacterMotor.moveNormalDir etc.)
    float moveX, moveY;       // strafe / forward, -1..1
    float pitch;              // degrees, positive = looking up
    Vec3 aimPoint;            // third-person aiming: world point under the crosshair
    bool hasAim;

    // motor state
    float vertVelocity, timeInAir;
    bool grounded;
    int jumpFrames;           // JumpCRT retried for up to 10 frames while airborne
    float lastShootTime;
    bool isNowShooting;

    // weapons (PlayerWeaponManager)
    Weapon weapons[kMaxWeapons];
    int weaponCount, current;

    // damage tracking for kill credit and assists
    int lastDamagerId, lastKillerId;
    int damagers[kMaxActors];
    int damagerCount;

    Player();
    void Init(Game *g, int actorId, TeamID t, const PlayerDef *d);
    bool IsPlayer() const override { return true; }

    bool AddWeapon(const char *gunId);
    Weapon &Gun() { return weapons[current]; }
    void SelectWeapon(int index);
    void SelectNextWeapon(int sign);

    void SetMove(float x, float y) { moveX = x; moveY = y; }
    void SetLook(float yawDeg, float pitchDeg) { yaw = yawDeg; pitch = Clampf(pitchDeg, -85.0f, 85.0f); }
    void Jump() { jumpFrames = 10; }
    void StartShoot();
    void StopShoot();
    Vec3 EyePos() const { return Vec3(pos.x, pos.y + 1.5f, pos.z); }   // BaseWeaponScript.pivotHeight
    Vec3 AimDir() const;

    void Damage(float val, int fromWhom) override;
    void Heal(float val) override;
    void Update(float dt) override;
    void Respawn(const Vec3 &at);

    bool IsThisIdKillerAssist(int damagerId) const;
    void AddScore(int score);
    void HandleMakeKill() { info.frags++; }
    void HandleMakeKillAssist() { info.assists++; }
    void HandleMyDeath() { info.deaths++; }
    void HandleRevenge() { lastKillerId = -1; }

private:
    void Die();
};

// ---------------------------------------------------------------- Bot (zombies)
class Bot : public Actor {
public:
    const BotDef *def;
    bool isAttacking;
    int targetId;
    float targetTimer, destroyTimer;
    float attackTimer;
    float speed;
    bool dead, destroyed;
    int attackIndex;
    int defIndex;             // index into the bot table (also selects the 3D model)

    Bot();
    void Init(Game *g, int actorId, const BotDef *d, const Vec3 &at);
    void Damage(float val, int fromWhom) override;
    void Heal(float) override {}
    void Update(float dt) override;

private:
    void UpdateTarget();
    void CheckAttack();
    void StartAttack();
    void StopAttack();
    void DamageTarget();
};

// ---------------------------------------------------------------- Game
struct TeamScores { int a, b; };

class Game {
public:
    static constexpr int kMaxSpawns = 16;

    IWorld *world;
    GameMode mode;
    Rng rng;
    float time;                 // seconds since match start
    float levelDuration;
    bool matchFinished;
    int matchesPlayed;
    TeamScores teamScores;
    int botKills;

    // actors are owned by the caller-provided storage inside Game (no heap)
    Actor *actors[kMaxActors];
    int actorCount;
    Bullet bullets[kMaxBullets];

    Game();
    void Init(IWorld *w, GameMode m, unsigned seed);

    Player *AddPlayer(TeamID team);
    Bot *SpawnBot(int botDefIndex, const Vec3 &at);
    Actor *Find(int id) const;
    Player *OurPlayer() const { return our_; }
    void AddSpawnPoint(const Vec3 &p);
    Vec3 PickSpawn();

    void Update(float dt);

    // events from actors
    void OnPlayerKilled(Player &victim);
    void OnBotKilled(Bot &bot, int killerId);
    void AddTeamScore(int score, TeamID team);
    int GetTeamScore(TeamID t) const { return t == TeamID::TeamA ? teamScores.a : t == TeamID::TeamB ? teamScores.b : -1; }
    bool IsTeamMate(TeamID t) const { return our_ && t == our_->team && t != TeamID::None; }
    bool IsFriendlyFire(int attackerId, const Actor &victim) const;
    double TimeLeft() const { double l = levelDuration - time; return l < 0 ? 0 : l; }

    // combat helpers used by weapons / bullets
    bool RaycastAll(const Vec3 &a, const Vec3 &b, RayHit &hit, int ignoreActor) const;
    void DamageInRadius(const Vec3 &c, float radius, float dmg, int fromWhom, bool hitOwner);
    Bullet *SpawnBullet(BulletType t, const Vec3 &pos, const Vec3 &dir, int owner, float damage);

    void PlayAgain();                       // GameController.OnClickPlayAgain
    void RespawnPlayer(Player &p);

    // zombie survival (ZombieManager)
    int currentWave;
    float zombieClock;

private:
    Player *our_;
    Vec3 spawns_[kMaxSpawns];
    int spawnCount_;
    float zombieSpawnTimer_;
    // actor storage
    Player playerStore_[8];
    int playerStoreUsed_;
    Bot botStore_[kMaxActors];
    int nextId_;

    void UpdateZombies(float dt);
    void CreateZombie();
    void CollectGarbage();
};

// lookup helpers (gun table from data_gen.h)
const GunDef *FindGun(const char *id);
int GunCount();
int BotDefCount();
const BotDef *GetBotDef(int i);
const PlayerDef &GetPlayerDef();
const BulletDef &GetBulletDef(BulletType t);

} // namespace cg
