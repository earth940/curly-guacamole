#pragma once
// Menu flow of the original MainMenu scene (layout and sprites come from the Unity export: ui_data / tex_data).
enum class Screen { Title, Create, Settings, Loading, Game };

struct GameConfig { int mode; int map; int players; int vibro; };

#define N_MODES 2          // Deathmatch, Team fight (as in the original "new game" screen)
#define N_MAPS  8
#define MIN_PLAYERS 2
#define MAX_PLAYERS 20
extern const char *MODE_NAMES[N_MODES];
extern const char *MAP_NAMES[N_MAPS];
extern unsigned maps_ready;   // bitmask of maps that have converted data

struct Menu {
    Screen scr = Screen::Title;
    int sel = 1;
    int timer = 0;
    int notice = 0;
    const char *notice_text = "";
    GameConfig cfg = { 0, 0, 6, 1 };

    void Update(unsigned pressed);
    void BackToTitle();
    // backdrop3d: the caller already drew the 3D scene; otherwise the flat background tile is drawn.
    void Draw(bool backdrop3d) const;
};
