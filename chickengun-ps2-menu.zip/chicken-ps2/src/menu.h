#ifndef MENU_H
#define MENU_H
typedef enum { SCR_TITLE, SCR_CREATE, SCR_SETTINGS, SCR_LOADING, SCR_GAME } Screen;

typedef struct { int mode; int map; int players; int vibro; } GameConfig;

typedef struct {
    Screen scr;
    int sel;
    int timer;
    int notice;          /* frames left to show a notice line */
    const char *notice_text;
    GameConfig cfg;
} Menu;

#define N_MODES 2
#define N_MAPS  8
#define MIN_PLAYERS 2
#define MAX_PLAYERS 20
extern const char *MODE_NAMES[N_MODES];
extern const char *MAP_NAMES[N_MAPS];
extern unsigned maps_ready;   /* bitmask of maps that have converted data */

void menu_init(Menu *m);
void menu_update(Menu *m, unsigned pressed);
void menu_draw(const Menu *m);
#endif
